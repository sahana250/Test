candump can0 &
candump can1 &
candump can2 &

