#!/bin/sh
#while [ 1 ];
#do
i2cdetect -y 0
#sleep 1
#done
