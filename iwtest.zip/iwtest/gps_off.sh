#!/bin/sh
echo 86 > /sys/class/gpio/export 
echo out > /sys/class/gpio/gpio86/direction
echo 0 > /sys/class/gpio/gpio86/value