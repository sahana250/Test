ifconfig ppp0 down
ifconfig can0 down
ifconfig wlan0 down
killall -9 cat
ifconfig eth0 down
ip link set can1 down
ip link set can2 down
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 1 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio78/value
echo 0 > /sys/class/gpio/gpio90/value

rmmod /iwtest/Kernel-Module/udc-core.ko
rmmod /iwtest/Kernel-Module/libcomposite.ko
rmmod /iwtest/Kernel-Module/ci_hdrc.ko
rmmod /iwtest/Kernel-Module/usbmisc_imx.ko
rmmod /iwtest/Kernel-Module/ci_hdrc_imx.ko
rmmod /iwtest/Kernel-Module/u_serial.ko
rmmod /iwtest/Kernel-Module/tcan4x5x.ko

sleep 1
echo 0 > /sys/class/gpio/gpio137/value
echo 0 > /sys/class/gpio/gpio90/value
echo 0 > /sys/class/gpio/gpio78/value

echo 137 > /sys/class/gpio/unexport
echo 118 > /sys/class/gpio/unexport
echo 120 > /sys/class/gpio/unexport
echo 73 > /sys/class/gpio/unexport
echo 64 > /sys/class/gpio/unexport
echo 90 > /sys/class/gpio/unexport   
echo 78 > /sys/class/gpio/unexport 
echo 88 > /sys/class/gpio/unexport 
