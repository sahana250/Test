sleep 3
echo "at+qgps=1" > /dev/ttyUSB2
sleep 1
echo "at+qgps=1" > /dev/ttyUSB2
sleep 1
echo "at+qgps=1" > /dev/ttyUSB2
while [ 1 ];
do
echo "GPS!!!!!!!!!!!!!!!!!!!!!!!!!!"
cat  /dev/ttyUSB1 &
sleep 3
killall cat
done
