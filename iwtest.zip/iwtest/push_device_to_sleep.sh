echo mem > /sys/power/state
