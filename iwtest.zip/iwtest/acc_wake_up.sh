killall -9 sensor_test
echo enabled > /sys/bus/i2c/devices/i2c-1/1-006a/power/wakeup
i2cset -f -y 1 0x6A 0x0D 0x00
i2cset -f -y 1 0x6A 0x58 0x8e


