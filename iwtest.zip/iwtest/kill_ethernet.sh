#! /bin/sh
ifconfig eth0 down
killall ethernet.sh