hwclock -r
date -s "2022-07-15 21:12:00"
hwclock -w
hwclock -r

