#!/bin/sh
#DOUT1
echo 32 > /sys/class/gpio/export                                                                                                                                              
echo out > /sys/class/gpio/gpio32/direction
#DOUT2
echo 38 > /sys/class/gpio/export 
echo out > /sys/class/gpio/gpio38/direction
while [ 1 ];
do
echo "DOUT1 ON"
echo 1 > /sys/class/gpio/gpio32/value
sleep 2
echo "DOUT2 ON"
echo 1 > /sys/class/gpio/gpio38/value
sleep 2
echo "DOUT1 OFF"
echo 0 > /sys/class/gpio/gpio32/value
sleep 4
echo "DOUT2 OFF"
echo 0 > /sys/class/gpio/gpio38/value
sleep 4 
done
