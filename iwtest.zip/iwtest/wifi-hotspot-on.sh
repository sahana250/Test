state=$(cat /sys/class/net/wlan0/operstate)
echo "$state"
if [ "$state" = "up" ]
then
        echo "WiFi is ON!!!!!!!!!!!!!!!!!!!!!! "
	sleep 1
elif [ "$state" = "down" ]
then
	systemctl restart dnsmasq
	sleep 1
	systemctl restart hostapd
	echo "WiFi is ON!!!!!!!!!!!!!!!!!!!!!! "
	sleep 1
fi
ifconfig
