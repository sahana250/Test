#!/bin/sh
insmod /iwtest/kernel-module/tcan4x5x.ko
sleep 2
ip link set can2 up type can bitrate 500000 dbitrate 5000000 fd on
sleep 1
ip link set can0 up type can bitrate 250000
sleep 1
ip link set can1 up type can bitrate 250000
sleep 1
ifconfig
