import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libRuggedTelematics.so")
print("battery_init")
rc = libc.i_battery_init()
print(hex((rc + (1 << 32)) % (1 << 32)))
print("battery_get_health")
rc =  libc.i_battery_get_health()
print(hex((rc + (1 << 32)) % (1 << 32)))
x = c_double()
print("battery_get_voltage")
rc = libc.i_battery_get_voltage(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
print(" voltage ")
print(x.value)

