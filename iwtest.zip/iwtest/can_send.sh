#!/bin/sh
while [ 1 ];
do
	cansend can2 123#abcdabcd
	sleep 2
done 