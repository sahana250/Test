./deinit.sh
killall -9 *.sh
killall -9 ash
killall -9 sensor_test
killall -9 pppd
killall -9 4G_AT_TEST

