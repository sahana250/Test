./deinit.sh
killall -9 *.sh
killall -9 ash
killall sensor_test
