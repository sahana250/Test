#!/bin/bash
i=1
while [ $i -le 10 ];
do
echo iwave RS232 Test > /dev/ttymxc5
sleep 1
(( i++ ))
done
echo "done" 

echo "Send data from Host PC"
cat /dev/ttymxc5 
