#!/bin/sh
#BLUETOOTH INITITALIZATION 
#./bluetooth_init.sh
./bluetooth_scan.sh &

#INITALIZING GPIO
./export.sh

#ENABLING ALL SWITCHES
./switch_on.sh

#MODEM ON  
./4g_on.sh
sleep 5

#4G PING
./4g_ping_test.sh &

#CAN INIT 
./can_init.sh

#ETH_INIT 
./eth_init

sleep 10

#GPS
./gps_RE.sh & 
sleep 10

#WIFI  
#./wifi-hotspot-on.sh &

#4G TEST
./4G_AT_TEST &

#BLUETOOTH SCAN 
#echo "##########################################"
#./bluetooth_scan.sh &
#echo "###########################################"
#LED 
./led.sh &

#BATTERY STATUS
./battery_status_RE.sh &

#CAN 
./can_send.sh &
./can_receive.sh &
#ETERNET
./eth_init
./ethernet.sh &

#ACCELEROMETER & GYROSCOPE
./sensor_test & 

#MCU DETECT
#./mcu.sh &
