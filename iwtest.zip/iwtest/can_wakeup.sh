ip link set can0 up type can bitrate 250000
ip link set can1 up type can bitrate 250000
echo enabled > /sys/devices/soc0/soc/2000000.aips-bus/2090000.flexcan/power/wakeup
echo enabled > /sys/devices/soc0/soc/2000000.aips-bus/2094000.flexcan/power/wakeup

