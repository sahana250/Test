echo +60 > /sys/class/rtc/rtc0/wakealarm
