#! /bin/sh
ping 192.168.1.12 &
