#! /bin/sh
ifconfig
ping 192.168.1.12 
