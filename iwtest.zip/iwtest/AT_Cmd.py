import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libRuggedTelematics.so")
#rc = libc.init(0)
#print(hex((rc + (1 << 32)) % (1 << 32)))

print("AT COMMAND")
at_cmd = c_char_p(b'at+cpin?')
print(at_cmd.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd.value, byref(resp), sizeof(resp), 500000)
print(resp.value)

print("AT COMMAND")
at_cmd1 = c_char_p(b'at+creg?')
print(at_cmd1.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd1.value, byref(resp), sizeof(resp), 500000)
print(resp.value)

print("AT COMMAND")
at_cmd2 = c_char_p(b'at+csq')
print(at_cmd2.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd2.value, byref(resp), sizeof(resp), 500000)
print(resp.value)

print("AT COMMAND")
at_cmd3 = c_char_p(b'at+gsn')
print(at_cmd3.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd3.value, byref(resp), sizeof(resp), 500000)
print(resp.value)

print("AT COMMAND")
at_cmd4 = c_char_p(b'at+qgmr')
print(at_cmd4.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd4.value, byref(resp), sizeof(resp), 500000)
print(resp.value)

print("AT COMMAND")
at_cmd5 = c_char_p(b'at+qccid')
print(at_cmd5.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd5.value, byref(resp), sizeof(resp), 500000)
print(resp.value)

