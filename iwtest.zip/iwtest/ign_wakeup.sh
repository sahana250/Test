echo enabled > /sys/devices/soc0/gpio-keys/power/wakeup
