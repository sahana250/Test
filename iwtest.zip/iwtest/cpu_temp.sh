while [ 1 ];
do
echo " CPU TEMP : "$(cat /sys/class/thermal/thermal_zone0/temp)
sleep 2
done
