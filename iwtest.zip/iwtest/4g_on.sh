echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 1 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 1
insmod /iwtest/kernel-module/udc-core.ko
insmod /iwtest/kernel-module/libcomposite.ko
insmod /iwtest/kernel-module/ci_hdrc.ko
insmod /iwtest/kernel-module/usbmisc_imx.ko
insmod /iwtest/kernel-module/ci_hdrc_imx.ko
insmod /iwtest/kernel-module/u_serial.ko
sleep 1
