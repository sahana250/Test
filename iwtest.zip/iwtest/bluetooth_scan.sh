#!/bin/sh
hciconfig
while [ 1 ];
do
#	echo "scanning ble devices"
	hcitool scan
	sleep 3
done