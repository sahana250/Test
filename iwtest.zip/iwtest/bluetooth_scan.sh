#!/bin/sh
while [ 1 ];
do
	hcitool scan
	sleep 3
done