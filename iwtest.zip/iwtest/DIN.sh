#!/bin/sh
echo 4 > /sys/class/gpio/export
echo in > /sys/class/gpio/gpio4/direction
echo 39 > /sys/class/gpio/export
echo in > /sys/class/gpio/gpio39/direction
while [ 1 ];
do
echo "DIN1"
cat /sys/class/gpio/gpio4/value
sleep 1
echo "DIN2"
cat /sys/class/gpio/gpio39/value
sleep 1
done
