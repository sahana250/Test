echo 73 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio73/direction
while [ 1 ];
do
echo 1 > /sys/class/gpio/gpio73/value
echo "LED ON"
sleep 1
echo 0 > /sys/class/gpio/gpio73/value
echo "LED OFF"
sleep 1
done
