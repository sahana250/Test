# AWS CloudFormation Templates for IoT FleetWise

These AWS CloudFormation template files can be used to compile and run the IoT FleetWise Edge Agent.
See the [Edge Agent Developer](../../docs/dev-guide/edge-agent-dev-guide.md) Guide for more information.
