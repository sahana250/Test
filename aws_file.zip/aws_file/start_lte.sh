#!/bin/sh
echo 1 > /proc/sys/net/ipv4/ip_forward

#12v register
echo 137 > /sys/class/gpio/export
#Battery Status
echo 118 > /sys/class/gpio/export
#Battery Charge Enable
echo 120 > /sys/class/gpio/export
#LED
echo 73 > /sys/class/gpio/export
#Battery Power Good
echo 64 > /sys/class/gpio/export
#Modem
echo 90 > /sys/class/gpio/export
echo 78 > /sys/class/gpio/export
echo 88 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio137/direction
echo out > /sys/class/gpio/gpio120/direction
echo out > /sys/class/gpio/gpio73/direction
echo in > /sys/class/gpio/gpio118/direction
echo in > /sys/class/gpio/gpio64/direction
echo out > /sys/class/gpio/gpio90/direction
echo out > /sys/class/gpio/gpio78/direction
echo out > /sys/class/gpio/gpio88/direction
sleep 1
echo 0 > /sys/class/gpio/gpio137/value
echo 1 > /sys/class/gpio/gpio90/value
echo 1 > /sys/class/gpio/gpio78/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 1 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 1
insmod /iwtest/kernel-module/udc-core.ko
insmod /iwtest/kernel-module/libcomposite.ko
insmod /iwtest/kernel-module/ci_hdrc.ko
insmod /iwtest/kernel-module/usbmisc_imx.ko
insmod /iwtest/kernel-module/ci_hdrc_imx.ko
insmod /iwtest/kernel-module/u_serial.ko
insmod /iwtest/kernel-module/can-isotp.ko
sleep 20
/usr/sbin/pppd call gprs_4g nodetach


