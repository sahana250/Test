import sys
import ctypes
import time
import struct
from ctypes import *

libc = ctypes.CDLL("/usr/lib/libTelematics_GW.so")

print("INIT Function")
rc = libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))

resp = create_string_buffer(20)
rc = (libc.i2c_write(1,0x6a,0x20,0x86))
print("I2C Write")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.i2c_read(1,0x6a,0x20,byref(resp))
print("I2C Read")
print(hex((rc + (1 << 32)) % (1 << 32)))
print(resp.value)

