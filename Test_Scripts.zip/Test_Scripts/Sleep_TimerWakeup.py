import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

rc = libc.init(0)
print("INIT FUNCTION")
print(hex((rc + (1 << 32)) % (1 << 32)))
print("************ init return val is ", rc)

print("ACCELEROMETER Init")
rc =  libc.acc_init()
print(hex((rc + (1 << 32)) % (1 << 32)))

ENABLE = 1
print("Config ACC Wakeup")
rc=libc.config_acc_wakeup(ENABLE)
print(hex((rc + (1 << 32)) % (1 << 32)))

ENABLE = 1
DISABLE = 0
rc = (libc.config_timer_wakeup(ENABLE, 30))
print("Config Timer Wakeup")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.config_ignition_wakeup(ENABLE))
print("Config Ignition Wakeup")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.config_can_wakeup(ENABLE))
print("Config CAN Wakeup")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.push_device_to_sleep())
print("Sleep Mode ON")
print(hex((rc + (1 << 32)) % (1 << 32)))
