import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

x = c_int()
print("Gsm sim_status")
rc = libc.get_gsm_sim_status(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
x.value
