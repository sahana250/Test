import sys                                                       
import ctypes                                                    
import time                                                      
from ctypes import *                                             
libc = ctypes.CDLL("/usr/lib/libOBD2.so")  

print("ACCELEROMETER Init")
rc =  libc.acc_init()
print(hex((rc + (1 << 32)) % (1 << 32)))

ENABLE = 1
print("Config ACC Wakeup")
rc=libc.config_acc_wakeup(ENABLE)
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.push_device_to_sleep())
print("Sleep Mode ON")
print(hex((rc + (1 << 32)) % (1 << 32)))

print("ACC Wakeup Threshold")
acc = 0x89
rc=libc.set_acc_wakeup_threshold(acc)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("ACC sampling frequency")
sample = 0x70
rc=libc.set_acc_sampling_frequency(sample)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("ACC Low Pass Filter")
filter = 0x80
rc=libc.set_acc_low_pass_filter(filter)
print(hex((rc + (1 << 32)) % (1 << 32)))

