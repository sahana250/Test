import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
print("FLIGHT MODE ON")
rc = (libc.set_gsm_flight_mode_on())
print(hex((rc + (1 << 32)) % (1 << 32)))
print("FLIGHT MODE OFF")
rc = (libc.set_gsm_flight_mode_off())
print(hex((rc + (1 << 32)) % (1 << 32)))
