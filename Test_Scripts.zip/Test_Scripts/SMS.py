import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

print("INIT FUNCTION")
rc = libc.init(0)
msg = create_string_buffer(10000000)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("SET to message init")
rc =libc. GSM_set_to_message_init()
print(hex((rc + (1 << 32)) % (1 << 32)))

print("READ MESSAGES")
rc=libc.read_message(ctypes.byref(msg),100000,8000000)
print(hex((rc + (1 << 32)) % (1 << 32)))
print(msg.value)

#rc=libc.delete_all_messages(10000)
#print("DELETE Messages")
#print(hex((rc + (1 << 32)) % (1 << 32)))
