import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

buf = create_string_buffer(150)
rc = libc.get_time(ctypes.byref(buf))
print("Get time")
print(buf.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.ntp_server_update()
print("NTP server Update")                                 
print(hex((rc + (1 << 32)) % (1 << 32)))


