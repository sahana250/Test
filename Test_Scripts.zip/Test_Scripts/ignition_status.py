import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

print("INIT")
rc=libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.ignition_pin_status_check()                                                  
print("Ignition PIN Status")                                                      
print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
rc = libc.ign_pin_status_check_enable()                                          
print("ignition status Check Enable")                                             
print(hex((rc + (1 << 32)) % (1 << 32)))
