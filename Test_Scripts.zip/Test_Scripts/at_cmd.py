import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc = libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("AT COMMAND")
at_cmd = c_char_p(b'at+cpin?')
print(at_cmd.value)
resp = create_string_buffer(200)
libc.gsm_at_cmd(at_cmd.value, byref(resp), sizeof(resp), 500000)
print(resp.value)
