import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc = libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))
apn = create_string_buffer(10)
apn.value=b'idea.com'
apd = create_string_buffer(10)
apd.value=b'****200##'
user = create_string_buffer(10)
user.value=b'akhil'
passd = create_string_buffer(10)
passd.value=b'123456'
libc.gsm_apn_configuration(ctypes.byref(apn),ctypes.byref(apd),ctypes.byref(user),ctypes.byref(passd))
