import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

rc = libc.init(0)
print("********* INIT FUNCTION with init 0 *********")
print(hex((rc + (1 << 32)) % (1 << 32)))
print("************ init return val is ", rc)

print("MODEM STATUS") 
rc = (libc.check_gsm_modem_status())                                                                    
print(hex((rc + (1 << 32)) % (1 << 32)))
                                                         
print("ESTABLISH CONNECTION")
rc = (libc.establish_connection())                                                                       
print(hex((rc + (1 << 32)) % (1 << 32)))
