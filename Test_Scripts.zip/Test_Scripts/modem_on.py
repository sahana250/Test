import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
cpin = create_string_buffer(4)
cpin.value=b'0000'
cpin.value
print(sizeof(cpin))
rc = libc.init(0)
print("INIT FUNCTION")
print(hex((rc + (1 << 32)) % (1 << 32)))
print("************ init return val is ", rc)
rc = libc.gsm_modem_on(ctypes.byref(cpin), 4)
print("GSM MODEM ON")
print(hex((rc + (1 << 32)) % (1 << 32)))
