import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

rc = libc.init(0)
print("INIT FUNCTION")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.check_network_connection())                                                                                         
print("CHECK NETWORK CONNECTION")                                                                        
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.check_gsm_nw_connection())
print("Check GSM Network Connection") 
print(hex((rc + (1 << 32)) % (1 << 32)))
