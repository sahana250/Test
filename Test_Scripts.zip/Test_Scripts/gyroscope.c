#include <stdio.h>
#include <linux/can.h>
#include <stdlib.h>
#include "accelerometer.h"
#include "gyroscope.h"

int main()
{
	int rc = -1;
	int i = 0;
	int j = 0;
	char can_name[] = "can0";
	accelerometer_api_priv g_adata;
	gyroscope_api_priv g_data;
#if 1
	rc = init(0);
	printf("Return value for Init : %d\n", rc);
	if(rc != 0)
		printf("Init Failed\n");
	else
		printf("Init Success\n");
#endif
	/* -------------------------------------- CAN ---------------------------------------*/
#if 0
	rc = gyro_init();

	printf("\n Gyroscope Initialisation return value = 0x%x\n",rc);
	if(rc != 0)
		printf("Gyro init Failed\n");
	else
		printf("Gyro init Success\n");
#endif
	for(i=0; i<=20; i++)
	{
		rc = gyroscope_read(&g_data);
		printf("\n Return Value for Gyroscope : %d\n", rc);
		printf ("gyro x-axis: %f\ty-axis: %f\tz-axis: %f\n",g_data.x,g_data.y,g_data.z);
        	if(rc < 0)
                	printf("gyro read Failed\n");
        	else
                	printf("gyro read Success\n");
	}

	rc = gyro_deinit ();
	printf("gyro_deinit rc value %x\n", rc );
        if(rc != 0)
                printf("gyro Deinit Failed\n");
        else
                printf("gyro Deinit Success\n");
}
