import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc = libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))
nmea1 = ctypes.c_char_p(b'GPRMC')
nmea = ctypes.c_char_p(b'GPGGA')
nmea2 = ctypes.c_char_p(b'GPGSA')
nmea3 = ctypes.c_char_p(b'GPVTG')
recv_data = ctypes.create_string_buffer(128)
clen = ctypes.c_size_t()
clen.value = 0
while 1:
    rc = libc.get_gps_data(nmea.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
    rc = libc.get_gps_data(nmea1.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
    rc = libc.get_gps_data(nmea2.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
    rc = libc.get_gps_data(nmea3.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
