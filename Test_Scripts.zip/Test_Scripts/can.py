import sys
import ctypes
import time
import struct
from ctypes import *

libc = ctypes.CDLL("/usr/lib/libOBD2.so")
libc.init(0)
#name = "can0"
#print(name)

name = c_char_p(b'can0')
print("CAN Init")
rc = libc.can_init(name.value,500000)
print("NAME :", name.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

data = c_char_p(b'7E0#02010C0000000000')
rc = libc.can_write(name.value, data.value)
print("CAN Write")
print(hex((rc + (1 << 32)) % (1 << 32)))

#rc = libc.can_read(name.value,frame)
#print(CAN Read)
#print(hex((rc + (1 << 32)) % (1 << 32)))

#rc = libc.can_deinit(name.value)
#print("CAN Deinit")
#print(hex((rc + (1 << 32)) % (1 << 32)))

