import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

print("INIT")
rc=libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.ble_init()                                                  
print("BLE init")                                                      
print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
rc = libc.ble_deinit()                                          
print("BLE deinit")                                             
print(hex((rc + (1 << 32)) % (1 << 32)))
