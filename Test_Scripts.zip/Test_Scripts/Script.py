import sys                                                       
import ctypes                                                    
import time                                                      
from ctypes import *                                             
libc = ctypes.CDLL("/usr/lib/libOBD2.so")                                                         
cpin = create_string_buffer(4)                                                                    
cpin.value=b'0000'                                                                                
cpin.value                                                                                        
print(sizeof(cpin))                                              
rc = libc.init(0)                                                
print("INIT FUNCTION")                                                                            
print(hex((rc + (1 << 32)) % (1 << 32)))                                
print("************ init return val is ", rc)                           
                                                                        
#rc = libc.gsm_modem_on(ctypes.byref(cpin), 4)                   
#print("GSM MODEM ON")                                           
#print(hex((rc + (1 << 32)) % (1 << 32)))                               
                                                                 
#adcvolt = create_string_buffer(5)                   
#rc = (libc.check_adc_voltage(ctypes.byref(adcvolt)))                                             
#print("ADC_VOLTAGE :")                  
#print("Return Value :",rc)                                      
#print(adcvolt.value)                                                                             
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#buf = create_string_buffer(150)                                                                  
#rc = libc.get_time(ctypes.byref(buf))                                                            
#print("Get time")                                               
#print(hex((rc + (1 << 32)) % (1 << 32)))                               
                                                                        
#rc = libc.gps_init()                                                   
#print("GPS init")                                                      
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#rc = libc.gps_deinit()                                          
#print("GPS deinit")                                             
#print(hex((rc + (1 << 32)) % (1 << 32)))                        
                                                                 
#rc = (libc.check_gsm_nw_connection())                                                            
#print("Check GSM Network Connection")                                                            
#print(hex((rc + (1 << 32)) % (1 << 32)))   

#imei = create_string_buffer(17)                                 
#rc = (libc.get_gsm_imei(ctypes.byref(imei),ctypes.sizeof(imei)))
#print("IMEI :")                                                                                  
#print(imei.value)                                                                                
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#at_cmd = c_char_p(b'at+cpin?')                                  
#print(at_cmd.value)                                             
#resp = create_string_buffer(200)                                                                 
#libc.gsm_at_cmd(at_cmd.value, byref(resp), sizeof(resp), 500000)       
#print(resp.value)                                                      
                                                                        
#rc = (libc.set_gsm_network_mode("2"))                           
#print("set GSM network mode")                                   
#print(hex((rc + (1 << 32)) % (1 << 32)))                               
                                                                 
#rc = (libc.establish_connection())                              
#print("ESTABLISH CONNECTION")                                                                    
#print(hex((rc + (1 << 32)) % (1 << 32)))
                                                                 
#rc = (libc.check_network_connection())                                                           
#print("CHECK NETWORK CONNECTION")                                                                
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#signal_strength = create_string_buffer(10)                                                       
#rc = (libc.get_gsm_signal_strength(ctypes.byref(signal_strength),ctypes.sizeof(signal_strength)))
#print("SIGNAL STRENGTH")                                                                         
#print(signal_strength.value)                                                                     
#print(hex((rc + (1 << 32)) % (1 << 32)))                               
                                                                        
#iccid = create_string_buffer(20)                                                                 
#rc = (libc.get_gsm_sim_iccid(ctypes.byref(iccid),ctypes.sizeof(iccid)))                          
#print("SIM ICCID")                                                                               
#print(iccid.value)                                                                               
#print(hex((rc + (1 << 32)) % (1 << 32)))                        
                                                                 
#rc = (libc.set_gsm_network_mode("5"))                                                            
#print("set GSM network mode")                                                                    
#print(hex((rc + (1 << 32)) % (1 << 32)))                               

rc = (libc.set_gsm_flight_mode_on())                                                             
print("FLIGHT MODE ON")                                                
print(hex((rc + (1 << 32)) % (1 << 32))) 
time.sleep(2)                 
rc = (libc.set_gsm_flight_mode_off())                                                            
print("FLIGHT MODE OFF")                                                                         
print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#rc = (libc.establish_connection())                                                               
#print("ESTABLISH CONNECTION")                                                                    
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#rc = (libc.check_gsm_nw_connection())                                  
#print("Check GSM Network Connection")                                  
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#imei = create_string_buffer(17)                                                                  
#rc = (libc.get_gsm_imei(ctypes.byref(imei),ctypes.sizeof(imei)))                                 
#print("IMEI :")                                                 
#print(imei.value)                                               
#print(hex((rc + (1 << 32)) % (1 << 32)))                                                         
                                                                                                  
#rc = libc.gsm_modem_off()                                              
#print("GSM MODEM OFF")                                                 
#print(hex((rc + (1 << 32)) % (1 << 32)))    
