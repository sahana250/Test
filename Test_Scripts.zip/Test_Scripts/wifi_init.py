import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc = libc.init(0)
print("INIT FUNCTION")
print(hex((rc + (1 << 32)) % (1 << 32)))
rc=libc.wifi_init(1)
print("Wifi INIT")
print(hex((rc + (1 << 32)) % (1 << 32)))
