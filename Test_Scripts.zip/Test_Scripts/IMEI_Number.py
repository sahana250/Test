import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
iccid = create_string_buffer(25)
rc=libc.init(1)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("GET GSM IMEI")
imei = create_string_buffer(25)
rc = libc.get_gsm_imei(ctypes.byref(imei),ctypes.sizeof(imei))
print(imei.value)
print(hex((rc + (1 << 32)) % (1 << 32)))
