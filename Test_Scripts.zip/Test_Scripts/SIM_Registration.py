import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc=libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))
cell_id = create_string_buffer(1)      
lac = create_string_buffer(1)                                         
rc = (libc.get_gsm_nw_reg(ctypes.byref(cell_id), ctypes.sizeof(cell_id), ctypes.byref(lac), ctypes.sizeof(lac)))
print("GSM NETWORK REGISTRATION STATUS")                               
print(cell_id.value)                    
print(lac.value)


