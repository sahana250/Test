import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")

mac = create_string_buffer(50)
print("Bluetooth MAC Address")
macaddrs = c_char_p(b'hci0')
rc = (libc.get_mac_address(macaddrs.value, byref(mac)))
print(mac.value)                                       
print(hex((rc + (1 << 32)) % (1 << 32)))
                                        
mac1 = create_string_buffer(25)          
print("Ethernet MAC Address") 
macaddrs = c_char_p(b'eth0')  
rc = libc.get_mac_address(macaddrs.value,byref(mac1))
print(mac1.value)                                    
print(hex((rc + (1 << 32)) % (1 << 32)))
