import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc=libc.init(1)
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.gsm_modem_on(ctypes.byref(cpin), 4)                   
print("GSM MODEM ON")                                           
print(hex((rc + (1 << 32)) % (1 << 32)))

signal_strength = create_string_buffer(10)
rc = (libc.get_gsm_signal_strength(ctypes.byref(signal_strength),ctypes.sizeof(signal_strength)))
print("SIGNAL STRENGTH")
print(signal_strength.value)
print(hex((rc + (1 << 32)) % (1 << 32)))                         
