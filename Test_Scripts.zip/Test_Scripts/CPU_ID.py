import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc=libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))
cpuid = create_string_buffer(23)
rc = (libc.get_cpu_id(ctypes.byref(cpuid),ctypes.sizeof(cpuid)))
print("CPUID :")
print(cpuid.value)
print(hex((rc + (1 << 32)) % (1 << 32)))
