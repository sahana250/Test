import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
iccid = create_string_buffer(25)
rc=libc.init(1)
print(hex((rc + (1 << 32)) % (1 << 32)))
rc = (libc.get_gsm_sim_iccid(ctypes.byref(iccid),ctypes.sizeof(iccid)))
print("SIM ICCID")
print(iccid.value)
print(hex((rc + (1 << 32)) % (1 << 32)))
