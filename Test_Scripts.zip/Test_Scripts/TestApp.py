import sys                                                       
import ctypes                                                    
import time                                                      
from ctypes import *                                             
libc = ctypes.CDLL("/usr/lib/libOBD2.so")                                                         
cpin = create_string_buffer(4)
cpin.value=b'0000'                                                                                
cpin.value                                                                                        
print(sizeof(cpin))                                              
ENABLE = 1
DISABLE = 0
msg = create_string_buffer(10000000)

rc = libc.init(0)                                                
print("INIT FUNCTION")                                                                            
print(hex((rc + (1 << 32)) % (1 << 32)))                                
print("************ init return val is ", rc)                           

rc = (libc.i_battery_init())      
print("Battery Init")                  
print(hex((rc + (1 << 32)) % (1 << 32)))

cpuid = create_string_buffer(23)
rc = (libc.get_cpu_id(ctypes.byref(cpuid),ctypes.sizeof(cpuid)))
print("CPUID :")
print(cpuid.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.eth_init())      
print("Ethernet Init")                  
print(hex((rc + (1 << 32)) % (1 << 32)))

mac = create_string_buffer(50)                 
print("MAC Address of Ethernet")                    
macaddrs = c_char_p(b'eth0')                                                                     
print(macaddrs.value)                                                                            
rc = (libc.get_mac_address(macaddrs.value, byref(mac)))                             
print(mac.value)                   
print(hex((rc + (1 << 32)) % (1 << 32)))

rc=libc.ble_init()
print("Bluetooth Init")
print(hex((rc + (1 << 32)) % (1 << 32)))

#rc = (libc.eth_deinit())      
#print("Ethernet deInit")                  
#print(hex((rc + (1 << 32)) % (1 << 32)))

mac = create_string_buffer(50)                 
print("MAC Address of Bluetooth")                    
macaddrs = c_char_p(b'hci0')                                                                     
print(macaddrs.value)                                                                            
rc = (libc.get_mac_address(macaddrs.value, byref(mac)))                             
print(mac.value)                   
print(hex((rc + (1 << 32)) % (1 << 32)))

rc=libc.wifi_init(1)
print("Wifi INIT")
print(hex((rc + (1 << 32)) % (1 << 32)))

mac = create_string_buffer(50)                 
print("MAC Address of Wifi")                    
macaddrs = c_char_p(b'wlan0')                                                                 
print(macaddrs.value)                                                                            
rc = (libc.get_mac_address(macaddrs.value, byref(mac)))                             
print(mac.value)                   
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.check_gsm_modem_status())                            
print("MODEM STATUS")                                           
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.gsm_modem_on(ctypes.byref(cpin), 4)                   
print("GSM MODEM ON")                                           
print(hex((rc + (1 << 32)) % (1 << 32)))

imei = create_string_buffer(17)
rc = (libc.get_gsm_imei(ctypes.byref(imei),ctypes.sizeof(imei)))
print("IMEI :")
print(imei.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

iccid = create_string_buffer(20)
rc = (libc.get_gsm_sim_iccid(ctypes.byref(iccid),ctypes.sizeof(iccid)))
print("SIM ICCID")
print(iccid.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

signal_strength = create_string_buffer(10)
rc = (libc.get_gsm_signal_strength(ctypes.byref(signal_strength),ctypes.sizeof(signal_strength)))
print("SIGNAL STRENGTH")
print(signal_strength.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

cell_id = create_string_buffer(1)      
lac = create_string_buffer(1)                                         
rc = (libc.get_gsm_nw_reg(ctypes.byref(cell_id), ctypes.sizeof(cell_id), ctypes.byref(lac), ctypes.sizeof(lac)))
print("GSM NETWORK REGISTRATION STATUS")                               
print(cell_id.value)                    
print(lac.value)

rc = (libc.set_gsm_network_mode("2"))                           
print("set GSM network mode")                                   
print(hex((rc + (1 << 32)) % (1 << 32)))                               

print("GSM APN Configuration")
apn = create_string_buffer(20)
apn.value=b'airtelgprs.com'
apd = create_string_buffer(15)
apd.value=b'ATD*99***1#'
user = create_string_buffer(10)
user.value=b'akhil'
passd = create_string_buffer(10)
passd.value=b'123456'
libc.gsm_apn_configuration(ctypes.byref(apn),ctypes.byref(apd),ctypes.byref(user),ctypes.byref(passd))
print(apn.value)                                                                                             
print(apd.value) 
                                                                 
rc = (libc.establish_connection())                              
print("ESTABLISH CONNECTION")                                                                    
print(hex((rc + (1 << 32)) % (1 << 32)))
                                                                 
rc = (libc.check_network_connection())                                                           
print("CHECK NETWORK CONNECTION")                                                                
print(hex((rc + (1 << 32)) % (1 << 32))) 

rc = (libc.check_gsm_nw_connection())
print("Check GSM Network Connection") 
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.ntp_server_update()
print("NTP server Update")                                                                               
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.led_enable()                                          
print("LED Enable")                                          
print(hex((rc + (1 << 32)) % (1 << 32))) 

rc = libc.agps_init()                                        
print("AGPS Init")                                           
print(hex((rc + (1 << 32)) % (1 << 32))) 

rc = libc.gps_init()                                       
print("GPS Init")                                        
print(hex((rc + (1 << 32)) % (1 << 32))) 

#rc = libc.gps_init()
#nmea1 = ctypes.c_char_p(b'GPRMC')
#nmea = ctypes.c_char_p(b'GPGGA')
#nmea2 = ctypes.c_char_p(b'GPGSA')
#nmea3 = ctypes.c_char_p(b'GPVTG')
#recv_data = ctypes.create_string_buffer(128)
#clen = ctypes.c_size_t()
#clen.value = 0
#time.sleep(30)
#while 1:
   #rc = libc.get_gps_data(nmea.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
#   rc = libc.get_gps_data(nmea1.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
#   rc = libc.get_gps_data(nmea2.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))
#   rc = libc.get_gps_data(nmea3.value, ctypes.byref(clen), ctypes.byref(recv_data), ctypes.sizeof(recv_data))

print("GSM set to message init")
rc =libc. GSM_set_to_message_init()
print(hex((rc + (1 << 32)) % (1 << 32)))

print("READ Message")
rc=libc.read_message(ctypes.byref(msg),100000,8000000)
print(hex((rc + (1 << 32)) % (1 << 32)))
print(msg.value)

#rc=libc.delete_all_messages(10000)
#print("DELETE Messages")
#print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.network_monitor_disable()     
print("Network monitor disable")        
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.set_gsm_flight_mode_on())                                                             
print("FLIGHT MODE ON")                                                
print(hex((rc + (1 << 32)) % (1 << 32))) 
time.sleep(2)                 

rc = (libc.set_gsm_flight_mode_off())                                                            
print("FLIGHT MODE OFF")                                                                         
print(hex((rc + (1 << 32)) % (1 << 32))) 

rc = libc.gps_deinit()                                
print("GPS De-Init")                          
print(hex((rc + (1 << 32)) % (1 << 32))) 

rc = libc.gsm_modem_off()              
print("GSM MODEM OFF")                                       
print(hex((rc + (1 << 32)) % (1 << 32)))
        
x = c_int()
print("get_battery_status")
rc = libc.i_get_battery_status(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
x.value

x = c_double()
print("battery_get_voltage")
rc = libc.i_battery_get_voltage(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
print(" voltage ")
print(x.value)

print("battery_get_health")
rc =  libc.i_battery_get_health()
print(hex((rc + (1 << 32)) % (1 << 32)))

x = c_int()
print("get_battery_status")
rc = libc.i_get_battery_status(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
x.value

print("ACCELEROMETER Init")
rc =  libc.acc_init()
print(hex((rc + (1 << 32)) % (1 << 32)))

print("GYROSCOPE Init")
rc =  libc.gyro_init()
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.config_timer_wakeup(ENABLE, 30))
print("Config Timer Wakeup")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.config_ignition_wakeup(ENABLE))
print("Config Ignition Wakeup")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = (libc.config_can_wakeup(ENABLE))
print("Config CAN Wakeup")
print(hex((rc + (1 << 32)) % (1 << 32)))
  
rc = (libc.push_device_to_sleep())
print("Sleep Mode ON")
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.gyro_deinit()                                 
print("Gyro Deinit")                                    
print(hex((rc + (1 << 32)) % (1 << 32))) 
  
rc = libc.acc_deinit()                                 
print("ACC Deinit")                                     
print(hex((rc + (1 << 32)) % (1 << 32))) 
                             
rc = libc.ble_deinit()                                 
print("BLE Deinit")                                     
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.wifi_deinit(1)                   
print("Wifi Deinit")                        
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.led_disable()                    
print("LED Disable")                        
print(hex((rc + (1 << 32)) % (1 << 32)))

rc = libc.deinit()                                              
print("Deinit")                                                 
print(hex((rc + (1 << 32)) % (1 << 32))) 

#rc = (libc.push_device_to_sleep())
#print("Sleep Mode ON")
#print(hex((rc + (1 << 32)) % (1 << 32)))

#print("Restart Device")
#rc = libc.restart_device()
#print(hex((rc + (1 << 32)) % (1 << 32)))
