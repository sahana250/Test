import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
print("INIT")
rc=libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("ADC_VOLTAGE")
#adcvolt = create_string_buffer(50)
adcvolt = c_double()
rc = (libc.check_adc_voltage(byref(adcvolt)))
print(adcvolt.value)
print(hex((rc + (1 << 32)) % (1 << 32)))

