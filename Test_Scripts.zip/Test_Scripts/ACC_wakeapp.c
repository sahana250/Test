#include <stdio.h>
#include <linux/can.h>
#include <stdlib.h>
#include "accelerometer.h"
#define ENABLE 1
int main()
{
	int rc = -1;
	int i = 0;
	int j = 0;
	char can_name[] = "can0";
	//magnetometer_api_priv mag;
	accelerometer_api_priv g_adata;
	int status = 0;
	rc = init(0);
	printf("Return value for Init : %d\n", rc);
	if(rc != 0)
		printf("Init Failed\n");
	else
		printf("Init Success\n");
		
	//rc = gsm_modem_on("0000", 4 );
	//printf("gsm_modem_on() Return value = %x\n",rc);

	rc = get_gsm_sim_status(&status);
	printf("Return value for SIM status : %d\n", rc);

	/* -------------------------------------- SENSOR ---------------------------------------*/
	rc = acc_init();

	printf("\n accelerometer Initialisation return value = 0x%x\n",rc);
	if(rc != 0)
		printf("ACC init Failed\n");
	else
		printf("ACC init Success\n");

	rc = config_acc_wakeup(ENABLE);
	printf("\n ACC Wakeup");
	
	rc = push_device_to_sleep();
	printf("\n Push device to sleep ");

#if 1
	for(i=0; i<=10; i++)
	{
		rc = accelerometer_read(&g_adata);
		printf("\n Return Value for Accelerometer : %d\n", rc);
		printf ("ACC x-axis: %f\ty-axis: %f\tz-axis: %f\n",g_adata.x,g_adata.y,g_adata.z);
        	if(rc < 0)
                	printf("ACC read Failed\n");
        	else
                	printf("ACC read Success\n");
	}

	rc = acc_deinit ();
	printf("mag_deinit rc value %x\n", rc );
        if(rc != 0)
                printf("ACC Deinit Failed\n");
        else
                printf("ACC Deinit Success\n");
#endif
}
