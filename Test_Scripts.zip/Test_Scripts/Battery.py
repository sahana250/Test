import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libRuggedTelematics.so")
print("init")
rc = libc.init(0)
print(hex((rc + (1 << 32)) % (1 << 32)))

print("battery_init")
rc = libc.i_battery_init()
print(hex((rc + (1 << 32)) % (1 << 32)))
print("battery_get_health")
rc =  libc.i_battery_get_health()
print(hex((rc + (1 << 32)) % (1 << 32)))
x = c_double()
print("battery_get_voltage")
rc = libc.i_battery_get_voltage(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
print(" voltage ")
print(x.value)
x = c_int()
print("get_battery_status")
rc = libc.i_get_battery_status(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
x.value
print("get_power_source")
rc = libc.get_power_source()
print(hex((rc + (1 << 32)) % (1 << 32)))
print("battery_charge_state_config")
y=0
print("%s" %(y))
rc = libc.battery_charge_state_config(y)
print(hex((rc + (1 << 32)) % (1 << 32)))
y=0
print("%s" %(y))
rc = libc.battery_connect_config(y)
print(hex((rc + (1 << 32)) % (1 << 32)))

x = c_int()
print("get_battery_Temperature")
rc = libc.i_get_battery_temp(byref(x))
print(hex((rc + (1 << 32)) % (1 << 32)))
x.value

