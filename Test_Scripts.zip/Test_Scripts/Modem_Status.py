import sys
import ctypes
import time
from ctypes import *
libc = ctypes.CDLL("/usr/lib/libOBD2.so")
rc = (libc.check_gsm_modem_status())                            
print("MODEM STATUS")                                           
print(hex((rc + (1 << 32)) % (1 << 32)))
