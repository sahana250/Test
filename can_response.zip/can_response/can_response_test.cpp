#include <stdio.h>
#include <string>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <chrono>
#include <cstring>
#include <cstdlib>

/*
return canfd socket file-description
*/
int can_setup(std::string can_name, sockaddr_can& addr) {
    struct ifreq ifr;
    int sockfd;
    uint32_t canfd_on = 1;

    if ( (sockfd = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0 ) {
        perror("socket");
        return -1;
    }

    strcpy(ifr.ifr_name, can_name.c_str());

    if (ioctl(sockfd, SIOCGIFINDEX, &ifr) < 0) {
        printf("Could not get index of interface > %s <\n", can_name.c_str());
        return -1;
    }

    memset(&addr, 0, sizeof(addr));

    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    /* Check MTU of interface */
    if (ioctl(sockfd, SIOCGIFMTU, &ifr) < 0) {
        perror("SIOCGIFMTU");
        return -1;
    }

    /* Check whether CAN_FD is possible */
    if (ifr.ifr_mtu == CANFD_MTU) {
        /* Try to switch into CAN_FD mode */
        if (setsockopt(sockfd, SOL_CAN_RAW, CAN_RAW_FD_FRAMES, &canfd_on, sizeof(canfd_on)) < 0) {
            printf("Could not enable CAN_FD.\n");
            return -1;
        }
    } else {
        printf("CAN_FD is not supported on > %s <\n", can_name.c_str());
        return -1;
    }

    /* Set timeout for CAN read interface - 1 second*/
    timeval tv;
    tv.tv_sec = 4;
    tv.tv_usec = 0;
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        printf("Could not set timeout.\n");
        return -1;
    }


	if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        // printf("Could not bind.\n");
		perror("Bind");
        return -1;
	}

    return sockfd;
}

int ReceiveCanFdFrame(int fd, canfd_frame& recv_frame) {
    int nbytes = read(fd, &recv_frame, sizeof(struct canfd_frame));
    
    if (nbytes < 0) {
        return -1;
    }

    // printf("%X \n", recv_frame.can_id);
    return 0;
}

int SendCan(int fd, canfd_frame *frame) {
    int mtu, maxdlen;
    mtu = CANFD_MTU;
    // maxdlen = CANFD_MAX_DLEN;
    frame->flags |= CANFD_BRS;
  if (write(fd, frame, mtu) < mtu) {
    printf("Write incomple canfd frame.\n");
    return -1;
  }
  return 0;
};

int main(int argc, char *argv[]) {
    std::string can_interface = "can0";
    int number_of_requests = 1000;

    for (int i=1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-i") {
            if (i + 1 < argc) {
                can_interface = argv[i + 1];
                i++;
            }
        } else if (arg == "-n") {
            if (i + 1 < argc) {
                number_of_requests = std::stoi(argv[i + 1]);
                i++;
            }
        }
    }

    int ret;
    uint32_t total_time = 0;
    sockaddr_can addr;
    int can_socket = can_setup(can_interface, addr);

    if (can_socket < 0) {
        return -1;
    }

    canfd_frame rx_frame;
    canfd_frame tx_frame;

    tx_frame.can_id = 0x610;
    tx_frame.len = 2;
    tx_frame.data[0] = 0x00;
    tx_frame.data[1] = 0x00;

    ret = SendCan(can_socket, &tx_frame);
    std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();

    if (ret < 0) return -1;
    int i = 1;

    while (true) {
        if (ReceiveCanFdFrame(can_socket, rx_frame) > -1) {
            if (rx_frame.can_id == 0x630) {
                if ( *((uint16_t*) rx_frame.data) == 0x0000) {
                    // TODO: measure time
                    end = std::chrono::steady_clock::now();
                    auto elapsed_miliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
                    total_time += elapsed_miliseconds;

                    if (i == number_of_requests) {
                        auto average_time = total_time * 1.0/number_of_requests;
                        printf("================================================================\n");
                        printf("Tested %d VCM version requests\n", number_of_requests);
                        printf("Average time to get response for every request is %f milliseconds\n", average_time);
                        break;
                    }

                    if ( (ret = SendCan(can_socket, &tx_frame)) < 0) {
                        return -1;
                    } else {
                        start = std::chrono::steady_clock::now();
                        i++;
                    }
                }
            }
        }
    }

    return 0;
}