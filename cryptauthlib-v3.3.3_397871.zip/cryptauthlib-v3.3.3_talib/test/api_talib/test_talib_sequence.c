/**
 * \file
 * \brief Basic test for Random command api - TA100
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "atca_test.h"
#include "test_talib.h"

#if ATCA_TA_SUPPORT

#define TA_SHARE_KEY_SEQ_LOCAL_FIRST  true

#define LOCAL_TARGET_HANDLE           0x8000
#define LOCAL_SIGN_HANDLE             0x8001
#define LOCAL_CERT_HANDLE             0x8002
#define LOCAL_EPEMERAL_HANDLE         0x4400

#define REMOTE_TARGET_HANDLE          0x8003
#define REMOTE_SIGN_HANDLE            0x8004
#define REMOTE_EPEMERAL_HANDLE        0x4401

#define ROOT_PUBKEY_HANDLE            0x8107
#define AUTH_CONTEXT_ID               0x4100

static sharekey_ctx_t ctx;
static uint8_t key_buf[32];

extern uint8_t hmac_key[22];
extern uint8_t hmac_i_nonce[16];
extern uint8_t hmac_r_nonce[16];

/* Using signer certificate as remote certificate */
extern const uint8_t test_ecc_signer_cert[571];

static uint8_t test_ecc_remote_cert_priv_key[32] = {
    0x05, 0x1d, 0x7b, 0x42, 0x94, 0xdb, 0x5c, 0xc3, 0xca, 0x86,     0xb6, 0x4a, 0x2c, 0xda, 0xc8, 0xd4,
    0x57, 0x4a, 0x37, 0x62, 0x80, 0xec, 0xd1, 0x16, 0x24, 0xb4,     0xbc, 0x61, 0x7f, 0x50, 0xc1, 0x5d
};


TEST_GROUP(talib_cmd_sequence);
TEST_SETUP(talib_cmd_sequence)
{
    UnityMalloc_StartTest();

    ATCA_STATUS status = atcab_init(gCfg);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    ta_element_attributes_t ecc_p256_private_key_attr;
    ta_element_attributes_t extracted_cert_attr;

    // skip if config is not locked
    test_assert_config_is_locked();

    /* Local sign handle */
    status = talib_handle_init_private_key(&ecc_p256_private_key_attr, TA_KEY_TYPE_ECCP256,
                                           TA_ALG_MODE_ECC_ECDSA, TA_PROP_SIGN_INT_EXT_DIGEST, TA_PROP_NO_KEY_AGREEMENT);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_handle_set_write_permission(&ecc_p256_private_key_attr, TA_PERM_ALWAYS);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_create_element_with_handle(atcab_get_device(), LOCAL_SIGN_HANDLE, &ecc_p256_private_key_attr);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_genkey(atcab_get_device(), LOCAL_SIGN_HANDLE, NULL, NULL);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Local cert handle */
    status = talib_handle_init_extracated_certificate(&extracted_cert_attr, TA_KEY_TYPE_ECCP256, TA_ALG_MODE_ECC_ECDSA, 0, TA_PROP_CERT_CA_OK);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_create_element_with_handle(atcab_get_device(), LOCAL_CERT_HANDLE, &extracted_cert_attr);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_store_extracted_cert_io(atcab_get_device(), ROOT_PUBKEY_HANDLE,
                                           LOCAL_CERT_HANDLE, test_ecc_signer_cert, sizeof(test_ecc_signer_cert));
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Remote sign handle */
    status = talib_handle_init_private_key(&ecc_p256_private_key_attr, TA_KEY_TYPE_ECCP256,
                                           TA_ALG_MODE_ECC_ECDSA, TA_PROP_SIGN_INT_EXT_DIGEST, TA_PROP_NO_KEY_AGREEMENT);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_handle_set_write_permission(&ecc_p256_private_key_attr, TA_PERM_ALWAYS);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    ecc_p256_private_key_attr.property &= ~TA_PROP_EXECUTE_ONLY_KEY_GEN_MASK;
    status = talib_create_element_with_handle(atcab_get_device(), REMOTE_SIGN_HANDLE, &ecc_p256_private_key_attr);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_write_priv_key(atcab_get_device(), REMOTE_SIGN_HANDLE, sizeof(test_ecc_remote_cert_priv_key), test_ecc_remote_cert_priv_key);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
}

TEST_TEAR_DOWN(talib_cmd_sequence)
{
    // skip if config is not locked
    test_assert_config_is_locked();

    /* Delete local handles that may have been created by the test */
    (void)talib_delete_handle(atcab_get_device(), LOCAL_TARGET_HANDLE);
    (void)talib_delete_handle(atcab_get_device(), LOCAL_SIGN_HANDLE);
    (void)talib_delete_handle(atcab_get_device(), LOCAL_CERT_HANDLE);

    /* Delete remote handles that may have been created by the test */
    (void)talib_delete_handle(atcab_get_device(), REMOTE_TARGET_HANDLE);
    (void)talib_delete_handle(atcab_get_device(), REMOTE_SIGN_HANDLE);

    TEST_ASSERT_EQUAL(ATCA_SUCCESS, atcab_release());

    UnityMalloc_EndTest();
}


/** \brief  To initialize share key sequence target attribute information
 *      .
 */
static ATCA_STATUS talib_handle_init_share_key_seq_target_key(ta_element_attributes_t* element_attributes)
{
    ATCA_STATUS status;

    status = talib_handle_init_symmetric_key(element_attributes, TA_KEY_TYPE_AES128,
                                             TA_PROP_SYMM_KEY_USAGE_ANY);
    element_attributes->property |= TA_PROP_SYMM_KEY_EITHER_OPTIONAL_MASK;

    status = talib_handle_set_write_permission(element_attributes, TA_PERM_ALWAYS);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_handle_set_read_permission(element_attributes, TA_PERM_NEVER);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_handle_set_usage_permission(element_attributes, TA_PERM_ALWAYS);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
    status = talib_handle_set_delete_permission(element_attributes, TA_PERM_ALWAYS);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    return status;
}




//#else

static uint8_t h_nonce[16] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff };

#if defined(ATCA_MBEDTLS) || defined(ATCA_OPENSSL) || defined(ATCA_WOLFSSL)
static uint8_t private_key_pem[] =
    "-----BEGIN EC PRIVATE KEY-----\n"
    "MHcCAQEEICFZhAyzqkUgyheo51bhg3mcp+qwfl+koE+Mhs/sRyzBoAoGCCqGSM49\n"
    "AwEHoUQDQgAExAE2yqujppBzD0hIpdqdXmMgtlXT90QqllaQYWEVBjdf+LmY5DCf\n"
    "Mx8PXEVxhbDmgo6HHbz0S4VaZjShBLMaPw==\n"
    "-----END EC PRIVATE KEY-----\n";
#endif

//uint8_t public_key_bytes[64] = {
//    0xc4, 0x01, 0x36, 0xca, 0xab, 0xa3, 0xa6, 0x90, 0x73, 0x0f, 0x48, 0x48, 0xa5, 0xda, 0x9d, 0x5e,
//    0x63, 0x20, 0xb6, 0x55, 0xd3, 0xf7, 0x44, 0x2a, 0x96, 0x56, 0x90, 0x61, 0x61, 0x15, 0x06, 0x37,
//    0x5f, 0xf8, 0xb9, 0x98, 0xe4, 0x30, 0x9f, 0x33, 0x1f, 0x0f, 0x5c, 0x45, 0x71, 0x85, 0xb0, 0xe6,
//    0x82, 0x8e, 0x87, 0x1d, 0xbc, 0xf4, 0x4b, 0x85, 0x5a, 0x66, 0x34, 0xa1, 0x04, 0xb3, 0x1a, 0x3f
//};

//static uint8_t shared_key[16];

static ta_element_attributes_t tar_attr;
static uint8_t device_public_key[TA_ECC256_PUB_KEY_SIZE];



/** \brief  Call back function used to perform user space functions and used for
 *          input/output. Host side is done in the same hardware
 */
ATCA_STATUS sharekey_cb_hardware(struct sharekey_ctx* ctx, uint8_t step_number, uint8_t* data, size_t data_len, uint8_t* ret_buf, size_t* ret_buf_len)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    uint16_t key_id;
    uint16_t auth_id = AUTH_CONTEXT_ID;
    ta_element_attributes_t attr;

    switch (step_number)
    {
    case SHARE_KEY_STEP_INIT:
        memcpy(key_buf, hmac_key, sizeof(hmac_key));

        status = atca_test_config_get_id(TEST_TYPE_AUTH_HMAC, &key_id);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        status = talib_auth_generate_nonce(atcab_get_device(), auth_id, 0, hmac_i_nonce);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        status = talib_auth_startup(atcab_get_device(), key_id, TA_AUTH_ALG_ID_HMAC, 100,
                                    32, key_buf, hmac_i_nonce, hmac_r_nonce);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;

    case SHARE_KEY_STEP_CREATE_TARGET:
        status = talib_handle_init_share_key_seq_target_key(&attr);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        memcpy(ret_buf, &attr, sizeof(attr));

        status = talib_handle_init_share_key_seq_target_key(&tar_attr);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        status = talib_create_element_with_handle(atcab_get_device(), REMOTE_TARGET_HANDLE, &tar_attr);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;

    case SHARE_KEY_STEP_CREATE_EPHEMERAL:
    {
        ta_element_attributes_t ephe_attr;

        status = talib_handle_init_private_key(&attr, TA_KEY_TYPE_ECCP256,
                                               TA_ALG_MODE_ECC_ECDH, TA_PROP_NO_SIGN_GENERATION,
                                               TA_PROP_KEY_AGREEMENT_OUT_BUFF);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        memcpy(ret_buf, &attr, sizeof(attr));

        status = talib_handle_init_private_key(&ephe_attr, TA_KEY_TYPE_ECCP256,
                                               TA_ALG_MODE_ECC_ECDH, TA_PROP_NO_SIGN_GENERATION,
                                               TA_PROP_KEY_AGREEMENT_OUT_BUFF);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        status = talib_create_ephemeral_element_with_handle(atcab_get_device(),
                                                            TA_CREATE_DETAILS_EPHEMERAL_PRIV_AND_KDF_REQ,
                                                            REMOTE_EPEMERAL_HANDLE, &ephe_attr);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;
    }
    case SHARE_KEY_STEP_RANDOM:
        /* Don't need to do anything with the device's nonce */
        break;

    case SHARE_KEY_STEP_SEQ_REMOTE_NONCE:
        memcpy(ret_buf, h_nonce, TA_SHARE_SEQ_NONCE_LEN);
        break;

    case SHARE_KEY_STEP_KEY_GEN:
        /* Save a copy of the device's public key */
        memcpy(device_public_key, data, data_len);
        break;

    case SHARE_KEY_STEP_SEQ_REMOTE_PUBKEY:
    {
        /* Generating remote public key */
        size_t length = *ret_buf_len;
        status = talib_genkey(atcab_get_device(), REMOTE_EPEMERAL_HANDLE, ret_buf, &length);
        *ret_buf_len = (uint16_t)length;
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;
    }
    case SHARE_KEY_STEP_SIGN:
        /* Ignoring Sign value from the device----------- */
        break;

    case SHARE_KEY_STEP_VERIFY:
    {
        uint16_t sign_length = (uint16_t)*ret_buf_len;
        status = talib_sign_external(atcab_get_device(), TA_SIGN_MODE_EXTERNAL_MSG | TA_KEY_TYPE_ECCP256, REMOTE_SIGN_HANDLE,
                                     TA_HANDLE_INPUT_BUFFER, data, (uint16_t)data_len, ret_buf, &sign_length);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        *ret_buf_len = sign_length;
        break;
    }
    case SHARE_KEY_STEP_ECDH:
        status = talib_ecdh_to_handle(atcab_get_device(), REMOTE_EPEMERAL_HANDLE, REMOTE_EPEMERAL_HANDLE, device_public_key,
                                      TA_ECC256_PUB_KEY_SIZE);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;

    case SHARE_KEY_STEP_KDF:
    {
        uint16_t kdf_length = TA_KEY_TYPE_AES128_SIZE;
        status = talib_kdf_hmac_counter_stored(atcab_get_device(), REMOTE_EPEMERAL_HANDLE, (uint8_t*)TA_SHARE_KEY_SEQ_LABEL,
                                               (uint16_t)strlen(TA_SHARE_KEY_SEQ_LABEL), data, (uint16_t)data_len, REMOTE_TARGET_HANDLE, &kdf_length);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;
    }
    case SHARE_KEY_STEP_TERMINATE:
        status = talib_auth_terminate(atcab_get_device());
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        memset(key_buf, 0, sizeof(key_buf));
        break;

    default:
        break;
    }

    return status;
}

/** \brief  This test case demonstrates the share key sequence using the same device to simulate how a remote
 * host could perform the same operations using a TA100 as well
 */
TEST(talib_cmd_sequence, share_key_sequence_hw)
{
    ATCA_STATUS status = ATCA_GEN_FAIL;
    ATCADevice device = atcab_get_device();
    uint8_t plain_text[16] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A,   0x0B, 0x0C, 0x0D, 0x0E, 0x0F
    };
    uint8_t cipher_text[16];
    uint8_t decrypted_cipher_text[16];
    char message[32];

    /* Share sequence init */
    status = talib_sharekey_sequence_init(device, &ctx, LOCAL_TARGET_HANDLE, LOCAL_EPEMERAL_HANDLE,
                                          LOCAL_SIGN_HANDLE, LOCAL_CERT_HANDLE, TA_KEY_TYPE_AES128_SIZE, TA_SHARE_KEY_SEQ_LOCAL_FIRST, (sharekey_cb_t)sharekey_cb_hardware);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Execute Sharekey Sequence */
    while (ctx.step != SHARE_KEY_STEP_TERMINATE)
    {
        snprintf(message, sizeof(message) - 1, "Step: %d", ctx.step);
        status = talib_sharekey_sequence_execute(&ctx);
        TEST_ASSERT_EQUAL_MESSAGE(ATCA_SUCCESS, status, message);
    }

    /* AUTH_TERMINATE */
    status = talib_sharekey_sequence_terminate(&ctx);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Verify Shared Key using AES Encryption and Decryption */
    memset(cipher_text, 0, sizeof(cipher_text));
    status = talib_aes_keyload(device, TA_AES_MODE_ECB, 0, 0, LOCAL_TARGET_HANDLE);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_aes_ecb(device, TA_AES_MODE_ECB | TA_AES_ACTION_ENCRYPT | TA_AES_UNLOAD,
                           plain_text, cipher_text);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    memset(decrypted_cipher_text, 0, sizeof(decrypted_cipher_text));
    status = talib_aes_keyload(device, TA_AES_MODE_ECB, 0, 0, REMOTE_TARGET_HANDLE);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_aes_ecb(device, TA_AES_MODE_ECB | TA_AES_ACTION_DECRYPT | TA_AES_UNLOAD,
                           cipher_text, decrypted_cipher_text);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(plain_text, decrypted_cipher_text, sizeof(plain_text));
}

#if defined(ATCA_MBEDTLS) || defined(ATCA_OPENSSL) || defined(ATCA_WOLFSSL)

atcac_pk_ctx ephemeral_ctx;
uint8_t local_key[64];
uint8_t hmac_buf[64];

/** \brief  Call back function used to perform user space functions and used for input/out - host side is done in software
 */
ATCA_STATUS sharekey_cb_software(struct sharekey_ctx* ctx, uint8_t step_number, uint8_t* data, size_t data_len, uint8_t* ret_buf, size_t* ret_buf_len)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    uint16_t key_id;
    uint16_t auth_id = AUTH_CONTEXT_ID;
    ta_element_attributes_t attr;

    switch (step_number)
    {
    case SHARE_KEY_STEP_INIT:
        memcpy(key_buf, hmac_key, sizeof(hmac_key));

        status = atca_test_config_get_id(TEST_TYPE_AUTH_HMAC, &key_id);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        status = talib_auth_generate_nonce(atcab_get_device(), auth_id, 0, hmac_i_nonce);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        status = talib_auth_startup(atcab_get_device(), key_id, TA_AUTH_ALG_ID_HMAC, 100,
                                    32, key_buf, hmac_i_nonce, hmac_r_nonce);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;

    case SHARE_KEY_STEP_CREATE_TARGET:
        status = talib_handle_init_share_key_seq_target_key(&attr);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        memcpy(ret_buf, &attr, sizeof(attr));
        break;

    case SHARE_KEY_STEP_CREATE_EPHEMERAL:
        /* Configure the attributes for the ephemeral key */
        status = talib_handle_init_private_key(&attr, TA_KEY_TYPE_ECCP256,
                                               TA_ALG_MODE_ECC_ECDH, TA_PROP_NO_SIGN_GENERATION,
                                               TA_PROP_KEY_AGREEMENT_OUT_BUFF);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        memcpy(ret_buf, &attr, sizeof(attr));

        /* Create/Initialize a local EC key */
        status = atcac_pk_init_pem(&ephemeral_ctx, private_key_pem, sizeof(private_key_pem), false);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        break;
    case SHARE_KEY_STEP_RANDOM:
        /* Don't need to do anything with the device's nonce */
        break;

    case SHARE_KEY_STEP_SEQ_REMOTE_NONCE:
        /* Return the host side nonce */
        memcpy(ret_buf, h_nonce, TA_SHARE_SEQ_NONCE_LEN);
        break;

    case SHARE_KEY_STEP_KEY_GEN:
        /* Save a copy of the device's public key */
        memcpy(device_public_key, data, data_len);
        break;

    case SHARE_KEY_STEP_SEQ_REMOTE_PUBKEY:
        /* Send the host side public key */
        status = atcac_pk_public(&ephemeral_ctx, ret_buf, ret_buf_len);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;

    case SHARE_KEY_STEP_SIGN:
        /* Ignoring Sign value from the device - host optionally could verify the signature to authenticate the device */
        break;

    case SHARE_KEY_STEP_VERIFY:
    {
        /* Sign the context digest with the host's key and return the signature */
        atcac_pk_ctx priv_ctx;
        status = atcac_pk_init(&priv_ctx, test_ecc_remote_cert_priv_key, sizeof(test_ecc_remote_cert_priv_key), 0, false);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

        status = atcac_pk_sign(&priv_ctx, data, data_len, ret_buf, ret_buf_len);
        (void)atcac_pk_free(&priv_ctx);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;
    }
    case SHARE_KEY_STEP_ECDH:
    {
        atcac_pk_ctx device_ephemeral_ctx;
        atcac_pk_init(&device_ephemeral_ctx, device_public_key, 64, 0, true);
        size_t local_key_size = 32;

        status = atcac_pk_derive(&ephemeral_ctx, &device_ephemeral_ctx, local_key, &local_key_size);
        atcac_pk_free(&ephemeral_ctx);
        atcac_pk_free(&device_ephemeral_ctx);

        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;
    }
    case SHARE_KEY_STEP_KDF:
    {
        /* Perform the host side HMAC KDF */
        atcac_hmac_sha256_ctx hmac_ctx;
        (void)atcac_sha256_hmac_init(&hmac_ctx, local_key, 32);

        status = atcac_sha256_hmac_counter(&hmac_ctx, TA_SHARE_KEY_SEQ_LABEL, strlen(TA_SHARE_KEY_SEQ_LABEL), data, data_len, local_key, 16);
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        break;
    }
    case SHARE_KEY_STEP_TERMINATE:
        status = talib_auth_terminate(atcab_get_device());
        TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
        memset(key_buf, 0, sizeof(key_buf));
        break;

    default:
        break;
    }

    return status;
}

/** \brief  This demonstrates the share key sequence using software crypto on the host
 *          .
 */
TEST(talib_cmd_sequence, share_key_sequence_sw)
{
    ATCA_STATUS status = ATCA_GEN_FAIL;
    ATCADevice device = atcab_get_device();
    uint8_t message[32];

    /* Share sequence init */
    status = talib_sharekey_sequence_init(device, &ctx, LOCAL_TARGET_HANDLE, LOCAL_EPEMERAL_HANDLE,
                                          LOCAL_SIGN_HANDLE, LOCAL_CERT_HANDLE, TA_KEY_TYPE_AES128_SIZE, TA_SHARE_KEY_SEQ_LOCAL_FIRST, (sharekey_cb_t)sharekey_cb_software);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Execute Sharekey Sequence */
    while (ctx.step != SHARE_KEY_STEP_TERMINATE)
    {
        snprintf(message, sizeof(message) - 1, "Step: %d", ctx.step);
        status = talib_sharekey_sequence_execute(&ctx);
        TEST_ASSERT_EQUAL_MESSAGE(ATCA_SUCCESS, status, message);
    }

    /* AUTH_TERMINATE */
    status = talib_sharekey_sequence_terminate(&ctx);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_auth_generate_nonce(device, 0x4100, 0, hmac_i_nonce);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_auth_startup(device, LOCAL_TARGET_HANDLE, TA_AUTH_ALG_ID_CMAC, 10, 16, local_key, hmac_i_nonce, hmac_r_nonce);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Execute a nested commands */
    status = talib_info(device, message);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    /* Include tx data */
    status = talib_random(device, hmac_i_nonce, message, 8);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_auth_terminate(device);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
}
#endif

/* *INDENT-OFF* - Preserve formatting */
t_test_case_info talib_sequence_basic_test_info[] =
{
    { REGISTER_TEST_CASE(talib_cmd_sequence, share_key_sequence_hw),            DEVICE_MASK(TA100) },
#if defined(ATCA_MBEDTLS) || defined(ATCA_OPENSSL) || defined(ATCA_WOLFSSL)
    { REGISTER_TEST_CASE(talib_cmd_sequence, share_key_sequence_sw),            DEVICE_MASK(TA100) },
#endif
    { (fp_test_case)NULL,                     (uint8_t)0 },   /* Array Termination element*/
};
/* *INDENT-OFN* */

t_test_case_info* talib_sequence_tests[] = {
    talib_sequence_basic_test_info,
    /* Array Termination element */
    (t_test_case_info*)NULL
};

#endif
