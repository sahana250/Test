/**
 * \file
 * \brief Basic test for Random command api - TA100
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "atca_test.h"
#include "test_talib.h"

#if ATCA_TA_SUPPORT && defined(ATCA_TA100_FCE_SUPPORT)

#include "talib/talib_fce.h"

#define FCE_HMAC_KEY_HANDLE 0X8109
#define FCE_CMAC_KEY_HANDLE 0X81A0

static ta_element_attributes_t attr_fce_hmac_key = { 0x46, 0x0000, 0, 0, 0, 0x55, 8 };
static ta_element_attributes_t attr_fce_cmac_key = { 0x66, 0x0600, 0, 0, 0, 0x55, 8 };
uint8_t fce_hmac_key[] = { 0xA2, 0x26, 0xE1, 0x65, 0x69, 0x01, 0x80, 0xEB, 0x1A, 0x0C, 0x9C,   0x5B, 0x64, 0x5E, 0x42, 0x02,
                           0xFA, 0x2F, 0x4F, 0xFD, 0x68, 0x75, 0xFA, 0x2F, 0x4F, 0xFD, 0x68,   0x75, 0xFA, 0x2F, 0x4F, 0xFD, };

uint8_t fce_cmac_key[] = { 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,   0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C };

TEST_GROUP(talib_fce_sha);
TEST_SETUP(talib_fce_sha)
{
    UnityMalloc_StartTest();

    ATCA_STATUS status = atcab_init(gCfg);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
}

TEST_TEAR_DOWN(talib_fce_sha)
{
    UnityMalloc_EndTest();
}

/** \brief Execute SHA operation using Fast Crypto Engine with start, update and end mode and verify
 *   the final digest with known digest
 */
TEST(talib_fce_sha, sha_split_call)
{
    ATCA_STATUS status;
    ATCADevice device = atcab_get_device();
    fce_ctx_t ctx;
    uint8_t message[129] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00 };
    uint8_t ref_digest[32] = { 0x9e, 0x8f, 0x6c, 0x56, 0x08, 0x25, 0xc5, 0x7f, 0xcd, 0xdf, 0x2d,   0x74, 0x83, 0x1f, 0x7d, 0x6c,
                               0xc8, 0xe6, 0x61, 0x67, 0x45, 0x2f, 0x3c, 0x92, 0x2b, 0xf0, 0x43,   0xab, 0x3f, 0x41, 0x6a, 0xff };
    uint8_t digest[32];

    ctx.device = device;
    status = talib_fce_sha_start(&ctx);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_sha_update(&ctx, &message[0], 16, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_sha_update(&ctx, &message[16], 16, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_sha_update(&ctx, &message[32], 32, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_sha_update(&ctx, &message[64], 64, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_sha_update(&ctx, &message[128], 1, true);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_sha_finish(&ctx, digest);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(ref_digest, digest, sizeof(digest));
}

/** \brief Execute SHA operation using Fast Crypto Engine with single call and verify
 *   the final digest with known digest
 */
TEST(talib_fce_sha, sha_single_call)
{
    ATCA_STATUS status;
    ATCADevice device = atcab_get_device();
    uint8_t message[129] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00 };
    uint8_t ref_digest[32] = { 0x9e, 0x8f, 0x6c, 0x56, 0x08, 0x25, 0xc5, 0x7f, 0xcd, 0xdf, 0x2d,   0x74, 0x83, 0x1f, 0x7d, 0x6c,
                               0xc8, 0xe6, 0x61, 0x67, 0x45, 0x2f, 0x3c, 0x92, 0x2b, 0xf0, 0x43,   0xab, 0x3f, 0x41, 0x6a, 0xff };
    uint8_t digest[32];

    status = talib_fce_sha(device, message, 129, digest);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(ref_digest, digest, sizeof(digest));
}

TEST_GROUP(talib_fce_hmac);
TEST_SETUP(talib_fce_hmac)
{
    UnityMalloc_StartTest();

    ATCA_STATUS status = atcab_init(gCfg);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
}

TEST_TEAR_DOWN(talib_fce_hmac)
{
    (void)talib_delete_handle(atcab_get_device(), FCE_HMAC_KEY_HANDLE);

    UnityMalloc_EndTest();
}

/** \brief Execute HMAC operation using Fast Crypto Engine with start, update and end mode and verify
 *   the final mac with known mac
 */
TEST(talib_fce_hmac, hmac_split_call)
{
    ATCA_STATUS status;
    ATCADevice device = atcab_get_device();
    uint8_t message[129] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00 };
    uint8_t ref_hmac[32] = { 0x4d, 0x83, 0x66, 0x6e, 0xaa, 0x69, 0x57, 0xe8, 0xab, 0x67, 0xac,   0x32, 0x6c, 0x88, 0xb3, 0xa3,
                             0x77, 0xf9, 0xd4, 0x34, 0x5d, 0x7a, 0x29, 0xa2, 0x66, 0x27, 0xdd,   0x64, 0xea, 0x46, 0x7b, 0x63 };
    uint8_t hmac[32];
    uint32_t written_map;
    fce_ctx_t ctx;

    ctx.device = device;
    status = talib_create_hmac_element_with_handle(ctx.device, sizeof(fce_hmac_key), FCE_HMAC_KEY_HANDLE, &attr_fce_hmac_key);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    // Write HMAC keys into handle
    status = atcab_write_bytes_zone(ATCA_ZONE_DATA, FCE_HMAC_KEY_HANDLE, 0, fce_hmac_key, sizeof(fce_hmac_key));
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_start(&ctx, TA_FCCONFIG_MAC_ALL_KEYS_MODE, FCE_HMAC_KEY_HANDLE, 0, &written_map);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_update(&ctx, &message[0], 16, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_update(&ctx, &message[16], 16, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_update(&ctx, &message[32], 32, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_update(&ctx, &message[64], 64, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_update(&ctx, &message[128], 1, true);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac_finish(&ctx, hmac);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(ref_hmac, hmac, sizeof(hmac));
}

/** \brief Execute HMAC operation using Fast Crypto Engine with single call and verify
 *   the final mac with known mac
 */
TEST(talib_fce_hmac, hmac_single_call)
{
    ATCA_STATUS status;
    ATCADevice device = atcab_get_device();
    uint8_t message[129] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00 };
    uint8_t ref_hmac[32] = { 0x4d, 0x83, 0x66, 0x6e, 0xaa, 0x69, 0x57, 0xe8, 0xab, 0x67, 0xac,   0x32, 0x6c, 0x88, 0xb3, 0xa3,
                             0x77, 0xf9, 0xd4, 0x34, 0x5d, 0x7a, 0x29, 0xa2, 0x66, 0x27, 0xdd,   0x64, 0xea, 0x46, 0x7b, 0x63 };
    uint8_t hmac[32];
    uint32_t written_map;

    status = talib_create_hmac_element_with_handle(device, sizeof(fce_hmac_key), FCE_HMAC_KEY_HANDLE, &attr_fce_hmac_key);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    // Write HMAC keys into handle
    status = atcab_write_bytes_zone(ATCA_ZONE_DATA, FCE_HMAC_KEY_HANDLE, 0, fce_hmac_key, sizeof(fce_hmac_key));
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_hmac(device, TA_FCCONFIG_MAC_ALL_KEYS_MODE, FCE_HMAC_KEY_HANDLE, 0, &written_map, message, 129, hmac);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(ref_hmac, hmac, sizeof(hmac));
}

TEST_GROUP(talib_fce_cmac);
TEST_SETUP(talib_fce_cmac)
{
    UnityMalloc_StartTest();

    ATCA_STATUS status = atcab_init(gCfg);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);
}

TEST_TEAR_DOWN(talib_fce_cmac)
{
    (void)talib_delete_handle(atcab_get_device(), FCE_CMAC_KEY_HANDLE);

    UnityMalloc_EndTest();
}

/** \brief Execute CMAC operation using Fast Crypto Engine with start, update and end mode and verify
 *   the final mac with known mac
 */
TEST(talib_fce_cmac, cmac_split_call)
{
    ATCA_STATUS status;
    ATCADevice device = atcab_get_device();
    uint8_t message[129] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00 };
    uint8_t ref_cmac[16] = { 0x42, 0xb3, 0x6d, 0x71, 0xf2, 0x0b, 0xa1, 0x89,   0x76, 0x53, 0x21, 0x29, 0x77, 0x50, 0xd9, 0xbe };
    uint8_t cmac[16];
    uint32_t written_map;
    fce_ctx_t ctx;

    ctx.device = device;
    status = talib_create_element_with_handle(ctx.device, FCE_CMAC_KEY_HANDLE, &attr_fce_cmac_key);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    // Write HMAC keys into handle
    status = atcab_write_bytes_zone(ATCA_ZONE_DATA, FCE_CMAC_KEY_HANDLE, 0, fce_cmac_key, sizeof(fce_cmac_key));
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_start(&ctx, TA_FCCONFIG_MAC_ALL_KEYS_MODE, FCE_CMAC_KEY_HANDLE, 0, &written_map);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_update(&ctx, &message[0], 16, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_update(&ctx, &message[16], 16, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_update(&ctx, &message[32], 32, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_update(&ctx, &message[64], 64, false);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_update(&ctx, &message[128], 1, true);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac_finish(&ctx, cmac);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(ref_cmac, cmac, sizeof(cmac));
}

/** \brief Execute CMAC operation using Fast Crypto Engine with single call and verify
 *   the final mac with known mac
 */
TEST(talib_fce_cmac, cmac_single_call)
{
    ATCA_STATUS status;
    ATCADevice device = atcab_get_device();
    uint8_t message[129] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,   0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                             0x00 };
    uint8_t ref_cmac[16] = { 0x42, 0xb3, 0x6d, 0x71, 0xf2, 0x0b, 0xa1, 0x89,   0x76, 0x53, 0x21, 0x29, 0x77, 0x50, 0xd9, 0xbe };
    uint8_t cmac[16];
    uint32_t written_map;

    status = talib_create_element_with_handle(device, FCE_CMAC_KEY_HANDLE, &attr_fce_cmac_key);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    // Write HMAC keys into handle
    status = atcab_write_bytes_zone(ATCA_ZONE_DATA, FCE_CMAC_KEY_HANDLE, 0, fce_cmac_key, sizeof(fce_cmac_key));
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    status = talib_fce_cmac(device, TA_FCCONFIG_MAC_ALL_KEYS_MODE, FCE_CMAC_KEY_HANDLE, 0, &written_map, message, 129, cmac);
    TEST_ASSERT_EQUAL(ATCA_SUCCESS, status);

    TEST_ASSERT_EQUAL_MEMORY(ref_cmac, cmac, sizeof(cmac));
}

t_test_case_info talib_fastcrypto_basic_test_info[] =
{
    { REGISTER_TEST_CASE(talib_fce_sha,  sha_split_call),   DEVICE_MASK(TA100)                },
    { REGISTER_TEST_CASE(talib_fce_sha,  sha_single_call),  DEVICE_MASK(TA100)                },
    { REGISTER_TEST_CASE(talib_fce_hmac, hmac_split_call),  DEVICE_MASK(TA100)                },
    { REGISTER_TEST_CASE(talib_fce_hmac, hmac_single_call), DEVICE_MASK(TA100)                },
    { REGISTER_TEST_CASE(talib_fce_cmac, cmac_split_call),  DEVICE_MASK(TA100)                },
    { REGISTER_TEST_CASE(talib_fce_cmac, cmac_single_call), DEVICE_MASK(TA100)                },
    { (fp_test_case)NULL,                (uint8_t)0 },      /* Array Termination element*/
};

t_test_case_info* talib_fastcrypto_tests[] = {
    talib_fastcrypto_basic_test_info,
    /* Array Termination element */
    (t_test_case_info*)NULL
};

int talib_fce_cmd(int argc, char* argv[])
{
    ATCADevice device;
    ATCA_STATUS status;
    uint32_t written_map;
    uint8_t * message = NULL;
    size_t mlen = 0;
    uint8_t digest[32];

    atcab_init(gCfg);
    device = atcab_get_device();

    if (3 == argc)
    {
        FILE * fp = fopen(argv[2], "r");
        if (fp)
        {
            fseek(fp, 0, SEEK_END);
            mlen = ftell(fp);
            fseek(fp, 0, SEEK_SET);
            message = hal_malloc(mlen);
            if (message)
            {
                fread(message, 1, mlen, fp);
            }
            fclose(fp);
        }
    }

    if (0 == strcmp("hmac", argv[1]))
    {
        if (ATCA_SUCCESS != (status = talib_create_hmac_element_with_handle(device, sizeof(fce_hmac_key), FCE_HMAC_KEY_HANDLE, &attr_fce_hmac_key)))
        {
            printf("talib_create_hmac_element_with_handle: %x\n", status);
        }

        if (ATCA_SUCCESS != (status = atcab_write_bytes_zone(ATCA_ZONE_DATA, FCE_HMAC_KEY_HANDLE, 0, fce_hmac_key, sizeof(fce_hmac_key))))
        {
            printf("atcab_write_bytes_zone: %x\n", status);
        }

        if (ATCA_SUCCESS == (status = talib_fce_hmac(device, TA_FCCONFIG_MAC_ALL_KEYS_MODE, FCE_HMAC_KEY_HANDLE, 0, &written_map, message, mlen, digest)))
        {
            for (int i = 0; i < 32; i++)
            {
                printf("%02x", digest[i]);
            }
            printf("\n");
        }
        else
        {
            printf("talib_fce_hmac: %x\n", status);
        }
    }
    else if (0 == strcmp("cmac", argv[1]))
    {
        if (ATCA_SUCCESS != (status = talib_create_element_with_handle(device, FCE_CMAC_KEY_HANDLE, &attr_fce_cmac_key)))
        {
            printf("talib_create_element_with_handle: %x\n", status);
        }

        if (ATCA_SUCCESS != (status = atcab_write_bytes_zone(ATCA_ZONE_DATA, FCE_CMAC_KEY_HANDLE, 0, fce_cmac_key, sizeof(fce_cmac_key))))
        {
            printf("atcab_write_bytes_zone: %x\n", status);
        }

        if (ATCA_SUCCESS == (status = talib_fce_cmac(device, TA_FCCONFIG_MAC_ALL_KEYS_MODE, FCE_CMAC_KEY_HANDLE, 0, &written_map, message, mlen, digest)))
        {
            for (int i = 0; i < 16; i++)
            {
                printf("%02x", digest[i]);
            }
            printf("\n");
        }
        else
        {
            printf("talib_fce_cmac: %x\n", status);
        }

    }
    else if (0 == strcmp("sha", argv[1]))
    {
        if (ATCA_SUCCESS == (status = talib_fce_sha(device, message, mlen, digest)))
        {
            for (int i = 0; i < 32; i++)
            {
                printf("%02x", digest[i]);
            }
            printf("\n");
        }
    }
    else
    {
        return -1;
    }

    if (message)
    {
        hal_free(message);
    }
    return status;
}

#endif
