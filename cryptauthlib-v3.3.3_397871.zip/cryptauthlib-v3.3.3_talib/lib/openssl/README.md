openssl directory - Purpose
===========================
This directory contains the interfacing and wrapper functions to
integrate openssl as the software crypto library.

