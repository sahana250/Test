/**
 * \file
 * \brief Basic Secureboot commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Execute secureboot command with full asymmetric mode.
 *                  signature is validated against extracted certificates or
 *                  secure boot public key
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  pub_handle        Handle for the validating public key which must be a
 *                                root key or extracted certificate element
 *  \param[in]  digest            Input digest
 *  \param[in]  signature         Input code signature
 *  \param[in]  sig_len           length of the input signature
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_secureboot_full_asymmetric(ATCADevice device, const uint16_t dig_handle,
                                             const uint16_t pub_handle, const uint8_t* digest,
                                             const uint8_t* signature, const size_t sig_len,
                                             bool* is_validated)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;

    if ((NULL == device) || (NULL == signature))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if ((sig_len != TA_SIGN_P256_SIG_SIZE) && (sig_len != TA_SIGN_RSA2048_SIG_SIZE) &&
        (sig_len != TA_SIGN_RSA3072_SIG_SIZE))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "Invalid signature length received");
    }

    if (NULL == (packet = (talib_packet_alloc())))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = TA_SECUREBOOT_MODE_FULL_ASYMMETRIC;
    packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(dig_handle);
    packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(pub_handle);
    data = packet->data;

    // copy the digest into input stream
    if (TA_HANDLE_INPUT_BUFFER == dig_handle)
    {
        if (digest)
        {
            memcpy(data, digest, TA_SHA256_DIGEST_SIZE);
            data += TA_SHA256_DIGEST_SIZE;
        }
        else
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
        }
    }

    /* Send the resulting packet */
    if (ATCA_SUCCESS == status)
    {
        // copy the input code signature into input stream
        memcpy(data, signature, sig_len);
        data += sig_len;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        /* Process the response */
        if (ATCA_SUCCESS == (status = talib_execute_command(packet, device)))
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint8_t resp_length = (uint8_t)(ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH);
            if (resp_length && is_validated)
            {
                *is_validated = resp_packet->data[0];
            }
        }
    }

    talib_packet_free(packet);

    return status;
}

/** \brief TA API - Execute secure boot command preset phase mode for full stored,
 *                  partial and pre boot config mode.
 *                  This phase allocates the necessary space for the stored digest
 *                  in the secureboot handle.
 *
 *  \param[in]  device        device context pointer
 *  \param[in]  mode          determine full store or partial or pre-boot
 *                            For full stored, 0x10
 *                            For partial, 0x20
 *                            For pre-boot, 0x40
 *  \param[in]  dig_handle    handle for the code digest.
 *                            For full stored and pre-boot, it is always 0x4800
 *                            For partial, it is always 0x0000
 *  \param[in]  param         determine digest present in io buffer or not
 *                            For full stored and pre-boot, it is either 0x0001 or 0x0000
 *                            For partial, it is always 0x0000
 *  \param[in]  digest        input code digest
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_preset(ATCADevice device, const uint8_t mode, const uint16_t
                                    dig_handle, const uint16_t param, const uint8_t* digest)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;

    if (NULL == device)
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if (NULL == (packet = (talib_packet_alloc())))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = mode;
    packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(dig_handle);
    packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(param);
    data = packet->data;

    if (param)
    {
        if (digest)
        {
            // copy the digest into input stream
            memcpy(data, digest, TA_SHA256_DIGEST_SIZE);
            data += TA_SHA256_DIGEST_SIZE;
        }
        else
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
        }
    }

    /* send the resulting packet */
    if (ATCA_SUCCESS == status)
    {
        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = talib_execute_command(packet, device);
    }

    talib_packet_free(packet);

    return status;

}

/** \brief TA API - Execute secureboot command with update phase mode for full stored and pre-boot
 *                  For partial config mode, this phase is similar with complete phase
 *                  This phase writes a new digest to the special handle allocated
 *                  during the Preset phase
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  mode              determine config mode
 *                                For full stored, 0x11
 *                                For partial, 0x24
 *                                For pre-boot, 0x41
 *  \param[in]  dig_handle        Handle for the code digest
 *                                For partial, 0x0000
 *  \param[in]  pub_handle        Handle for the validating public key which must be a
 *                                root key or extracted certificate element
 *  \param[in]  digest            Input digest
 *                                For partial, no input digest required
 *  \param[in]  signature         Input code signature
 *  \param[in]  sig_len           length of the input signature
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_secureboot_update(ATCADevice device, const uint8_t mode, const uint16_t
                                    dig_handle, const uint16_t pub_handle, const uint8_t* digest,
                                    const uint8_t* signature, const size_t sig_len,
                                    bool* is_validated)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;

    if ((NULL == device) || (NULL == signature))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if ((sig_len != TA_SIGN_P256_SIG_SIZE) && (sig_len != TA_SIGN_RSA2048_SIG_SIZE) &&
        (sig_len != TA_SIGN_RSA3072_SIG_SIZE))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "Invalid signature length received");

    }

    if (NULL == (packet = (talib_packet_alloc())))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = mode;
    packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(dig_handle);
    packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(pub_handle);
    data = packet->data;

    // copy the digest into input stream
    if (TA_HANDLE_INPUT_BUFFER == dig_handle)
    {
        if (digest)
        {
            memcpy(data, digest, TA_SHA256_DIGEST_SIZE);
            data += TA_SHA256_DIGEST_SIZE;
        }
        else
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
        }
    }

    /* send the resulting packet */
    if (ATCA_SUCCESS == status)
    {
        // copy the input code signature into input stream
        memcpy(data, signature, sig_len);
        data += sig_len;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        if (ATCA_SUCCESS == (status = talib_execute_command(packet, device)))
        {
            /* process the response */
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint8_t resp_length = (uint8_t)(ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH);
            if (resp_length && is_validated)
            {
                *is_validated = resp_packet->data[0];
            }
        }
    }

    talib_packet_free(packet);

    return status;
}

/** \brief TA API - Execute secureboot command with boot phase mode for full store,
 *                  partial and pre boot config mode.
 *                  Validate the code digest from the host against stored digest
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  mode              Determine config mode
 *                                For full store, 0x12
 *                                For partial, 0x26
 *                                For pre boot, 0x42
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  digest            input code digest
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_boot(ATCADevice device, const uint8_t mode, const uint16_t dig_handle,
                                  const uint8_t* digest, bool* is_validated)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;

    if (NULL == device)
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if (NULL == (packet = (talib_packet_alloc())))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = mode;
    packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(dig_handle);
    packet->param2.val16[1] = 0;
    data = packet->data;

    if (TA_HANDLE_INPUT_BUFFER == dig_handle)
    {
        if (digest)
        {
            // copy the digest into input stream
            memcpy(packet->data, digest, TA_SHA256_DIGEST_SIZE);
            data += TA_SHA256_DIGEST_SIZE;
        }
        else
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
        }
    }

    /* Send the resulting packet */
    if (ATCA_SUCCESS == status)
    {
        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        if (ATCA_SUCCESS == (status = talib_execute_command(packet, device)))
        {
            /* process the response */
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint8_t resp_length = (uint8_t)(ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH);
            if (resp_length && is_validated)
            {
                *is_validated = resp_packet->data[0];
            }
        }
    }

    talib_packet_free(packet);

    return status;
}

/** \brief TA API - Execute secure boot command preset phase mode for full stored
 *                  config mode.
 *                  This phase allocates the necessary space for the stored digest
 *                  in the secureboot handle.
 *
 *  \param[in]  device        device context pointer
 *  \param[in]  digest        input code digest
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_fullstore_preset(ATCADevice device, const uint8_t* digest)
{
    uint16_t param = 0x0000;

    if (digest)
    {
        param = 0x0001;
    }

    return talib_secureboot_preset(device, TA_SECUREBOOT_MODE_FULLSTORE_PRESET,
                                   TA_HANDLE_INPUT_BUFFER, param, digest);
}

/** \brief TA API - Execute secureboot command with update phase mode for full stored
 *                  config mode.
 *                  This phase writes a new digest to the special handle allocated
 *                  during the Preset phase
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  pub_handle        Handle for the validating public key which must be a
 *                                root key or extracted certificate element
 *  \param[in]  digest            Input digest
 *  \param[in]  signature         Input code signature
 *  \param[in]  sig_len           length of the input signature
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_secureboot_fullstore_update(ATCADevice device, const uint16_t dig_handle,
                                              const uint16_t pub_handle, const uint8_t* digest,
                                              const uint8_t* signature, const size_t sig_len,
                                              bool* is_validated)
{
    return talib_secureboot_update(device, TA_SECUREBOOT_MODE_FULLSTORE_UPDATE, dig_handle,
                                   pub_handle, digest, signature, sig_len, is_validated);
}

/** \brief TA API - Execute secureboot command with boot phase mode for full store config mode.
 *                  Validate the code digest from the host against stored digest
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  digest            input code digest
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_fullstore_boot(ATCADevice device, const uint16_t dig_handle,
                                            const uint8_t* digest, bool* is_validated)
{
    return talib_secureboot_boot(device, TA_SECUREBOOT_MODE_FULLSTORE_BOOT, dig_handle,
                                 digest, is_validated);
}

/** \brief TA API - Execute secure boot command preset phase mode for partial
 *                  config mode.
 *                  This phase allocates the necessary space for the stored digest
 *                  in the secureboot handle.
 *
 *  \param[in]  device        device context pointer
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_preset(ATCADevice device)
{
    return talib_secureboot_preset(device, TA_SECUREBOOT_MODE_PARTIAL_PRESET,
                                   0x0000, 0x0000, NULL);
}

/** \brief TA API - Execute secure boot command for setup phase in partial config mode
 *                  This phase initializes the code update sequence
 *
 *  \param[in]   device             device context pointer
 *  \param[in]   code_size          Total size of the code over
 *                                  which the signature was generated
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_setup(ATCADevice device, const uint32_t code_size)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;

    if (NULL == device)
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if (NULL == (packet = talib_packet_alloc()))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = TA_SECUREBOOT_MODE_PARTIAL_SETUP;
    packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(code_size);

    //Update length including length, opcode, param1, param2 and CRC
    packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

    /* Send the resulting packet */
    status = talib_execute_command(packet, device);

    talib_packet_free(packet);

    return status;

}

/** \brief TA API - Execute Secureboot command in partial config mode to update the code
 *                  Pass a full SHA256 (64 byte) block of code to the Vega device as part of
 *                  the overall code load/upgrade procedure.
 *                  This phase is run repeatedly till the final full or partial block has been sent.
 *
 *  \param[in]   device         device context pointer
 *  \param[in]   mode           determine initial block or final block
 *  \param[in]   code           Subsequent block of operating code bytes
 *  \param[in]   code_size      size of the operating code
 *
 *  \return ATCA_SUCCES on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_code_base(ATCADevice device, const uint8_t mode, const uint8_t*
                                               code, const size_t code_size)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;

    if ((NULL == device) || (NULL == code) || (code_size <= 0))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid length received");
    }

    if ((TA_SECUREBOOT_MODE_PARTIAL_CODE == mode) &&
        (TA_SECUREBOOT_PARTIAL_CODE_SIZE_MAX != code_size))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "Invalid code size received");
    }

    if ((TA_SECUREBOOT_MODE_PARTIAL_FINAL == mode) &&
        (code_size > TA_SECUREBOOT_PARTIAL_CODE_SIZE_MAX))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "Invalid code size received");
    }

    if (NULL == (packet = talib_packet_alloc()))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = mode;
    packet->param2.val32 = 0;

    // copy code into input stream
    memcpy(packet->data, code, code_size);

    //Update length including length, opcode, param1, param2 and CRC
    packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)code_size + ATCA_CMD_BUILD_MIN_LENGTH);

    /* send the resulting packet */
    status = talib_execute_command(packet, device);

    talib_packet_free(packet);

    return status;

}

/** \brief TA API - Execute Secureboot command in partial config mode to update the initial code
 *                  Pass a full SHA256 (64 byte) block of code to the Vega device as part of
 *                  the overall code load/upgrade procedure.
 *                  This phase is run repeatedly till before the final full or partial block
 *                  has been sent.
 *
 *  \param[in]   device         device context pointer
 *  \param[in]   code           Subsequent block of operating code bytes
 *                                  Data must be of 64 bytes
 *
 *  \return ATCA_SUCCES on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_code(ATCADevice device, const uint8_t* code)
{
    return talib_secureboot_partial_code_base(device, TA_SECUREBOOT_MODE_PARTIAL_CODE, code,
                                              TA_SECUREBOOT_PARTIAL_CODE_SIZE_MAX);
}

/** \brief TA API - Execute Secureboot command in partial config mode to update the final code
 *                  This phase update the final code block
 *
 *  \param[in]   device         device context pointer
 *  \param[in]   code           Subsequent block of operating code bytes
 *  \param[in]   code_size      size of the operating code
 *
 *  \return ATCA_SUCCES on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_final(ATCADevice device, const uint8_t* code, const size_t
                                           code_size)
{
    return talib_secureboot_partial_code_base(device, TA_SECUREBOOT_MODE_PARTIAL_FINAL, code,
                                              code_size);
}

/** \brief TA API - Execute secureboot command in partial config mode of complete phase
 *                  This phase verifies the signature and updated the partial digests
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  pub_handle        Handle for the validating public key which must be a
 *                                root key or extracted certificate element
 *  \param[in]  signature         Input code signature
 *  \param[in]  sig_len           length of the input signature
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_secureboot_partial_complete(ATCADevice device, const uint16_t pub_handle, const
                                              uint8_t* signature, const size_t sig_len,
                                              bool* is_validated)
{
    return talib_secureboot_update(device, TA_SECUREBOOT_MODE_PARTIAL_COMPLETE, 0x0000,
                                   pub_handle, NULL, signature, sig_len, is_validated);
}

/** \brief TA API - Execute secureboot command in partial config mode of address phase
 *                  This pahse retrieve address min/max bounds from the Vega device.
 *
 *  \param[in]   device    device context pointer
 *  \param[out]  begin     The begin address (inclusive) for the current portion over
 *                         which host should calculate digest
 *  \param[out]  end       The ending address (inclusive) for the current portion
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_address(ATCADevice device, uint32_t* const begin, uint32_t*
                                             const end)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;

    if ((NULL == device) || (NULL == begin) || (NULL == end))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if (NULL == (packet = talib_packet_alloc()))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = TA_SECUREBOOT_MODE_PARTIAL_ADDRESS;
    packet->param2.val32 = 0;

    //Update length including length, opcode, param1, param2 and CRC
    packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

    /* send the resulting packet */
    if (ATCA_SUCCESS == (status = talib_execute_command(packet, device)))
    {
        ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
        size_t rsp_len = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

        if (rsp_len == (TA_SECUREBOOT_PARTIAL_ADDRESS_BEGIN_SIZE +
                        TA_SECUREBOOT_PARTIAL_ADDRESS_END_SIZE))
        {
            // copy begin address
            memcpy((uint8_t*)begin, &resp_packet->data[0], TA_SECUREBOOT_PARTIAL_ADDRESS_BEGIN_SIZE);
            *begin = ATCA_UINT32_BE_TO_HOST(*begin);

            // copy end address
            memcpy((uint8_t*)end, &resp_packet->data[TA_SECUREBOOT_PARTIAL_ADDRESS_BEGIN_SIZE],
                   TA_SECUREBOOT_PARTIAL_ADDRESS_END_SIZE);
            *end = ATCA_UINT32_BE_TO_HOST(*end);
        }
    }

    talib_packet_free(packet);

    return status;

}

/** \brief TA API - Execute secureboot command with boot phase mode for partial config mode.
 *                  Validate the code digest from the host against stored digest
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  digest            input code digest
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_partial_boot(ATCADevice device, const uint16_t dig_handle,
                                          const uint8_t* digest, bool* is_validated)
{
    return talib_secureboot_boot(device, TA_SECUREBOOT_MODE_PARTIAL_BOOT, dig_handle,
                                 digest, is_validated);
}

/** \brief TA API - Execute secure boot command preset phase mode for pre boot
 *                  config mode.
 *                  This phase allocates the necessary space for the stored digest
 *                  in the secureboot handle.
 *
 *  \param[in]  device        device context pointer
 *  \param[in]  digest        input code digest
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_preboot_preset(ATCADevice device, const uint8_t* digest)
{
    uint16_t param = 0x0000;

    if (digest)
    {
        param = 0x0001;
    }

    return talib_secureboot_preset(device, TA_SECUREBOOT_MODE_PREBOOT_PRESET,
                                   TA_HANDLE_INPUT_BUFFER, param, digest);
}

/** \brief TA API - Execute secureboot command with update phase mode for pre boot
 *                  config mode.
 *                  This phase writes a new digest to the special handle allocated
 *                  during the Preset phase
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  pub_handle        Handle for the validating public key which must be a
 *                                root key or extracted certificate element
 *  \param[in]  digest            Input digest
 *  \param[in]  signature         Input code signature
 *  \param[in]  sig_len           length of the input signature
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_secureboot_preboot_update(ATCADevice device, const uint16_t dig_handle,
                                            const uint16_t pub_handle, const uint8_t* digest,
                                            const uint8_t* signature, const size_t sig_len,
                                            bool* is_validated)
{
    return talib_secureboot_update(device, TA_SECUREBOOT_MODE_PREBOOT_UPDATE, dig_handle,
                                   pub_handle, digest, signature, sig_len, is_validated);
}

/** \brief TA API - Execute secureboot command with boot phase mode for pre boot config mode.
 *                  Validate the code digest from the host against stored digest
 *
 *  \param[in]  device            device context pointer
 *  \param[in]  dig_handle        Handle for the code digest
 *  \param[in]  digest            input code digest
 *  \param[out] is_validated      result of secure boot validation (True or False)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_preboot_boot(ATCADevice device, const uint16_t dig_handle,
                                          const uint8_t* digest, bool* is_validated)
{
    return talib_secureboot_boot(device, TA_SECUREBOOT_MODE_PREBOOT_BOOT, dig_handle,
                                 digest, is_validated);
}

/** \brief TA API - Execute secureboot command to prevents further Secure_Boot commands
 *                  from executing until the next power/reset cycle or the passing of 50% of
 *                  the secure boot timer.
 *
 *  \param[in]  device          device context pointer
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_secureboot_common_lock(ATCADevice device)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;

    if (NULL == device)
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    if (NULL == (packet = (talib_packet_alloc())))
    {
        return ATCA_TRACE(ATCA_ALLOC_FAILURE, "Packet allocation failure");
    }

    packet->opcode = TA_OPCODE_SECUREBOOT;
    packet->param1 = TA_SECUREBOOT_MODE_COMMON_LOCK;
    packet->param2.val32 = 0;

    //Update length including length, opcode, param1, param2 and CRC
    packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

    /* send the resulting packet */
    status = talib_execute_command(packet, device);

    talib_packet_free(packet);

    return status;
}
