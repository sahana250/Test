/**
 * \file
 * \brief Basic RSAEnc commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes RSAEnc command to perform RSA Encryption and Decryption operations
 *                  Maximum number of bytes that can be encrypted or decrypted is 62.
 *                  This is available only for RSA-1024 bit keys
 *
 *  \param[in]  device        Device context pointer
 *  \param[in]  mode          mode parameter for RSAEnc command
 *  \param[in]  in_length     number of bytes in data_in
 *  \param[in]  handle        RSA Key handle for encrypt or decrypt operation
 *  \param[in]  data_in       Input data to encrypt or decrypt

 *  \param[out] data_out      Encrypt or decrypt result is returned here
 *  \param[in]  public_key    RSA-1024 bit public key for encryption if handle is IO buffer,
 *                            otherwise NULL.
 *  \param[in,out] out_length As Input, size of data_out
 *                            As output, number of bytes in data_out
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_rsaenc(ATCADevice device, const uint8_t mode, const uint16_t in_length, const
                         uint16_t handle, const uint8_t* data_in, uint8_t* const data_out, const
                         uint8_t* public_key, uint16_t* const out_length)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;

    if ((NULL == device) || (NULL == data_in) || ((TA_HANDLE_INPUT_BUFFER == handle) && (NULL == public_key)))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        if ((mode & TA_RSAENC_ENCRYPT) == TA_RSAENC_ENCRYPT)
        {
            if ((in_length < TA_RSAENC_PLAIN_TEXT_MIN_SIZE) || (in_length >
                                                                TA_RSAENC_PLAIN_TEXT_MAX_SIZE))
            {
                status = ATCA_TRACE(ATCA_INVALID_LENGTH, "Invalid input length received");
            }
        }
        else
        {
            if (in_length != TA_RSAENC_CIPHER_TEXT_SIZE)
            {
                status = ATCA_TRACE(ATCA_INVALID_LENGTH, "Invalid input length received");
            }
        }

        if (ATCA_SUCCESS == status)
        {
            packet = talib_packet_alloc();
            status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
        }
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_RSAENC;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(in_length);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(handle);

        data = packet->data;
        //copy input data into input stream buffer
        memcpy(data, data_in, in_length);
        data += in_length;

        if (TA_HANDLE_INPUT_BUFFER == handle)
        {
            memcpy(data, public_key, TA_RSAENC_PUB_KEY_SIZE);
            data += TA_RSAENC_PUB_KEY_SIZE;
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;
            if (data_out && rsp_length)
            {
                if (out_length)
                {
                    *out_length = *out_length < rsp_length ? *out_length : rsp_length;
                    memcpy(data_out, resp_packet->data, *out_length);
                }
                else
                {
                    memcpy(data_out, resp_packet->data, rsp_length);
                }
            }
        }

        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes RSAEnc command to perform RSA Encryption.
 *                  Encrypt using shared data element which is referred by handle
 *
 *  \param[in]  device                  Device context pointer
 *  \param[in]  handle                  RSA public Key handle for encrypt operation
 *  \param[in]  text_size               number of bytes of plain text (maximum 62 bytes)
 *  \param[in]  plain_text              Input data to encrypt
 *  \param[out] cipher_text_size        The size of the ciphertext buffer
 *  \param[in]  cipher_text             Encrypted result is returned here
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_rsaenc_encrypt(ATCADevice device, const uint16_t handle, const uint16_t text_size,
                                 const uint8_t* plain_text, const uint16_t cipher_text_size, uint8_t* const cipher_text)
{
    return talib_rsaenc(device, TA_RSAENC_ENCRYPT, text_size, handle, plain_text, cipher_text,
                        NULL, (uint16_t*)&cipher_text_size);
}

/** \brief TA API - Executes RSAEnc command to perform RSA Encryption.
 *                  Encrypt using given public key in input buffer
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  pub_key             public key used to encrypt the plain text
 *  \param[in]  text_size           number of bytes of plain text (maximum 62 bytes)
 *  \param[in]  plain_text          Input data to encrypt
 *  \param[in]  cipher_text_size    The size of the ciphertext buffer
 *  \param[out] cipher_text         Encrypted result is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_rsaenc_encrypt_with_iobuffer(ATCADevice device, const uint8_t* pub_key,
                                               const uint16_t text_size, const uint8_t* plain_text,
                                               const uint16_t cipher_text_size,
                                               uint8_t* const cipher_text)
{
    return talib_rsaenc(device, TA_RSAENC_ENCRYPT, text_size, TA_HANDLE_INPUT_BUFFER,
                        plain_text, cipher_text, pub_key, (uint16_t*)&cipher_text_size);
}

/** \brief TA API - Executes RSAEnc command to perform RSA Decryption.
 *                  Decrypt using private key referred by the handle
 *
 *  \param[in]  device            Device context pointer
 *  \param[in]   handle           RSA private Key handle to decrypt cipher text
 *  \param[in]   text_size        number of bytes of cipher text which is always 128 bytes.
 *  \param[in]   cipher_text      Input data to decrypt
 *  \param[in]   plain_text_size  Size of the plain_text buffer.
 *  \param[out]  plain_text       decrypted result is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_rsaenc_decrypt(ATCADevice device, const uint16_t handle, const uint16_t
                                 text_size, const uint8_t* cipher_text,
                                 const uint16_t plain_text_size, uint8_t* const plain_text)
{
    return talib_rsaenc(device, TA_RSAENC_DECRYPT, text_size, handle, cipher_text, plain_text,
                        NULL, (uint16_t*)&plain_text_size);
}
