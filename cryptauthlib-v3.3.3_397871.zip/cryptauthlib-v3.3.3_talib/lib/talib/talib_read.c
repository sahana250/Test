/**
 * \file
 * \brief Basic Read command for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes Read command to read an element from shared data memory.
 *                  This supports both partial and completed writes
 *                  Restrictions apply based on attributes of the element
 *                  Volatile registers can never be read
 *
 *  \param[in]      device              Device context pointer
 *  \param[in]      mode                mode parameter for the read operations
 *  \param[in]      transfer_handle     Remote device write handle in case of transfer operation
 *  \param[in]      key_handle          Target handle to initiate read operation
 *  \param[in]      offset              Offset to the first byte to be read...
 *                                      Applicable only to Shared data memory only
 *                                      Valid only for partial reads
 *  \param[in,out]   length              As Input, number of bytes to read.
 *                                      Cannot exceed element size
 *                                      Valid only for partial reads
 *                                      As Output, number bytes read is returned here
 *  \param[out]      data_read          Actual data read is returned here
 *  \param[in]       mac                MAC  for the transfer function.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read(ATCADevice device, const uint8_t mode, const uint16_t transfer_handle,
                       const uint16_t key_handle, const uint16_t offset, uint16_t* const length,
                       uint8_t* const data_read, const uint8_t* mac)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if ((NULL == device) || (NULL == data_read) || ((NULL == length) && (mode | TA_READ_PARTIAL_ELEMENT) == TA_READ_PARTIAL_ELEMENT))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_READ;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(transfer_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        if (!(mode & TA_READ_ENTIRE_ELEMENT))
        {
            /* lint -e613 Checked above but some linters don't follow the logic */
            tmp16 = ATCA_UINT16_HOST_TO_BE(*length);
            memcpy(data, &tmp16, 2);
            data += sizeof(*length);
            tmp16 = ATCA_UINT16_HOST_TO_BE(offset);
            memcpy(data, &tmp16, 2);
            data += sizeof(offset);
        }

        //In transfer authorize session there must be mac appended to the command
        if (mode & TA_READ_FOR_TRANSFER)
        {
            if (mac)
            {
                memcpy(data, mac, TA_READ_TRANSFER_MAC_SIZE);
            }
            else
            {
                memset(data, 0, TA_READ_TRANSFER_MAC_SIZE);
            }
            data += TA_READ_TRANSFER_MAC_SIZE;
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            if (data_read)
            {
                uint16_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;
                if (length)
                {
                    *length = *length < rsp_length ? *length : rsp_length;
                    memcpy(data_read, resp_packet->data, *length);
                }
                else
                {
                    memcpy(data_read, resp_packet->data, rsp_length);
                }
            }
        }

        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes Read command to read complete element from shared data memory.
 *                  Restrictions apply based on attributes of the element.
 *                  Volatile registers can never be read.
 *
 *  \param[in]      device              Device context pointer
 *  \param[in]      key_handle          Target handle to initiate read operation
 *  \param[in,out]   length              As Input, number of bytes to read.
 *                                      Cannot exceed element size
 *  \param[out]     data_out            Actual data read is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_element(ATCADevice device, const uint16_t key_handle, uint16_t* const length,
                               uint8_t* const data_out)
{
    return talib_read(device, TA_READ_ENTIRE_ELEMENT, 0, key_handle, 0, length, data_out,
                      NULL);
}

/** \brief TA API - Executes Read command to read partial element from shared date memory.
 *                  Restrictions apply based on attributes of the element.
 *                  Volatile registers can never be read.
 *
 *  \param[in]      device          Device context pointer
 *  \param[in]      key_handle      Target handle to initiate read operation
 *  \param[in]      offset          Offset to the first byte to be read...
 *                                  Applicable only to Shared data memory only
 *  \param[in,out]   length          As Input, number of bytes to read. Cannot exceed element size
 *                                  As Output, number bytes read is returned here
 *  \param[out]      data           Actual data read is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_partial_element(ATCADevice device, const uint16_t key_handle, const uint16_t
                                       offset, uint16_t* const length, uint8_t* const data)
{
    return talib_read(device, TA_READ_PARTIAL_ELEMENT, 0, key_handle, offset, length, data,
                      NULL);
}

/** \brief Executes Read command to read the complete device configuration
 *         handle.
 *
 *  \param[in]  device       Device context pointer
 *  \param[out] config_data  Configuration zone data is returned here.
 *
 *  \returns ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_config_zone(ATCADevice device, uint8_t* const config_data)
{
    uint16_t config_length = TA_CONFIG_SIZE;

    return talib_read(device, TA_READ_ENTIRE_ELEMENT, 0, TA_HANDLE_CONFIG_MEMORY, 0,
                      &config_length, config_data, NULL);
}

/** \brief Executes Read command to read the gpio pin state
 *
 *  \param[in]  device       Device context pointer
 *  \param[in]  gpio_handle  refer to gpio handle (gpio1, gpio2, gpio2)
 *  \param[out] pin_state    state of the gpio pin returned here
 *
 *  \returns ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_gpio_pin_state(ATCADevice device, const uint16_t gpio_handle, uint8_t* const
                                      pin_state)
{
    ATCA_STATUS status;

    do
    {
        if ((gpio_handle < TA_HANDLE_GPIO1 || gpio_handle > TA_HANDLE_GPIO3))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid gpio handle received");
            break;
        }

        status = talib_read(device, TA_READ_ENTIRE_ELEMENT, 0, gpio_handle, 0, NULL, pin_state,
                            NULL);
    }
    while (0);

    return status;
}

/** \brief Executes Read command to read an ECC P256 public key from a handle for clear reads.
 *
 * This function assumes the public key is stored using the ECC P256 public key
 * format specified in the datasheet.
 *
 *  \param[in]    device      Device context pointer
 *  \param[in]    handle      Handle number to read from.
 *  \param[out]   public_key  Public key is returned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_pubkey_compat(ATCADevice device, const uint16_t handle, uint8_t public_key[TA_ECC256_PUB_KEY_SIZE])
{
    uint16_t pubkey_size = TA_ECC256_PUB_KEY_SIZE;

    return talib_read_element(device, handle, &pubkey_size, public_key);
}

/** \brief Used to read an arbitrary number of bytes from internal memory
 *         for clear reads.
 *
 * This function will issue the Read command as many times as is required to
 * read the requested data.
 *
 *  \param[in]  device  Device context pointer
 *  \param[in]  zone    Zone to read data from. Unused
 *  \param[in]  handle  handle number to read
 *  \param[in]  offset  Byte offset within the handle to read from.
 *  \param[out] data    Read data is returned here.
 *  \param[in]  length  Number of bytes to read starting from the offset.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_bytes_zone(ATCADevice device, const uint8_t zone, const uint16_t handle,
                                  const size_t offset, uint8_t* const data, const size_t length)
{
    (void)zone;
    return talib_read_partial_element(device, handle, (uint16_t)offset, (uint16_t*)&length,
                                      data);
}

/** \brief Executes Read command to read a 64 byte ECDSA P256 signature from a
 *         slot configured for clear reads.
 *
 *  \param[in]  device       Device context pointer
 *  \param[in]  handle       Handle number to read from.
 *  \param[out] signature    Signature will be returned here (64 bytes). Format will be
 *                           the 32 byte R and S big-endian integers concatenated.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_sig_compat(ATCADevice device, const uint16_t handle, uint8_t signature[64])
{
    uint16_t sig_len = 64;

    return talib_read_element(device, handle, &sig_len, signature);
}

/** \brief Executes Read command to transfer key to another vega device
 *
 *  \param[in]  device           Device context pointer
 *  \param[in]  transfer_handle  handle where data need to be written
 *  \param[out] data             transfer package is returned here
 *  \param[in]  transfer_mac     mac for transfer read
 *
 *  \returns ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_read_data_transfer(ATCADevice device, const uint16_t transfer_handle,
                                     uint8_t* const data, const uint8_t* transfer_mac)
{
    return talib_read(device, TA_READ_FOR_TRANSFER | TA_READ_ENTIRE_ELEMENT,
                      transfer_handle, 0, 0, NULL, data, transfer_mac);
}

/** \brief Compares a specified configuration zone with the configuration zone
 *          currently on the device.
 *
 * \param[in]  device       Device context pointer
 * \param[in]  config_data  Full configuration data to compare the device
 *                          against.
 * \param[out] same_config  Result is returned here. True if the static portions
 *                          on the configuration zones are the same.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_cmp_config_zone(ATCADevice device, const uint8_t config_data[TA_CONFIG_SIZE],
                                  bool* same_config)
{
    ATCA_STATUS status;
    uint8_t device_config_data[TA_CONFIG_SIZE] = { 0 };

    do
    {
        if (!config_data || !same_config)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        if (ATCA_SUCCESS != (status = talib_read_config_zone(device, device_config_data)))
        {
            ATCA_TRACE(status, "talib_read_config_zone - Execution failed");
            break;
        }

        *same_config = memcmp(config_data, device_config_data, TA_CONFIG_SIZE) ? false : true;

    }
    while (0);

    return status;
}
