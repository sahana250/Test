/**
 * \file
 * \brief Basic Sign command for Trust Anchor Devices.
 *
 * The Sign command generates a signature using the private key in handle with
 * ECDSA algorithm or RSA algorithm.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes the Sign command for sign internally generated messages using
 *                  ECDSA or RSA algorithm.
 *
 * \param[in]  device               Device context pointer
 * \param[in]  mode                 Mode determines algorithm, key and algorithm options
 * \param[in]  priv_handle          Private key handle used to sign the message.
 * \param[in]  template_handle      Message template handle... Should be in Shared Data memory
 * \param[in]  target_handle        Private key corresponding to Public Key to be included in the
 *                                      message... Should be in Shared Data memory
 * \param[out] signature            Signature is returned here.
 * \param[in,out] sign_size          As input, the size of the data_out buffer.
 *                                  As output, the number of bytes returned in data_out.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sign_internal(ATCADevice device, const uint8_t mode, const uint16_t priv_handle,
                                const uint16_t template_handle, const uint16_t target_handle,
                                uint8_t* const signature, uint16_t* const sign_size)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t *data;
    uint16_t tmp16;

    if (NULL == device)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_SIGN;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(template_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(priv_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(target_handle);
        memcpy(data, &tmp16, sizeof(target_handle));
        data += sizeof(target_handle);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (signature && rsp_length)
            {
                if (sign_size)
                {
                    *sign_size = *sign_size < rsp_length ? *sign_size : rsp_length;
                    memcpy(signature, resp_packet->data, *sign_size);
                }
                else
                {
                    memcpy(signature, resp_packet->data, rsp_length);
                }
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes the Sign command for sign the external messages using
 *                  ECDSA or RSA algorithm
 *
 * \param[in]  device               Device context pointer
 * \param[in]  mode                 Mode determines algorithm, key and algorithm options
 * \param[in]  priv_handle          Private key handle used to sign the message
 * \param[in]  msg_handle           Message handle that contains message to be signed
 * \param[in]  message              Message to be signed when msg_handle points to Input buffer
 *                                  Should be 28, 32 or 48 bytes when sent on Input buffer
 * \param[in]  message_length       number of bytes in message buffer
 * \param[out] signature            Signature is returned here.
 * \param[in,out] sign_size          As input, the size of the signature buffer.
 *                                  As output, the number of bytes returned in data_out.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sign_external(ATCADevice device, const uint8_t mode, const uint16_t priv_handle,
                                const uint16_t msg_handle, const uint8_t* message, const uint16_t
                                message_length, uint8_t* const signature, uint16_t* const sign_size)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    ATCA_TA_RspPacket* resp_packet;
    uint8_t *data;
    uint16_t rsp_length;

    if ((NULL == device) || ((msg_handle == TA_HANDLE_INPUT_BUFFER) && (message == NULL)))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_SIGN;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(msg_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(priv_handle);

        data = packet->data;
        if (message)
        {
            memcpy(data, message, message_length);
            data += message_length;
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            resp_packet = (ATCA_TA_RspPacket*)packet;
            rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (signature && rsp_length)
            {
                if (sign_size)
                {
                    *sign_size = *sign_size < rsp_length ? *sign_size : rsp_length;
                    memcpy(signature, resp_packet->data, *sign_size);
                }
                else
                {
                    memcpy(signature, resp_packet->data, rsp_length);
                }
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief Executes Sign command, to sign a 32-byte external message using the
 *                   private key in the specified slot.
 *
 *  \param[in]  device     Device context pointer
 *  \param[in]  key_id     Slot of the private key to be used to sign the message.
 *  \param[in]  msg        32-byte message to be signed. Typically the SHA256
 *                         hash of the full message.
 *  \param[out] signature  Signature will be returned here. Format is R and S
 *                         integers in big-endian format. 64 bytes for P256
 *                         curve.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sign_compat(ATCADevice device, const uint16_t key_id, const uint8_t msg[32], uint8_t signature[64])
{
    uint16_t sign_size = TA_SIGN_P256_SIG_SIZE;

    return talib_sign_external(device, TA_SIGN_MODE_EXTERNAL_MSG | TA_KEY_TYPE_ECCP256,
                               key_id, TA_HANDLE_INPUT_BUFFER, msg, TA_SIGN_P256_MSG_SIZE,
                               signature, &sign_size);
}
