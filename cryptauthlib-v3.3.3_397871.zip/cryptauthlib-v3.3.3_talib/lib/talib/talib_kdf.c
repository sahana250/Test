/**
 * \file
 * \brief Basic KDF commands for Trust Anchor Devices.
 *
 * The KDF command implements one of a number of Key Derivation Functions (KDF).
 * Generally this function combines a source key with an input string and
 * creates a result key/digest/array. The algorithms currently supported are:
 * PRF, HKDF, HMAC counter, SHA, AES-A & AES-B.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheet for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes AES OptionA operations using KDF command.
 *             Output_Handle = AESencrypt(key, Message[16:31])
 *
 *  \param[in] device           Device context pointer
 *  \param[in] msg_handle       handle refers to the message which present in device
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    kdf output will be stored in this handle
 *  \param[in] message          Message to send on IO if indicated by message_handle
 *                               if present, should be 32 bytes
 *  \param[out] kdf_out         Output of the KDF AES-A function is retuned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_aesA(ATCADevice device, const uint16_t msg_handle, const uint16_t key_handle,
                           const uint16_t output_handle, const uint8_t* message, uint8_t* const
                           kdf_out)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if (NULL == device)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KDF;
        packet->param1 = TA_KDF_AESA_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(msg_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(output_handle);
        memcpy(data, &tmp16, sizeof(output_handle));
        data += sizeof(output_handle);

        tmp16 = ATCA_UINT16_HOST_TO_BE(TA_KDF_AES_A_MESSAGE_LEN);
        memcpy(data, &tmp16, sizeof(tmp16));
        data += sizeof(uint16_t);

        if (msg_handle == TA_HANDLE_INPUT_BUFFER)
        {
            if (message == NULL)
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            }
            else
            {
                memcpy(data, message, TA_KDF_AES_A_MESSAGE_LEN);
                data += TA_KDF_AES_A_MESSAGE_LEN;
            }
        }

        if (ATCA_SUCCESS == status)
        {
            //Updating packet length with opcode, param1, param2, data, crc
            packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                    ATCA_CMD_BUILD_MIN_LENGTH);

            status = ATCA_TRACE(talib_execute_command(packet, device), "");
        }

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t resp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (kdf_out && (resp_length >= TA_KDF_AES_RESULT_LEN))
            {
                memcpy(kdf_out, resp_packet->data, resp_length);
            }

        }

        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes AES OptionA operations using KDF command, result is on IO buffer
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] msg_handle       Input handle for the message
 *  \param[in] message          Message to send on IO if indicated by message_handle
 *                               if present, should be 32 bytes
 *  \param[out] kdf_output      Output of the KDF - AESA function is retuned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_aesA_io(ATCADevice device, const uint16_t key_handle, const uint16_t
                              msg_handle, const uint8_t* message, uint8_t* const kdf_output)
{
    return talib_kdf_aesA(device, msg_handle, key_handle, TA_HANDLE_OUTPUT_BUFFER,
                          message, kdf_output);
}

/** \brief TA API - Executes AES OptionA operations using KDF command, result is stored inside
 *                  device either in shared data memory or volatile register
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] message_handle   handle refers to the message which present in device
 *  \param[in] message          Message to send on IO if indicated by message_handle
 *                               if present, should be 32 bytes
 *  \param[in] output_handle    Stores the KDF output result in this handle
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_aesA_stored(ATCADevice device, const uint16_t key_handle, const uint16_t
                                  message_handle, const uint8_t* message, const uint16_t output_handle)
{
    return talib_kdf_aesA(device, message_handle, key_handle, output_handle, message, NULL);
}

/** \brief TA API - Executes AES OptionB operations using KDF command.
 *
 *  \param[in] device           Device context pointer
 *  \param[in] msg_handle       handle refers to the message (which present in device)
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    Holds the KDF output result
 *  \param[in] input_data       Application data to include in computation, should be 16 bytes
 *  \param[out] kdf_out         Output of the HKDF function is retuned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_aesB(ATCADevice device, const uint16_t msg_handle, const uint16_t key_handle,
                           const uint16_t output_handle, const uint8_t* input_data, uint8_t* const
                           kdf_out)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if ((NULL == device) || (NULL == input_data) || (TA_HANDLE_INPUT_BUFFER == msg_handle))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid message handle received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KDF;
        packet->param1 = TA_KDF_AESB_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(msg_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(output_handle);
        memcpy(data, &tmp16, sizeof(output_handle));
        data += sizeof(output_handle);

        tmp16 = ATCA_UINT16_HOST_TO_BE(TA_KDF_AES_B_INPUT_LEN);
        memcpy(data, &tmp16, sizeof(uint16_t));
        data += sizeof(uint16_t);

        memcpy(data, input_data, TA_KDF_AES_B_INPUT_LEN);
        data += TA_KDF_AES_B_INPUT_LEN;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t resp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (kdf_out && (resp_length >= TA_KDF_AES_RESULT_LEN))
            {
                memcpy(kdf_out, resp_packet->data, resp_length);
            }

        }
        talib_packet_free(packet);
    }

    return status;
}


/** \brief TA API - Executes AES OptionB operations using KDF command, result is on IO buffer
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] message_handle   Input handle for the message
 *  \param[in] input_data       Message to send on IO if indicated by message_handle
 *                              if present, should be 16 bytes
 *  \param[out] kdf_output      Output of the KDF - AESA function is retuned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_aesB_io(ATCADevice device, const uint16_t key_handle, const uint16_t message_handle,
                              const uint8_t* input_data, uint8_t* const kdf_output)
{
    return talib_kdf_aesB(device, message_handle, key_handle, TA_HANDLE_OUTPUT_BUFFER, input_data, kdf_output);
}
/** \brief TA API - Executes AES OptionB operations using KDF command, result is stored inside
 *                  device in either shared data memory or volatile register
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    Holds the KDF output result
 *  \param[in] message_handle   handle refers to the message (which present in device)
 *  \param[in] input_data       Application data to include in computation, should be 16 bytes
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_aesB_stored(ATCADevice device, const uint16_t key_handle, const uint16_t
                                  output_handle, const uint16_t message_handle, const uint8_t* input_data)
{
    return talib_kdf_aesB(device, message_handle, key_handle, output_handle, input_data, NULL);
}

/** \brief TA API - Executes HKDF operation using KDF command.
 *                      Extract_key = HMAC(Salt, Key_Handle)
 *                      Out_Handle[0-31] = HMAC(Key_ Extract_key, Info | 1)
 *                      Out_Handle[32-63] = HMAC(Key_ Extract_key, Out_Handle[0-31] | Info | 2)
 *                      Out_Handle[64-95] = HMAC(Key_ Extract_key, Out_Handle[32-63] | Info | 3)
 *                      Out_Handle[96-127] = HMAC(Key_ Extract_key, Out_Handle[64-95] | Info | 4)
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    Holds the KDF output result
 *  \param[in] salt_len         Input Salt size
 *  \param[in] info_len         Input Info size
 *  \param[in] salt             Input Salt for HKDF-Extract phase
 *  \param[in] info             Application specific info for HKDF-Exapnd phase
 *  \param[out] kdf_out         Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_hkdf(ATCADevice device, const uint16_t key_handle, const uint16_t output_handle,
                       const uint16_t salt_len, const uint16_t info_len, const uint8_t* salt, const
                       uint8_t* info, uint8_t* const kdf_out, uint16_t* const kdf_length)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if ((NULL == device) || (NULL == salt) || (salt_len < TA_KDF_HKDF_SALT_MIN_LEN) || (salt_len > TA_KDF_HKDF_SALT_MAX_LEN))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid salt length received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KDF;
        packet->param1 = TA_KDF_HKDF_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(*kdf_length);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(output_handle);
        memcpy(data, &tmp16, sizeof(output_handle));
        data += sizeof(output_handle);

        tmp16 = ATCA_UINT16_HOST_TO_BE(salt_len);
        memcpy(data, &tmp16, sizeof(salt_len));
        data += sizeof(salt_len);

        tmp16 = ATCA_UINT16_HOST_TO_BE(info_len);
        memcpy(data, &tmp16, sizeof(info_len));
        data += sizeof(info_len);

        memcpy(data, salt, salt_len);
        data += salt_len;

        if (info)
        {
            if (info_len > TA_KDF_HKDF_INFO_MAX_LEN)
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid info length received");
            }
            memcpy(data, info, info_len);
            data += info_len;
        }

        if (ATCA_SUCCESS == status)
        {
            //Updating packet length with opcode, param1, param2, data, crc
            packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                    ATCA_CMD_BUILD_MIN_LENGTH);

            status = ATCA_TRACE(talib_execute_command(packet, device), "");
        }

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t resp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (kdf_out && resp_length)
            {
                if (kdf_length)
                {
                    *kdf_length = *kdf_length < resp_length ? *kdf_length : resp_length;
                    memcpy(kdf_out, resp_packet->data, *kdf_length);
                }
                else
                {
                    memcpy(kdf_out, resp_packet->data, resp_length);
                }
            }

        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes HKDF operation using KDF command, result in IO buffer
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] salt             Input Salt for HKDF-Extract phase
 *  \param[in] salt_len         Input Salt size
 *  \param[in] info             Application specific info for HKDF-Exapnd phase
 *  \param[in] info_len         Input Info size
 *  \param[out] kdf_output      Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_hkdf_io(ATCADevice device, const uint16_t key_handle, const uint8_t* salt, const
                          uint16_t salt_len, const uint8_t* info, const uint16_t info_len, uint8_t*
                          const kdf_output, uint16_t* const kdf_length)
{
    return talib_hkdf(device, key_handle, TA_HANDLE_OUTPUT_BUFFER, salt_len, info_len,
                      salt, info, kdf_output, kdf_length);
}

/** \brief TA API - Executes HKDF operation using KDF command, result is stored inside device either
 *                  in shared data memory or volatile register
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] salt             Input Salt for HKDF-Extract phase
 *  \param[in] salt_len         Input Salt size
 *  \param[in] info             Application specific info for HKDF-Exapnd phase
 *  \param[in] info_len         Input Info size
 *  \param[in] target_handle    Holds the KDF output result
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_hkdf_stored(ATCADevice device, const uint16_t key_handle, const uint8_t* salt,
                              const size_t salt_len, const uint8_t* info, const size_t info_len,
                              const uint16_t target_handle, uint16_t* const kdf_length)
{
    return talib_hkdf(device, key_handle, target_handle, (uint16_t)salt_len, (uint16_t)info_len,
                      salt, info, NULL, kdf_length);
}

/** \brief TA API - Executes PRF operation using KDF command.
 *                  A1 = HMAC(Key_Handle, Input_Data)
 *                  Out_Handle[0-31] = HMAC(Key_Handle, A1 | Input_Data)
 *                  A2 = HMAC(Key_Handle, A1)
 *                  Out_Handle[32-63] = HMAC(Key_Handle, A2 | Input_Data)
 *                  A3 = HMAC(Key_Handle, A2)
 *                  Out_Handle[64-95] = HMAC(Key_Handle, A3 | Input_Data)
 *                  A4 = HMAC(Key_Handle, A3)
 *                  Out_Handle[96-127] = HMAC(Key_Handle, A4 | Input_Data)
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    Holds the KDF output result
 *  \param[in] input_len        Input "input" size
 *  \param[in] input_data       concatenated value of label and seed
 *  \param[out] kdf_out         Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_prf(ATCADevice device, const uint16_t key_handle, const uint16_t
                          output_handle, const uint16_t input_len, const uint8_t* input_data,
                          uint8_t* const kdf_out, uint16_t* const kdf_length)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if (NULL == device)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KDF;
        packet->param1 = TA_KDF_PRF_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(*kdf_length);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(output_handle);
        memcpy(data, &tmp16, sizeof(output_handle));
        data += sizeof(output_handle);

        tmp16 = ATCA_UINT16_HOST_TO_BE(input_len);
        memcpy(data, &tmp16, sizeof(input_len));
        data += sizeof(input_len);

        if (input_data)
        {
            if (input_len > TA_KDF_PRF_INPUT_MAX_LEN)
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid input length received");
            }
            else
            {
                memcpy(data, input_data, input_len);
                data += input_len;
            }
        }

        if (ATCA_SUCCESS == status)
        {
            //Updating packet length with opcode, param1, param2, data, crc
            packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                    ATCA_CMD_BUILD_MIN_LENGTH);

            status = ATCA_TRACE(talib_execute_command(packet, device), "");
        }

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t resp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (kdf_out && resp_length)
            {
                if (kdf_length)
                {
                    *kdf_length = *kdf_length < resp_length ? *kdf_length : resp_length;
                    memcpy(kdf_out, resp_packet->data, *kdf_length);
                }
                else
                {
                    memcpy(kdf_out, resp_packet->data, resp_length);
                }
            }

        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes PRF operation using KDF command, result in IO buffer
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] src_key_length   Source Key length in bytes. 16, 32, 48 and 64 are only valid
 *  \param[in] input            concatenated value of label and seed
 *  \param[in] input_len        Input "input" size
 *  \param[out] kdf_output      Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_prf_io(ATCADevice device, const uint16_t key_handle, const uint8_t
                             src_key_length, const uint8_t* input, const uint16_t input_len,
                             uint8_t* const kdf_output, uint16_t* const kdf_length)
{
    (void)src_key_length;
    return talib_kdf_prf(device, key_handle, TA_HANDLE_OUTPUT_BUFFER, input_len, input,
                         kdf_output, kdf_length);
}

/** \brief TA API - Executes PRF operation using KDF command, result is stored inside device either
 *                  in shared data memory or volatile register
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] src_key_length   Source Key length in bytes. 16, 32, 48 and 64 are only valid
 *  \param[in] input            concatenated value of label and seed
 *  \param[in] input_len        Input "input" size
 *  \param[in] target_handle    Holds the KDF output result
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_prf_stored(ATCADevice device, const uint16_t key_handle, const uint8_t
                                 src_key_length, const uint8_t* input, const uint16_t input_len,
                                 const uint16_t target_handle, uint16_t* const kdf_length)
{
    (void)src_key_length;
    return talib_kdf_prf(device, key_handle, target_handle, input_len, input, NULL, kdf_length);
}

/** \brief TA API - Executes HMAC-Counter operation using KDF command.
 *                      Bytes 0-31: HMAC(key_handle, 1 | Label | 0 | Context | Length)
 *                      Bytes 32-63: HMAC(key_handle, 2 | Label | 0 | Context | Length)
 *                      Bytes 64-95: HMAC(key_handle, 3 | Label | 0 | Context | Length)
 *                      Bytes 95-127: HMAC(key_handle, 4 | Label | 0 | Context | Length)
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    Holds the KDF output result
 *  \param[in] label_len        Input label size
 *  \param[in] context_len      Input context size
 *  \param[in] label            Input label string provided by host
 *  \param[in] context          Input context provided by host
 *  \param[out] kdf_out         Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_hmac_counter(ATCADevice device, const uint16_t key_handle, const uint16_t
                                   output_handle, const uint16_t label_len, const uint16_t
                                   context_len, const uint8_t* label, const uint8_t* context,
                                   uint8_t* const kdf_out, uint16_t* const kdf_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if (NULL == device || (label_len > TA_KDF_HMAC_LABEL_MAX_LEN) || (context_len > TA_KDF_HMAC_CONTEXT_MAX_LEN))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid length received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KDF;
        packet->param1 = TA_KDF_HMAC_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(*kdf_length);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(output_handle);
        memcpy(data, &tmp16, sizeof(output_handle));
        data += sizeof(output_handle);

        tmp16 = ATCA_UINT16_HOST_TO_BE(label_len);
        memcpy(data, &tmp16, sizeof(label_len));
        data += sizeof(label_len);

        tmp16 = ATCA_UINT16_HOST_TO_BE(context_len);
        memcpy(data, &tmp16, sizeof(context_len));
        data += sizeof(context_len);

        if (label)
        {
            memcpy(data, label, label_len);
            data += label_len;
        }

        if (context)
        {
            memcpy(data, context, context_len);
            data += context_len;
        }

        //Updating packet length with opcode, param1, param2, data, crc
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t resp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (kdf_out && resp_length)
            {
                if (kdf_length)
                {
                    *kdf_length = *kdf_length < resp_length ? *kdf_length : resp_length;
                    memcpy(kdf_out, resp_packet->data, *kdf_length);
                }
                else
                {
                    memcpy(kdf_out, resp_packet->data, resp_length);
                }
            }

        }

        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes HMAC-Counter operation using KDF command, result is in IO buffer
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] label            Input label string provided by host
 *  \param[in] label_len        Input label size
 *  \param[in] context          Input context provided by host
 *  \param[in] context_len      Input context size
 *  \param[out] kdf_output      Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_hmac_counter_io(ATCADevice device, const uint16_t key_handle, const uint8_t*
                                      label, const uint16_t label_len, const uint8_t* context,
                                      const uint16_t context_len, uint8_t* const kdf_output,
                                      uint16_t* const kdf_length)
{
    return talib_kdf_hmac_counter(device, key_handle, TA_HANDLE_OUTPUT_BUFFER, label_len,
                                  context_len, label, context, kdf_output, kdf_length);
}

/** \brief TA API - Executes HMAC-Counter operation using KDF command, result is stored inside
 *                  device either in shared data memory or volatile register
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] label            Input label string provided by host
 *  \param[in] label_len        Input label size
 *  \param[in] context          Input context provided by host
 *  \param[in] context_len      Input context size
 *  \param[in] target_handle    Holds the KDF output result
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_hmac_counter_stored(ATCADevice device, const uint16_t key_handle, const
                                          uint8_t* label, const uint16_t label_len, const uint8_t*
                                          context, const uint16_t context_len, const uint16_t
                                          target_handle, uint16_t* const kdf_length)
{
    return talib_kdf_hmac_counter(device, key_handle, target_handle, label_len, context_len, label,
                                  context, NULL, kdf_length);
}


/** \brief TA API - Executes SHA256 operation using KDF command.
 *                      Bytes 0-31: SHA256(Pre_pad | key_handle | Post_pad)
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] output_handle    Holds the KDF output result
 *  \param[in] pre_pad          Host data to prepad IKM
 *  \param[in] pre_len          Input pre-pad size
 *  \param[in] post_pad         Host data to prepad IKM
 *  \param[in] post_len         Input post-pad size
 *  \param[out] kdf_out         Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                               As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_sha256(ATCADevice device, const uint16_t key_handle, const uint16_t
                             output_handle, const uint8_t* pre_pad, const uint16_t pre_len, const
                             uint8_t* post_pad, const uint16_t post_len, uint8_t* const kdf_out,
                             uint16_t* const kdf_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if (NULL == device || (pre_len > TA_KDF_SHA_PAD_LENGTH_MAX) || (post_len > TA_KDF_SHA_PAD_LENGTH_MAX))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid length received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KDF;
        packet->param1 = TA_KDF_SHA256_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(*kdf_length);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        tmp16 = ATCA_UINT16_HOST_TO_BE(output_handle);
        memcpy(data, &tmp16, sizeof(output_handle));
        data += sizeof(output_handle);

        tmp16 = ATCA_UINT16_HOST_TO_BE(pre_len);
        memcpy(data, &tmp16, sizeof(pre_len));
        data += sizeof(pre_len);

        tmp16 = ATCA_UINT16_HOST_TO_BE(post_len);
        memcpy(data, &tmp16, sizeof(post_len));
        data += sizeof(post_len);

        if (pre_pad)
        {
            memcpy(data, pre_pad, pre_len);
            data += pre_len;
        }

        if (post_pad)
        {
            memcpy(data, post_pad, post_len);
            data += post_len;
        }

        //Updating packet length with opcode, param1, param2, data, crc
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t resp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (kdf_out && resp_length)
            {
                if (kdf_length)
                {
                    *kdf_length = *kdf_length < resp_length ? *kdf_length : resp_length;
                    memcpy(kdf_out, resp_packet->data, *kdf_length);
                }
                else
                {
                    memcpy(kdf_out, resp_packet->data, resp_length);
                }
            }

        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes SHA256 operation using KDF command, result in IO buffer
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] pre_pad          Host data to prepad IKM
 *  \param[in] pre_pad_len      Input pre-pad size
 *  \param[in] post_pad         Host data to prepad IKM
 *  \param[in] post_pad_len     Input post-pad size
 *  \param[out] kdf_output      Output of the HKDF function is retuned here.
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_sha256_io(ATCADevice device, const uint16_t key_handle, const uint8_t*
                                pre_pad, const uint16_t pre_pad_len, const uint8_t* post_pad,
                                const uint16_t post_pad_len, uint8_t* const kdf_output, uint16_t*
                                const kdf_length)
{
    return talib_kdf_sha256(device, key_handle, TA_HANDLE_OUTPUT_BUFFER, pre_pad,
                            pre_pad_len, post_pad, post_pad_len, kdf_output, kdf_length);
}

/** \brief TA API - Executes SHA256 operation using KDF command, result is stored inside device
 *                  either in shared data memory or volatile register
 *
 *  \param[in] device           Device context pointer
 *  \param[in] key_handle       Contains Input Key Material
 *  \param[in] pre_pad          Host data to prepad IKM
 *  \param[in] pre_pad_len      Input pre-pad size
 *  \param[in] post_pad         Host data to prepad IKM
 *  \param[in] post_pad_len     Input post-pad size
 *  \param[in] target_handle    Holds the KDF output result
 *  \param[in,out] kdf_length    As input, expected Key Material size
 *                              As output, length of the Key Material in kdf_output
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_kdf_sha256_stored(ATCADevice device, const uint16_t key_handle, const uint8_t*
                                    pre_pad, const uint16_t pre_pad_len, const uint8_t* post_pad,
                                    const uint16_t post_pad_len, const uint16_t target_handle,
                                    uint16_t* const kdf_length)
{
    return talib_kdf_sha256(device, key_handle, target_handle, pre_pad, pre_pad_len, post_pad,
                            post_pad_len, NULL, kdf_length);
}
