/**
 * \file
 * \brief CryptoAuthLib Basic API methods. These methods provide a simpler way
 *        to access the core crypto methods.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "cryptoauthlib.h"

#ifdef ATCA_TA100_FCE_SUPPORT

#include "talib_fce.h"

#ifdef ATCA_HAL_LEGACY_API
#error "TA100 FCE support is not compatible with legacy HALs as specified by ATCA_HAL_LEGACY_API. Upgrade the HALs and disable this define"
#endif

static size_t talib_fce_get_block_size(uint8_t mode)
{
    size_t block_size;

    switch (mode)
    {
    case ATCA_FCE_MODE_HMAC:
        block_size = ATCA_FAST_CRYPTO_HMAC_BLOCK_SIZE;
        break;
    case ATCA_FCE_MODE_CMAC:
        block_size = ATCA_FAST_CRYPTO_CMAC_BLOCK_SIZE;
        break;
    default:
        block_size = ATCA_FAST_CRYPTO_SHA_BLOCK_SIZE;
        break;
    }
    return block_size;
}

static size_t talib_fce_get_output_size(uint8_t mode)
{
    size_t out_size;

    switch (mode)
    {
    case ATCA_FCE_MODE_HMAC:
        out_size = ATCA_FAST_CRYPTO_HMAC_SIZE;
        break;
    case ATCA_FCE_MODE_CMAC:
        out_size = ATCA_FAST_CRYPTO_CMAC_SIZE;
        break;
    default:
        out_size = ATCA_FAST_CRYPTO_SHA_SIZE;
        break;
    }
    return out_size;
}

/** \brief TA API Check to see if the FCE is ready for a new command */
static ATCA_STATUS talib_fce_check_ready(ATCADevice device, bool * fce_ready)
{
    uint8_t fsr_value = 0;
    ATCA_STATUS status = talib_execute_read_register(device, ATCA_FAST_CRYPTO_RD_FSR, &fsr_value);

    if (fsr_value & ATCA_FAST_CRYPTO_FSR_FERROR_MASK)
    {
        status = ATCA_TRACE(ATCA_EXECUTION_ERROR, "FSR reported error");
    }
    else if (fsr_value & ATCA_FAST_CRYPTO_FSR_FOUPUT_MASK)
    {
        *fce_ready = true;
    }
    else if ((fsr_value & ATCA_FAST_CRYPTO_FSR_FINPUT_MASK) == 0)
    {
        *fce_ready = true;
    }
    else
    {
        *fce_ready = false;
    }

    return status;
}

/** \brief TA API - Provides access to instructions of TA100 device.
 *      For ATCA_FAST_CRYPTO_WR_FAST_DATA, ATCA_FAST_CRYPTO_WR_FAST_LAST confirms that data
 *          is successfully written to internal buffers
 *      For ATCA_FAST_CRYPTO_RD_FAST_FIRST, ATCA_FAST_CRYPTO_RD_FAST_ADDL just reads from the
 *          device and subsequent checks or operations to be taken care by caller.
 *
 * \param[in]    device  CryptoAuthentication device to send the command to.
 * \param[in,out] packet  As input, the packet to be sent. As output, the data buffer
 *                          in the packet structure will contain the response.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_execute(ATCADevice device, ATCA_TA_InstrPacket* packet)
{
    ATCA_STATUS status;

    // Check the input parameters
    if (packet == NULL || device == NULL)
    {
        return ATCA_BAD_PARAM;
    }

    do
    {
        switch (packet->instr_code)
        {
        case ATCA_FAST_CRYPTO_WR_FAST_DATA:
        case ATCA_FAST_CRYPTO_WR_FAST_LAST:
            if (ATCA_SUCCESS != (status = talib_execute_send(device, atcab_get_device_address(device), (uint8_t*)&packet->instr_code, packet->length + 1)))
            {
                ATCA_TRACE(status, "WR FAST send - Failed");
                break;
            }
            break;

        case ATCA_FAST_CRYPTO_RD_FAST_FIRST:
        case ATCA_FAST_CRYPTO_RD_FAST_ADDL:
            if (ATCA_SUCCESS != (status = talib_execute_receive(device, atcab_get_device_address(device), packet->instr_code, packet->data, &packet->length)))
            {
                ATCA_TRACE(status, "RD FAST receive - Failed");
                break;
            }
            break;

        default:
            status = ATCA_BAD_PARAM;
            break;
        }
    }
    while (0);

    return status;
}

/** \brief TA FCE API - Execute FC Config command to configure the Fast Crypto Engine.
 *
 *  \param[in]  device           Device context pointer
 *  \param[in]  mode             Mode Algorithm Encoding
 *  \param[in]  key_handle       Handle of the group of symmetric keys for use
 *  \param[out] written_map      Map of those keys that were successfully written to the FCE
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_init(ATCADevice device, const uint8_t mode, const uint32_t key_handle, uint32_t* const written_map)
{
    ATCA_STATUS status;
    uint8_t fsr_value;

    status = talib_fcconfig_base(device, mode, key_handle, written_map);
    if (status == ATCA_SUCCESS)
    {
        status = talib_execute_read_register(device, ATCA_FAST_CRYPTO_RD_FSR, &fsr_value);
        if ((fsr_value) & (ATCA_FAST_CRYPTO_FSR_FINIT_MASK | ATCA_FAST_CRYPTO_FSR_FINPUT_MASK | ATCA_FAST_CRYPTO_FSR_FOUPUT_MASK))
        {
            status = ATCA_EXECUTION_ERROR;
        }
    }
    return status;
}

/** \brief Executes FCE Write instruction operation to add message data to the SHA operation.
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for SHA operation.
 * \param[in] message_length  Input data length for SHA operation
 * \param[in] is_last_block   Indicates whether the current input is last block for the calcualtion or not
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block)
{
    ATCA_TA_InstrPacket packet;
    ATCA_STATUS status = ATCA_SUCCESS;

    if ((ctx == NULL) || (message == NULL) || (message_length == 0))
    {
        status = ATCA_BAD_PARAM;
    }
    else
    {
        size_t rem_length;
        size_t curr_length = 0;
        size_t block_size = talib_fce_get_block_size(ctx->mode);

        int8_t status_retries = 3;
        bool first_block = true;
        bool is_fce_ok = false;

        while ((status == ATCA_SUCCESS) && (status_retries-- > 0) && !is_fce_ok)
        {
            status = talib_fce_check_ready(ctx->device, &is_fce_ok);
        }

        rem_length = message_length;
        while ((status == ATCA_SUCCESS) && (rem_length > 0) && is_fce_ok)
        {
            if ((ctx->counter > 0) && (((size_t)ctx->counter + rem_length > block_size)))
            {
                /* Residual bytes from the last update + the new bytes exceeds the block
                   size so there will again be residual bytes */
                memcpy(&packet.data[0], ctx->buffer, ctx->counter);
                memcpy(&packet.data[ctx->counter], message, block_size - ctx->counter);
                packet.length = block_size;
                rem_length -= (block_size - ctx->counter);
                curr_length += (block_size - ctx->counter);
                ctx->counter = 0;
            }
            else if ((ctx->counter > 0) && (((size_t)ctx->counter + rem_length == block_size)))
            {
                /* The residual bytes and the new bytes do not exceed the block size so
                   copy everything */
                memcpy(&packet.data[0], ctx->buffer, ctx->counter);
                memcpy(&packet.data[ctx->counter], message, rem_length);
                packet.length = (uint16_t)((size_t)ctx->counter + rem_length);
                rem_length = 0;
                ctx->counter = 0;
            }
            else if (rem_length >= block_size)
            {
                /* There are no residual bytes from a previous update and packet
                   can be completely filled */
                packet.length = (uint16_t)block_size;
                memcpy(&packet.data[0], message + curr_length, block_size);
                curr_length += block_size;
                rem_length -= block_size;
            }
            else
            {
                /* The remaining bytes is less than the block size so check if
                   this is the final packet and the context can be closed and the
                   result computed */
                packet.length = rem_length;
                if (is_last_block == true)
                {
                    memcpy(&packet.data[0], message + curr_length, rem_length);
                    rem_length = 0;
                }
                else
                {
                    /* Since this is not the last block copy the remaining bytes
                       to the context and return without sending a command */
                    memcpy(&ctx->buffer[ctx->counter], message + curr_length, rem_length);
                    ctx->counter += (uint16_t)rem_length;
                    return status;
                }
            }

            if ((rem_length <= 0) && (is_last_block))
            {
                packet.instr_code = ATCA_FAST_CRYPTO_WR_FAST_LAST;
            }
            else
            {
                packet.instr_code = ATCA_FAST_CRYPTO_WR_FAST_DATA;
            }

            if (ATCA_SUCCESS == (status = talib_fce_execute(ctx->device, &packet)))
            {
                if (first_block && (ATCA_FCE_MODE_HMAC == ctx->mode))
                {
                    status = talib_fce_check_ready(ctx->device, &is_fce_ok);
                }
                first_block = false;
            }
        }
    }
    return status;
}

/** \brief Executes read instruction and read the output digest value
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 *  \param[out] digest        The output digest is returned here (32 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_finish(fce_ctx_t* ctx, uint8_t* const buffer, size_t buf_len)
{
    ATCA_TA_InstrPacket packet;
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx && buffer && buf_len)
    {
        uint16_t out_len = talib_fce_get_output_size(ctx->mode);
        packet.length = out_len;
        packet.instr_code = ATCA_FAST_CRYPTO_RD_FAST_FIRST;

        if (ATCA_SUCCESS == (status = talib_fce_execute(ctx->device, &packet)))
        {
            memcpy(buffer, packet.data, (buf_len < out_len) ? buf_len : out_len);
            return ATCA_SUCCESS;
        }
    }
    return status;
}

/** \brief Executes FC Config command to configure FCE and Initialize Fast Crypto context counter value
 *  \param[in]  ctx          Fast Crypto Engine object that holds the internal remaining buffer
 *                           which need for calculation and its length.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_sha_start(fce_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint8_t fsr_value;

    if (ctx)
    {
        status = talib_fce_init(ctx->device, TA_FCCONFIG_SHA256_MODE, 0, NULL);
        if (status == ATCA_SUCCESS)
        {
            /* Initializing context counter value */
            ctx->counter = 0;
            ctx->mode = ATCA_FCE_MODE_SHA;
            fsr_value = 0;
            status = talib_execute_write_register(ctx->device, ATCA_FAST_CRYPTO_WR_FCR, fsr_value);
        }
    }
    return status;
}

/** \brief Executes FCE Write instruction operation to add message data to the SHA operation.
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for SHA operation.
 * \param[in] message_length  Input data length for SHA operation
 * \param[in] is_last_block   Indicates whether the current input is last block for the calcualtion or not
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_sha_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block)
{
    return talib_fce_update(ctx, message, message_length, is_last_block);
}

/** \brief Executes read instruction and read the output digest value
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 *  \param[out] digest        The output digest is returned here (32 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_sha_finish(fce_ctx_t* ctx, uint8_t* const digest)
{
    return talib_fce_finish(ctx, digest, ATCA_FAST_CRYPTO_SHA_SIZE);
}

/** \brief Use the FCE to compute a SHA-256 digest for given message in input stream
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for SHA operation.
 * \param[in] message_length  Input data length for SHA operation
 * \param[out] digest         The output digest is returned here (32 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_sha(ATCADevice device, const uint8_t* message, const size_t message_length, uint8_t* const digest)
{
    fce_ctx_t ctx;
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if ((message) && (digest))
    {
        ctx.device = device;
        status = talib_fce_sha_start(&ctx);
        if (status == ATCA_SUCCESS)
        {
            status = talib_fce_sha_update(&ctx, message, message_length, true);
            if (status == ATCA_SUCCESS)
            {
                status = talib_fce_sha_finish(&ctx, digest);
            }
        }
    }
    return status;
}

/** \brief Executes FC Config command to configure FCE for HMAC operation and Initialize Fast Crypto context counter value
 *  \param[in]  ctx          Fast Crypto Engine object that holds the internal remaining buffer
 *                           which need for calculation and its length.
 *  \param[in]  mode         Mode Algorithm Encoding
 *  \param[in]  handle       Handle of the Fast Crypto Group keys for use
 *  \param[in]  key_index    Key index which controls which key in the currently loaded fast crypto key group
 *  \param[out] written_map  Map of those keys that were successfully written to the FCE
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_hmac_start(fce_ctx_t* ctx, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint8_t fsr_value;

    if (ctx)
    {
        status = talib_fce_init(ctx->device, mode, key_handle, written_map);
        if (status == ATCA_SUCCESS)
        {
            /* Initializing context counter value */
            ctx->counter = 0;
            ctx->mode = ATCA_FCE_MODE_HMAC;
            fsr_value = (uint8_t)(key_index << ATCA_FAST_CRYPTO_FKEY_POS);
            status = talib_execute_write_register(ctx->device, ATCA_FAST_CRYPTO_WR_FCR, fsr_value);
        }
    }
    return status;
}

/** \brief Executes FCE Write instruction operation to add message data to the HMAC operation.
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for HMAC operation.
 * \param[in] message_length  Input data length for HMAC operation
 * \param[in] is_last_block   Indicates whether the current input is last block for the calcualtion or not
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_hmac_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block)
{
    return talib_fce_update(ctx, message, message_length, is_last_block);
}

/** \brief Executes read instruction and read the output mac value
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 *  \param[out] hmac          The output HMAC is returned here (32 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_hmac_finish(fce_ctx_t* ctx, uint8_t* const hmac)
{
    return talib_fce_finish(ctx, hmac, ATCA_FAST_CRYPTO_HMAC_SIZE);
}

/** \brief Use the FCE to compute a HMAC for given message in input stream
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for SHA operation.
 * \param[in] message_length  Input data length for SHA operation
 * \param[in]  handle         Handle of the Fast Crypto Group keys for use
 * \param[in]  key_index      Key index which controls which key in the currently loaded fast crypto key group
 * \param[out] written_map    Map of those keys that were successfully written to the FCE
 * \param[out] hmac           The output HMAC is returned here (32 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_hmac(ATCADevice device, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map, const uint8_t* message, const size_t message_length, uint8_t* const hmac)
{
    fce_ctx_t ctx;
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if ((message) && (hmac))
    {
        ctx.device = device;
        status = talib_fce_hmac_start(&ctx, mode, key_handle, key_index, written_map);
        if (status == ATCA_SUCCESS)
        {
            status = talib_fce_hmac_update(&ctx, message, message_length, true);
            if (status == ATCA_SUCCESS)
            {
                status = talib_fce_hmac_finish(&ctx, hmac);
            }
        }
    }
    return status;
}

/** \brief Executes FC Config command to configure FCE for CMAC operation and Initialize Fast Crypto context counter value
 *  \param[in]  ctx          Fast Crypto Engine object that holds the internal remaining buffer
 *                           which need for calculation and its length.
 *  \param[in]  mode         Mode Algorithm Encoding
 *  \param[in]  handle       Handle of the Fast Crypto Group keys for use
 *  \param[in]  key_index    Key index which controls which key in the currently loaded fast crypto key group
 *  \param[out] written_map  Map of those keys that were successfully written to the FCE
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_cmac_start(fce_ctx_t* ctx, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint8_t fsr_value;

    if (ctx)
    {
        status = talib_fce_init(ctx->device, mode, key_handle, written_map);
        if (status == ATCA_SUCCESS)
        {
            /* Initializing context counter value */
            ctx->counter = 0;
            ctx->mode = ATCA_FCE_MODE_CMAC;
            fsr_value = ATCA_FAST_CRYPTO_CMAC_MODE;
            fsr_value |= (uint8_t)(key_index << ATCA_FAST_CRYPTO_FKEY_POS);
            status = talib_execute_write_register(ctx->device, ATCA_FAST_CRYPTO_WR_FCR, fsr_value);
        }
    }
    return status;
}

/** \brief Executes FCE Write instruction operation to add message data to the CMAC operation.
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for CMAC operation.
 * \param[in] message_length  Input data length for CMAC operation
 * \param[in] is_last_block   Indicates whether the current input is last block for the calcualtion or not
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_cmac_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block)
{
    return talib_fce_update(ctx, message, message_length, is_last_block);
}

/** \brief Executes read instruction and read the output mac value
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 *  \param[out] cmac          The output CMAC is returned here (16 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_cmac_finish(fce_ctx_t* ctx, uint8_t* const cmac)
{
    return talib_fce_finish(ctx, cmac, ATCA_FAST_CRYPTO_CMAC_SIZE);
}

/** \brief Use the FCE to compute a CMAC for given message in input stream
 *
 *  \param[in]  ctx           Fast Crypto Engine object that holds the internal remaining buffer
 *                              which need for calculation and its length.
 * \param[in] message         Input data for CMAC operation.
 * \param[in] message_length  Input data length for CMAC operation
 * \param[in]  handle         Handle of the Fast Crypto Group keys for use
 * \param[in]  key_index      Key index which controls which key in the currently loaded fast crypto key group
 * \param[out] written_map    Map of those keys that were successfully written to the FCE
 * \param[out] cmac           The output CMAC is returned here (16 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_fce_cmac(ATCADevice device, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map, const uint8_t* message, const size_t message_length, uint8_t* const cmac)
{
    fce_ctx_t ctx;
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if ((message) && (cmac))
    {
        ctx.device = device;
        status = talib_fce_cmac_start(&ctx, mode, key_handle, key_index, written_map);
        if (status == ATCA_SUCCESS)
        {
            status = talib_fce_cmac_update(&ctx, message, message_length, true);
            if (status == ATCA_SUCCESS)
            {
                status = talib_fce_cmac_finish(&ctx, cmac);
            }
        }
    }
    return status;
}

#endif
