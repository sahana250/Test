talib
=========================

talib API cross reference
-------------------------

The talib api is extensive however due to the specifics of the device it is not
always possible to create a compatible api with the classic cryptoauth devices.


| Hardware Feature            | atcab_                          | calib_                            | talib_                                |
| --------------------------- | ------------------------------- | --------------------------------- | ------------------------------------- |
| AES128 ECB                  | [atcab_aes]                     | [calib_aes]                       |                                       |
| ^                           | [atcab_aes_encrypt]             | [calib_aes_encrypt]               | [talib_aes_encrypt]                   |
| ^                           | [atcab_aes_decrypt]             | [calib_aes_decrypt]               | [talib_aes_decrypt]                   |
| Galois Field Multiply       | [atcab_aes_gfm]                 | [calib_aes_gfm]                   |                                       |
| Incremental AES128-GCM      | [atcab_aes_gcm_init]            | [calib_aes_gcm_init]              |                                       |
| ^                           | [atcab_aes_gcm_init_rand]       | [calib_aes_gcm_init_rand]         |                                       |
| ^                           | [atcab_aes_gcm_aad_update]      | [calib_aes_gcm_aad_update]        |                                       |
| ^                           | [atcab_aes_gcm_encrypt_update]  | [calib_aes_gcm_encrypt_update]    |                                       |
| ^                           | [atcab_aes_gcm_encrypt_finish]  | [calib_aes_gcm_encrypt_finish]    |                                       |
| ^                           | [atcab_aes_gcm_decrypt_update]  | [calib_aes_gcm_decrypt_update]    |                                       |
| ^                           | [atcab_aes_gcm_decrypt_finish]  | [calib_aes_gcm_decrypt_finish]    |                                       |
| Atomic AES128-GCM           |                                 |                                   | [talib_aes_gcm]                       |
| ^                           |                                 |                                   | [talib_aes_gcm_keyload]               |
| ^                           |                                 |                                   | [talib_aes_gcm_keyload_with_implicit_iv]  |
| ^                           |                                 |                                   | [talib_aes_gcm_encrypt]               |
| ^                           |                                 |                                   | [talib_aes_gcm_encrypt_with_rand_iv]  |
| ^                           |                                 |                                   | [talib_aes_gcm_decrypt]               |
| AES128-CMAC                 |                                 |                                   | [talib_cmac] |
| Authenticated & Encrypted Communication  |                    |                                   | [talib_auth_generate_nonce] |
| ^                           |                                 |                                   | [talib_auth_startup] |
| ^                           |                                 |                                   | [talib_auth_terminate] |
| Cryptoauth Checkmac (SHA256) | [atcab_checkmac]               | [calib_checkmac]                  |                                       |
| Monotonic Counters          | [atcab_counter]                 | [calib_counter]                   | [talib_counter] |
| ^                           | [atcab_counter_increment]       | [calib_counter_increment]         | [talib_counter_increment] |
| ^                           | [atcab_counter_read]            | [calib_counter_read]              | [talib_counter_read] |
| Cryptoauth Derivekey        | [atcab_derivekey]               | [calib_derivekey]                 |                                       |
| ECDH (secp256r1)            | [atcab_ecdh_base]               | [calib_ecdh_base]                 |                                       |
| ^                           | [atcab_ecdh]                    | [calib_ecdh]                      | [talib_ecdh_compat] |
| ^                           | [atcab_ecdh_enc]                | [calib_ecdh_enc]                  |                                       |
| ^                           | [atcab_ecdh_ioenc]              | [calib_ecdh_ioenc]                |                                       |
| ^                           | [atcab_ecdh_tempkey]            | [calib_ecdh_tempkey]              |                                       |
| ^                           | [atcab_ecdh_tempkey_ioenc]      | [calib_ecdh_tempkey_ioenc]        |                                       |
| ECDH (P224, P256, P384)     |                                 |                                   | [talib_ecdh_io_buffer] |
| ^                           |                                 |                                   | [talib_ecdh_xy_in_io_buffer] |
| ^                           |                                 |                                   | [talib_ecdh_to_handle] |
| ^                           |                                 |                                   | [talib_ecdh_xy_to_handle] |
| Full Chip Erase             |                                 |                                   | [talib_chip_erase] |
| Cryptoauth Gendig           | [atcab_gendig]                  | [calib_gendig]                    |                                       |
| Generate Key-pair (P256)    | [atcab_genkey_base]             | [calib_genkey_base]               |                                       |
| ^                           | [atcab_genkey]                  | [calib_genkey]                    | [talib_genkey_compat] |
| Get Public Key (P256)       | [atcab_get_pubkey]              | [calib_get_pubkey]                | [talib_get_pubkey_compat] |
| Generate Key-pair (RSA, P224, P256) |                         |                                   | [talib_genkey] |
| Get Public Key (RSA, P224, P256) |                            |                                   | [talib_get_pubkey] |
| Generate AES/HMAC Key       |                                 |                                   | [talib_genkey_symmetric_key] |
| Handle Management           |                                 |                                   | [talib_create_element] |
| ^                           |                                 |                                   | [talib_create_element_with_handle] |
| ^                           |                                 |                                   | [talib_create_ephemeral_element_with_handle] |
| ^                           |                                 |                                   | [talib_create_hmac_element] |
| ^                           |                                 |                                   | [talib_create_hmac_element_with_handle] |
| ^                           |                                 |                                   | [talib_delete_handle] |
| Cryptoauth HMAC             | [atcab_hmac]                    | [calib_hmac]                      |                                       |
| HMAC                        |                                 |                                   | [talib_hmac] |
| Device Revision             | [atcab_info]                    | [calib_info]                      | [talib_info_compat] |
| Device Info                 | [atcab_info_base]               | [calib_info_base]                 |                                       |
| ^                           | [atcab_info_get_latch]          | [calib_info_get_latch]            |                                       |
| ^                           | [atcab_info_set_latch]          | [calib_info_set_latch]            |                                       |
| Key Derivation Function     | [atcab_kdf]                     | [calib_kdf]                       |                                       |
| Device Configuration        | [atcab_lock]                    | [calib_lock]                      |                                       |
| ^                           | [atcab_lock_config_zone]        | [calib_lock_config_zone]          | [talib_lock_config] |
| ^                           | [atcab_lock_config_zone_crc]    | [calib_lock_config_zone_crc]      | [talib_lock_config_with_crc] |
| ^                           | [atcab_lock_data_zone]          | [calib_lock_data_zone]            | [talib_lock_setup] |
| ^                           | [atcab_lock_data_zone_crc]      | [calib_lock_data_zone_crc]        |                                       |
| ^                           | [atcab_lock_data_slot]          | [calib_lock_data_slot]            | [talib_lock_handle] |
| Cryptoauth MAC (SHA256)     | [atcab_mac]                     | [calib_mac]                       |                                       |
| Cryptoauth Nonce            | [atcab_nonce_base]              | [calib_nonce_base]                |                                       |
| ^                           | [atcab_nonce]                   | [calib_nonce]                     |                                       |
| ^                           | [atcab_nonce_load]              | [calib_nonce_load]                |                                       |
| ^                           | [atcab_nonce_rand]              | [calib_nonce_rand]                |                                       |
| ^                           | [atcab_challenge]               | [calib_challenge]                 |                                       |
| ^                           | [atcab_challenge_seed_update]   | [calib_challenge_seed_update]     |                                       |
| Power Management            |                                 |                                   | [talib_power] |
| ^                           |                                 |                                   | [talib_power_reboot] |
| ^                           |                                 |                                   | [talib_power_sleep] |
| ECC Private Key Write       | [atcab_priv_write]              | [calib_priv_write]                |                                       |
| Random Number Generation    | [atcab_random]                  | [calib_random]                    | [talib_random_compat] |
| ^                           | [atcab_read_zone]               | [calib_read_zone]                 |                                       |
| ^                           | [atcab_is_locked]               | [calib_is_locked]                 | [talib_is_locked_compat] |
| ^                           | [atcab_is_config_locked]        | [calib_is_config_locked]          | [talib_is_config_locked]   |
| ^                           | [atcab_is_data_locked]          | [calib_is_data_locked]            | [talib_is_setup_locked] |
| ^                           | [atcab_is_slot_locked]          | [calib_is_slot_locked]            | [talib_is_handle_locked] |
| ^                           | [atcab_read_bytes_zone]         | [calib_read_bytes_zone]           | [talib_read_bytes_zone] |
| ^                           | [atcab_read_serial_number]      | [calib_read_serial_number]        | [talib_info_serial_number_compat] |
| ^                           | [atcab_read_pubkey]             | [calib_read_pubkey]               | [talib_read_pubkey_compat] |
| ^                           | [atcab_read_sig]                | [calib_read_sig]                  | [talib_read_sig_compat] |
| ^                           | [atcab_read_config_zone]        | [calib_read_config_zone]          | [talib_read_config_zone] |
| ^                           | [atcab_cmp_config_zone]         | [calib_cmp_config_zone]           | [talib_cmp_config_zone] |
| ^                           | [atcab_read_enc]                | [calib_read_enc]                  |                                       |
| Cryptoauth Secure Boot      | [atcab_secureboot]              | [calib_secureboot]                |                                       |
| ^                           | [atcab_secureboot_mac]          | [calib_secureboot_mac]            |                                       |
| Device selftest configuration | [atcab_selftest]              | [calib_selftest]                  | [talib_selftest] |
| ^                           | [atcab_sha_base]                | [calib_sha_base]                  | [talib_sha_base_compat] |
| ^                           | [atcab_sha_start]               | [calib_sha_start]                 | [talib_sha_start] |
| ^                           | [atcab_sha_update]              | [calib_sha_update]                | [talib_sha_update_compat] |
| ^                           | [atcab_sha_end]                 | [calib_sha_end]                   | [talib_sha_end_compat] |
| ^                           | [atcab_sha_read_context]        | [calib_sha_read_context]          | [talib_sha_read_context] |
| ^                           | [atcab_sha_write_context]       | [calib_sha_write_context]         | [talib_sha_write_context] |
| ^                           | [atcab_sha]                     | [calib_sha]                       | [talib_sha] |
| ^                           | [atcab_hw_sha2_256]             | [calib_hw_sha2_256]               |                                       |
| ^                           | [atcab_hw_sha2_256_init]        | [calib_hw_sha2_256_init]          |                                       |
| ^                           | [atcab_hw_sha2_256_update]      | [calib_hw_sha2_256_update]        |                                       |
| ^                           | [atcab_hw_sha2_256_finish]      | [calib_hw_sha2_256_finish]        |                                       |
| ^                           | [atcab_sha_hmac_init]           | [calib_sha_hmac_init]             |                                       |
| ^                           | [atcab_sha_hmac_update]         | [calib_sha_hmac_update]           |                                       |
| ^                           | [atcab_sha_hmac_finish]         | [calib_sha_hmac_finish]           |                                       |
| ^                           | [atcab_sha_hmac]                | [calib_sha_hmac]                  | [talib_hmac_compat] |
| RSA                         |                                 |                                   | [talib_rsaenc_encrypt] |
| ^                           |                                 |                                   | [talib_rsaenc_encrypt_with_iobuffer] |
| ^                           |                                 |                                   | [talib_rsaenc_decrypt] |
| Sign (P256)                 | [atcab_sign_base]               | [calib_sign_base]                 |                                       |
| ^                           | [atcab_sign]                    | [calib_sign]                      | [talib_sign_compat] |
| Cryptoauth Sign Internal (P256) | [atcab_sign_internal]       | [calib_sign_internal]             |                                       |
| Sign (RSA, P224, P256)      |                                 |                                   | [talib_sign_external] |
| Sign Internal Message (RSA, P224, P256) |                     |                                   | [talib_sign_internal] |
| Cryptoauth Update Extra Byte | [atcab_updateextra]            | [calib_updateextra]               |                                       |
| ^                           | [atcab_verify]                  | [calib_verify]                    |                                       |
| Verify (External P256 Pubkey) | [atcab_verify_extern]         | [calib_verify_extern]             | [talib_verify_extern_compat] |
| ^                           | [atcab_verify_extern_mac]       | [calib_verify_extern_mac]         |                                       |
| Verify (Stored P256 Pubkey) | [atcab_verify_stored]           | [calib_verify_stored]             | [talib_verify_stored_compat] |
| ^                           | [atcab_verify_stored_mac]       | [calib_verify_stored_mac]         |                                       |
| ^                           | [atcab_verify_validate]         | [calib_verify_validate]           |                                       |
| ^                           | [atcab_verify_invalidate]       | [calib_verify_invalidate]         |                                       |
| ^                           | [atcab_write]                   | [calib_write]                     |                                       |
| ^                           | [atcab_write_zone]              | [calib_write_zone]                | [talib_write_zone] |
| ^                           | [atcab_write_bytes_zone]        | [calib_write_bytes_zone]          | [talib_write_bytes_zone] |
| ^                           | [atcab_write_pubkey]            | [calib_write_pubkey]              | [talib_write_pubkey_compat] |
| ^                           | [atcab_write_config_zone]       | [calib_write_config_zone]         | [talib_write_config_zone] |
| ^                           | [atcab_write_enc]               | [calib_write_enc]                 |                                       |
| ^                           | [atcab_write_config_counter]    | [calib_write_config_counter]      |                                       |


\ingroup TALIB_

[atcab_aes]: @ref atcab_aes
[atcab_aes_decrypt]: @ref atcab_aes_decrypt
[atcab_aes_encrypt]: @ref atcab_aes_encrypt
[atcab_aes_gcm_aad_update]: @ref atcab_aes_gcm_aad_update
[atcab_aes_gcm_decrypt_finish]: @ref atcab_aes_gcm_decrypt_finish
[atcab_aes_gcm_decrypt_update]: @ref atcab_aes_gcm_decrypt_update
[atcab_aes_gcm_encrypt_finish]: @ref atcab_aes_gcm_encrypt_finish
[atcab_aes_gcm_encrypt_update]: @ref atcab_aes_gcm_encrypt_update
[atcab_aes_gcm_init]: @ref atcab_aes_gcm_init
[atcab_aes_gcm_init_rand]: @ref atcab_aes_gcm_init_rand
[atcab_aes_gfm]: @ref atcab_aes_gfm
[atcab_challenge]: @ref atcab_challenge
[atcab_challenge_seed_update]: @ref atcab_challenge_seed_update
[atcab_checkmac]: @ref atcab_checkmac
[atcab_cmp_config_zone]: @ref atcab_cmp_config_zone
[atcab_counter]: @ref atcab_counter
[atcab_counter_increment]: @ref atcab_counter_increment
[atcab_counter_read]: @ref atcab_counter_read
[atcab_derivekey]: @ref atcab_derivekey
[atcab_ecdh]: @ref atcab_ecdh
[atcab_ecdh_base]: @ref atcab_ecdh_base
[atcab_ecdh_enc]: @ref atcab_ecdh_enc
[atcab_ecdh_ioenc]: @ref atcab_ecdh_ioenc
[atcab_ecdh_tempkey]: @ref atcab_ecdh_tempkey
[atcab_ecdh_tempkey_ioenc]: @ref atcab_ecdh_tempkey_ioenc
[atcab_gendig]: @ref atcab_gendig
[atcab_genkey]: @ref atcab_genkey
[atcab_genkey_base]: @ref atcab_genkey_base
[atcab_get_pubkey]: @ref atcab_get_pubkey
[atcab_hmac]: @ref atcab_hmac
[atcab_hw_sha2_256]: @ref atcab_hw_sha2_256
[atcab_hw_sha2_256_finish]: @ref atcab_hw_sha2_256_finish
[atcab_hw_sha2_256_init]: @ref atcab_hw_sha2_256_init
[atcab_hw_sha2_256_update]: @ref atcab_hw_sha2_256_update
[atcab_info]: @ref atcab_info
[atcab_info_base]: @ref atcab_info_base
[atcab_info_get_latch]: @ref atcab_info_get_latch
[atcab_info_set_latch]: @ref atcab_info_set_latch
[atcab_is_locked]: @ref atcab_is_locked
[atcab_is_config_locked]: @ref atcab_is_config_locked
[atcab_is_data_locked]: @ref atcab_is_data_locked
[atcab_is_slot_locked]: @ref atcab_is_slot_locked
[atcab_kdf]: @ref atcab_kdf
[atcab_lock]: @ref atcab_lock
[atcab_lock_config_zone]: @ref atcab_lock_config_zone
[atcab_lock_config_zone_crc]: @ref atcab_lock_config_zone_crc
[atcab_lock_data_slot]: @ref atcab_lock_data_slot
[atcab_lock_data_zone]: @ref atcab_lock_data_zone
[atcab_lock_data_zone_crc]: @ref atcab_lock_data_zone_crc
[atcab_mac]: @ref atcab_mac
[atcab_nonce]: @ref atcab_nonce
[atcab_nonce_base]: @ref atcab_nonce_base
[atcab_nonce_load]: @ref atcab_nonce_load
[atcab_nonce_rand]: @ref atcab_nonce_rand
[atcab_priv_write]: @ref atcab_priv_write
[atcab_random]: @ref atcab_random
[atcab_read_bytes_zone]: @ref atcab_read_bytes_zone
[atcab_read_config_zone]: @ref atcab_read_config_zone
[atcab_read_enc]: @ref atcab_read_enc
[atcab_read_pubkey]: @ref atcab_read_pubkey
[atcab_read_serial_number]: @ref atcab_read_serial_number
[atcab_read_sig]: @ref atcab_read_sig
[atcab_read_zone]: @ref atcab_read_zone
[atcab_secureboot]: @ref atcab_secureboot
[atcab_secureboot_mac]: @ref atcab_secureboot_mac
[atcab_selftest]: @ref atcab_selftest
[atcab_sha]: @ref atcab_sha
[atcab_sha_base]: @ref atcab_sha_base
[atcab_sha_end]: @ref atcab_sha_end
[atcab_sha_hmac]: @ref atcab_sha_hmac
[atcab_sha_hmac_finish]: @ref atcab_sha_hmac_finish
[atcab_sha_hmac_init]: @ref atcab_sha_hmac_init
[atcab_sha_hmac_update]: @ref atcab_sha_hmac_update
[atcab_sha_read_context]: @ref atcab_sha_read_context
[atcab_sha_start]: @ref atcab_sha_start
[atcab_sha_update]: @ref atcab_sha_update
[atcab_sha_write_context]: @ref atcab_sha_write_context
[atcab_sign]: @ref atcab_sign
[atcab_sign_base]: @ref atcab_sign_base
[atcab_sign_internal]: @ref atcab_sign_internal
[atcab_updateextra]: @ref atcab_updateextra
[atcab_verify]: @ref atcab_verify
[atcab_verify_extern]: @ref atcab_verify_extern
[atcab_verify_extern_mac]: @ref atcab_verify_extern_mac
[atcab_verify_invalidate]: @ref atcab_verify_invalidate
[atcab_verify_stored]: @ref atcab_verify_stored
[atcab_verify_stored_mac]: @ref atcab_verify_stored_mac
[atcab_verify_validate]: @ref atcab_verify_validate
[atcab_write]: @ref atcab_write
[atcab_write_bytes_zone]: @ref atcab_write_bytes_zone
[atcab_write_config_counter]: @ref atcab_write_config_counter
[atcab_write_config_zone]: @ref atcab_write_config_zone
[atcab_write_enc]: @ref atcab_write_enc
[atcab_write_pubkey]: @ref atcab_write_pubkey
[atcab_write_zone]: @ref atcab_write_zone

[calib_aes]: @ref calib_aes
[calib_aes_decrypt]: @ref calib_aes_decrypt
[calib_aes_encrypt]: @ref calib_aes_encrypt
[calib_aes_gcm_aad_update]: @ref calib_aes_gcm_aad_update
[calib_aes_gcm_decrypt_finish]: @ref calib_aes_gcm_decrypt_finish
[calib_aes_gcm_decrypt_update]: @ref calib_aes_gcm_decrypt_update
[calib_aes_gcm_encrypt_finish]: @ref calib_aes_gcm_encrypt_finish
[calib_aes_gcm_encrypt_update]: @ref calib_aes_gcm_encrypt_update
[calib_aes_gcm_init]: @ref calib_aes_gcm_init
[calib_aes_gcm_init_rand]: @ref calib_aes_gcm_init_rand
[calib_aes_gfm]: @ref calib_aes_gfm
[calib_challenge]: @ref calib_challenge
[calib_challenge_seed_update]: @ref calib_challenge_seed_update
[calib_checkmac]: @ref calib_checkmac
[calib_cmp_config_zone]: @ref calib_cmp_config_zone
[calib_counter]: @ref calib_counter
[calib_counter_increment]: @ref calib_counter_increment
[calib_counter_read]: @ref calib_counter_read
[calib_derivekey]: @ref calib_derivekey
[calib_ecdh]: @ref calib_ecdh
[calib_ecdh_base]: @ref calib_ecdh_base
[calib_ecdh_enc]: @ref calib_ecdh_enc
[calib_ecdh_ioenc]: @ref calib_ecdh_ioenc
[calib_ecdh_tempkey]: @ref calib_ecdh_tempkey
[calib_ecdh_tempkey_ioenc]: @ref calib_ecdh_tempkey_ioenc
[calib_gendig]: @ref calib_gendig
[calib_genkey]: @ref calib_genkey
[calib_genkey_base]: @ref calib_genkey_base
[calib_get_pubkey]: @ref calib_get_pubkey
[calib_hmac]: @ref calib_hmac
[calib_hw_sha2_256]: @ref calib_hw_sha2_256
[calib_hw_sha2_256_finish]: @ref calib_hw_sha2_256_finish
[calib_hw_sha2_256_init]: @ref calib_hw_sha2_256_init
[calib_hw_sha2_256_update]: @ref calib_hw_sha2_256_update
[calib_info]: @ref calib_info
[calib_info_base]: @ref calib_info_base
[calib_info_get_latch]: @ref calib_info_get_latch
[calib_info_set_latch]: @ref calib_info_set_latch
[calib_is_locked]: @ref calib_is_locked
[calib_is_config_locked]: @ref calib_is_config_locked
[calib_is_data_locked]: @ref calib_is_data_locked
[calib_is_slot_locked]: @ref calib_is_slot_locked
[calib_kdf]: @ref calib_kdf
[calib_lock]: @ref calib_lock
[calib_lock_config_zone]: @ref calib_lock_config_zone
[calib_lock_config_zone_crc]: @ref calib_lock_config_zone_crc
[calib_lock_data_slot]: @ref calib_lock_data_slot
[calib_lock_data_zone]: @ref calib_lock_data_zone
[calib_lock_data_zone_crc]: @ref calib_lock_data_zone_crc
[calib_mac]: @ref calib_mac
[calib_nonce]: @ref calib_nonce
[calib_nonce_base]: @ref calib_nonce_base
[calib_nonce_load]: @ref calib_nonce_load
[calib_nonce_rand]: @ref calib_nonce_rand
[calib_priv_write]: @ref calib_priv_write
[calib_random]: @ref calib_random
[calib_read_bytes_zone]: @ref calib_read_bytes_zone
[calib_read_config_zone]: @ref calib_read_config_zone
[calib_read_enc]: @ref calib_read_enc
[calib_read_pubkey]: @ref calib_read_pubkey
[calib_read_serial_number]: @ref calib_read_serial_number
[calib_read_sig]: @ref calib_read_sig
[calib_read_zone]: @ref calib_read_zone
[calib_secureboot]: @ref calib_secureboot
[calib_secureboot_mac]: @ref calib_secureboot_mac
[calib_selftest]: @ref calib_selftest
[calib_sha]: @ref calib_sha
[calib_sha_base]: @ref calib_sha_base
[calib_sha_end]: @ref calib_sha_end
[calib_sha_hmac]: @ref calib_sha_hmac
[calib_sha_hmac_finish]: @ref calib_sha_hmac_finish
[calib_sha_hmac_init]: @ref calib_sha_hmac_init
[calib_sha_hmac_update]: @ref calib_sha_hmac_update
[calib_sha_read_context]: @ref calib_sha_read_context
[calib_sha_start]: @ref calib_sha_start
[calib_sha_update]: @ref calib_sha_update
[calib_sha_write_context]: @ref calib_sha_write_context
[calib_sign]: @ref calib_sign
[calib_sign_base]: @ref calib_sign_base
[calib_sign_internal]: @ref calib_sign_internal
[calib_updateextra]: @ref calib_updateextra
[calib_verify]: @ref calib_verify
[calib_verify_extern]: @ref calib_verify_extern
[calib_verify_extern_mac]: @ref calib_verify_extern_mac
[calib_verify_invalidate]: @ref calib_verify_invalidate
[calib_verify_stored]: @ref calib_verify_stored
[calib_verify_stored_mac]: @ref calib_verify_stored_mac
[calib_verify_validate]: @ref calib_verify_validate
[calib_write]: @ref calib_write
[calib_write_bytes_zone]: @ref calib_write_bytes_zone
[calib_write_config_counter]: @ref calib_write_config_counter
[calib_write_config_zone]: @ref calib_write_config_zone
[calib_write_enc]: @ref calib_write_enc
[calib_write_pubkey]: @ref calib_write_pubkey
[calib_write_zone]: @ref calib_write_zone


[talib_aes_decrypt]: @ref talib_aes_decrypt
[talib_aes_encrypt]: @ref talib_aes_encrypt
[talib_aes_gcm]: @ref talib_aes_gcm
[talib_aes_gcm_decrypt]: @ref talib_aes_gcm_decrypt
[talib_aes_gcm_encrypt]: @ref talib_aes_gcm_encrypt
[talib_aes_gcm_encrypt_with_rand_iv]: @ref talib_aes_gcm_encrypt_with_rand_iv
[talib_aes_gcm_keyload]: @ref talib_aes_gcm_keyload
[talib_aes_gcm_keyload_with_implicit_iv]: @ref talib_aes_gcm_keyload_with_implicit_iv
[talib_auth_generate_nonce]: @ref talib_auth_generate_nonce
[talib_auth_startup]: @ref talib_auth_startup
[talib_auth_terminate]: @ref talib_auth_terminate
[talib_chip_erase]: @ref talib_chip_erase
[talib_cmac]: @ref talib_cmac
[talib_cmp_config_zone]: @ref talib_cmp_config_zone
[talib_counter]: @ref talib_counter
[talib_counter_increment]: @ref talib_counter_increment
[talib_counter_read]: @ref talib_counter_read
[talib_create_element]: @ref talib_create_element
[talib_create_element_with_handle]: @ref talib_create_element_with_handle
[talib_create_ephemeral_element_with_handle]: @ref talib_create_ephemeral_element_with_handle
[talib_create_hmac_element]: @ref talib_create_hmac_element
[talib_create_hmac_element_with_handle]: @ref talib_create_hmac_element_with_handle
[talib_delete_handle]: @ref talib_delete_handle
[talib_ecdh_compat]: @ref talib_ecdh_compat
[talib_ecdh_io_buffer]: @ref talib_ecdh_io_buffer
[talib_ecdh_to_handle]: @ref talib_ecdh_to_handle
[talib_ecdh_xy_in_io_buffer]: @ref talib_ecdh_xy_in_io_buffer
[talib_ecdh_xy_to_handle]: @ref talib_ecdh_xy_to_handle
[talib_genkey]: @ref talib_genkey
[talib_genkey_compat]: @ref talib_genkey_compat
[talib_genkey_symmetric_key]: @ref talib_genkey_symmetric_key
[talib_get_pubkey]: @ref talib_get_pubkey
[talib_get_pubkey_compat]: @ref talib_get_pubkey_compat
[talib_hmac]: @ref talib_hmac
[talib_hmac_compat]: @ref talib_hmac_compat
[talib_info_compat]: @ref talib_info_compat
[talib_info_serial_number_compat]: @ref talib_info_serial_number_compat
[talib_is_handle_locked]: @ref talib_is_handle_locked
[talib_is_locked_compat]: @ref talib_is_locked_compat
[talib_is_config_locked]: @ref talib_is_config_locked
[talib_is_setup_locked]: @ref talib_is_setup_locked
[talib_lock_config]: @ref talib_lock_config
[talib_lock_config_with_crc]: @ref talib_lock_config_with_crc
[talib_lock_handle]: @ref talib_lock_handle
[talib_lock_setup]: @ref talib_lock_setup
[talib_power]: @ref talib_power
[talib_power_reboot]: @ref talib_power_reboot
[talib_power_sleep]: @ref talib_power_sleep
[talib_random_compat]: @ref talib_random_compat
[talib_read_bytes_zone]: @ref talib_read_bytes_zone
[talib_read_config_zone]: @ref talib_read_config_zone
[talib_read_pubkey_compat]: @ref talib_read_pubkey_compat
[talib_read_sig_compat]: @ref talib_read_sig_compat
[talib_rsaenc_decrypt]: @ref talib_rsaenc_decrypt
[talib_rsaenc_encrypt]: @ref talib_rsaenc_encrypt
[talib_rsaenc_encrypt_with_iobuffer]: @ref talib_rsaenc_encrypt_with_iobuffer
[talib_selftest]: @ref talib_selftest
[talib_sha]: @ref talib_sha
[talib_sha_base_compat]: @ref talib_sha_base_compat
[talib_sha_end_compat]: @ref talib_sha_end_compat
[talib_sha_read_context]: @ref talib_sha_read_context
[talib_sha_start]: @ref talib_sha_start
[talib_sha_update_compat]: @ref talib_sha_update_compat
[talib_sha_write_context]: @ref talib_sha_write_context
[talib_sign_compat]: @ref talib_sign_compat
[talib_sign_external]: @ref talib_sign_external
[talib_sign_internal]: @ref talib_sign_internal
[talib_verify_extern_compat]: @ref talib_verify_extern_compat
[talib_verify_stored_compat]: @ref talib_verify_stored_compat
[talib_write_bytes_zone]: @ref talib_write_bytes_zone
[talib_write_config_zone]: @ref talib_write_config_zone
[talib_write_pubkey_compat]: @ref talib_write_pubkey_compat
[talib_write_zone]: @ref talib_write_zone

