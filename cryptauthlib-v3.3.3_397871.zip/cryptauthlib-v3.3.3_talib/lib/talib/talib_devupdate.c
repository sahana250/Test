/**
 * \file
 * \brief Basic DevUpdate commands for the Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes devupdate command to Update one block of the nonvolatile operating code
 *                  within the Vega device.
 *
 *  \param[in]  device      device context pointer
 *  \param[in]  mode        Block ID. 0x00 through 0xFE legal
 *  \param[in]  data        data to Update image block
 *  \param[in]  data_length length of update image block in bytes (maximum size is 1024)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_devupdate_base(ATCADevice device, const uint8_t mode, const uint8_t* data, const
                                 uint16_t data_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    if ((NULL == device) || (NULL == data))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else if ((data_length > TA_DEV_UPDATE_MAX_BLOCK_SIZE) || (mode == 0xFF))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid parameter received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_DEVUPDATE;
        packet->param1 = mode;
        packet->param2.val32 = 0;

        //Copy the data into packet
        memcpy(packet->data, data, data_length);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(data_length + ATCA_CMD_BUILD_MIN_LENGTH);

        if (ATCA_SUCCESS != (status = (talib_execute_command(packet, device))))
        {
            status = ATCA_TRACE(status, "talib_devupdate_base - execution failed");
        }

        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Initialize the Devupdate context stucture.
 *
 *  \param[out]  ctx                devupdate context pointer
 *  \param[in]   first_block_size   size of first block
 *  \param[in]   second_block_szie  size of remaining block
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_devupdate_init_ctx(talib_devupdate_ctx_t* ctx, const uint16_t first_block_size,
                                     const int16_t remaining_block_size)
{
    ATCA_STATUS status = ATCA_SUCCESS;

    if (NULL == ctx)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else if (TA_DEV_UPDATE_MAX_IMAGE_SIZE < (first_block_size + (uint16_t)remaining_block_size))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid length received");
    }
    else
    {
        ctx->block_id = 0;
        ctx->first_block_size = first_block_size;
        ctx->remaining_block_size = (uint16_t)remaining_block_size;
    }

    return status;
}

/** \brief TA API - Executes devupdate command to Update the first block (image) of the nonvolatile operating
 *                  code within the Vega device.
 *
 *  \param[in]      device             device context pointer
 *  \param[in,out]  ctx                As input, devupdate context pointer
 *                                     As output, Update the block id after successful first block update
 *  \param[in]      first_block        first block of the image
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_devupdate_first_block(ATCADevice device, talib_devupdate_ctx_t* ctx, const uint8_t*
                                        first_block)
{
    ATCA_STATUS status = ATCA_SUCCESS;

    do
    {
        if ((NULL == device) || (NULL == first_block) || (NULL == ctx))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL Pointer received");
            break;
        }

        if (ctx->block_id != 0x00)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid parameter received");
            break;
        }

        // Update the first block of the image
        status = talib_devupdate_base(device, ctx->block_id, first_block, ctx->first_block_size);
        ctx->block_id++;

        // Device wont respond to last block... Treat this as success
        if ((ctx->remaining_block_size == 0) && (status == ATCA_RX_TIMEOUT))
        {
            status = ATCA_SUCCESS;
        }

        if (ATCA_SUCCESS != status)
        {
            status = ATCA_TRACE(status, "talib_devupdate_first_block - execution failed");
            break;
        }
    }
    while (0);

    return status;
}

/** \brief TA API - Executes devupdate command to Update the subsequent block (image) of the nonvolatile operating
 *                  code within the Vega device.
 *
 *  \param[in]       device             device context pointer
 *  \param[in,out]   ctx                As input, devupdate context pointer
 *                                      As output, Update the block id and remaining size
 *  \param[in]       block              block of the image to be updated in the device
 *  \param[in,out]   block_len          As input, length of the block
 *                                      As output, updated block length
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_devupdate_subsequent_block(ATCADevice device, talib_devupdate_ctx_t* ctx, const
                                             uint8_t* block, uint16_t* const block_len)
{
    ATCA_STATUS status = ATCA_SUCCESS;

    do
    {
        if ((NULL == device) || (NULL == ctx) || (NULL == block) || (NULL == block_len))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL Pointer Received");
            break;
        }

        if ((ctx->block_id > 0xFE) || (ctx->remaining_block_size <= 0) || (*block_len <= 0))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid Parameter received");
            break;
        }

        // Adjust block length
        if (*block_len > ctx->remaining_block_size)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Total block length is higher than allowed");
            break;
        }
        else if (*block_len >= TA_DEV_UPDATE_MAX_BLOCK_SIZE)
        {
            *block_len = TA_DEV_UPDATE_MAX_BLOCK_SIZE;
        }


        // Update the block to device
        status = talib_devupdate_base(device, ctx->block_id, block, *block_len);
        ctx->block_id++;
        ctx->remaining_block_size -= *block_len;

        // Device wont respond to last block... Treat this as success
        if ((ctx->remaining_block_size == 0) && (status == ATCA_RX_TIMEOUT))
        {
            status = ATCA_SUCCESS;
        }

        if (ATCA_SUCCESS != status)
        {
            status = ATCA_TRACE(status, "talib_devupdate_subsequent_block - execution failed");
            break;
        }
    }
    while (0);

    return status;
}

/** \brief TA API - Executes devupdate command to Update the complete image of the nonvolatile operating
 *                  code within the Vega device.
 *
 *  NOTE: This api update the first block without an authorization session.
 *        (Auth_options bit (in configuration memrory) should be 0)
 *
 *  \param[in]  image        Update image of the non volatile operating code
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_devupdate_image(ATCADevice device, const uint8_t* image)
{
    ATCA_STATUS status;
    talib_devupdate_ctx_t ctx;
    uint16_t first_block_size;
    uint16_t remaining_block_size;
    uint16_t block_len = 0;
    const uint8_t* block = image;

    do
    {
        if ((NULL == device) || (NULL == image))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        // Get the first block size and remaining block size
        first_block_size = ((((uint16_t)image[3]) << 8u) | image[2]);
        remaining_block_size = ((((uint16_t)image[5]) << 8u) | image[4]);

        // Initialize the devupdate context
        if (ATCA_SUCCESS != (status = talib_devupdate_init_ctx(&ctx, first_block_size, (int16_t)remaining_block_size)))
        {
            status = ATCA_TRACE(status, "talib_devupdate_init_ctx - Execution failed");
            break;
        }

        // Update the first block of the image
        if (ATCA_SUCCESS != (status = talib_devupdate_first_block(device, &ctx, block)))
        {
            status = ATCA_TRACE(status, "talib_devupdate_first_block - Execution failed");
            break;
        }

        // Update block index for next block
        block += ctx.first_block_size;

        // Update the subsequent block
        while (ctx.remaining_block_size > 0)
        {
            block_len = (uint16_t)ctx.remaining_block_size;
            if (ATCA_SUCCESS != (status = talib_devupdate_subsequent_block(device, &ctx, block,
                                                                           &block_len)))
            {
                status = ATCA_TRACE(status, "talib_devupdate_subsequent_block - Execution failed");
                break;
            }

            // Update block index for next block
            block += block_len;
        }
    }
    while (0);

    return status;
}
