/**
 * \file
 * \brief Basic AES commands for the Trust Anchor Devices.
 *
 *
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Loads a Key into internal key memory for AES operation.
 *                   This must be called before performing AES operations
 *
 * \param[in]  device      Device object that holds the device related informations
 * \param[in]  mode        Mode value for key load operation
 * \param[in]  iv_index    IV offset in the Key handle. Applicable only for TLS1.2 IV mode
 * \param[in]  key_index   Key Offset in the Key group / Handle
 * \param[in]  key_handle  Handle of the Symmetric key to be used
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_keyload(ATCADevice device, const uint8_t mode, const uint8_t iv_index,
                              const uint8_t key_index, const uint16_t key_handle)
{
    ATCA_TA_CmdPacket * packet = NULL;
    ATCA_STATUS status;

    if (device == NULL)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        // build a AES command
        packet->opcode = TA_OPCODE_AES;
        packet->param1 = mode;
        packet->param2.val8[0] = iv_index;
        packet->param2.val8[1] = key_index;
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);
        packet->length = ATCA_UINT16_HOST_TO_BE(TA_CMD_SIZE_MIN);

        status = talib_execute_command(packet, device);

        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Perform an AES-128 ECB encrypt or decrypt operation with a key in the device.
 *
 * \param[in]  device       Device object that holds the device related informations
 * \param[in]  mode         Mode value for AES operation, including encryption or decryption setting
 * \param[in]  aes_in       Input text to be encrypted or decrypted (16 bytes).
 * \param[out] aes_out      Output plaintext or ciphertext is returned here (16 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_ecb(ATCADevice device, const uint8_t mode, const uint8_t* aes_in,
                          uint8_t* aes_out)
{
    ATCA_TA_CmdPacket* packet = NULL;
    ATCA_STATUS status = ATCA_SUCCESS;
    uint16_t length;

    if ((NULL == device) || (NULL == aes_in))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        // build a AES command
        packet->opcode = TA_OPCODE_AES;
        packet->param1 = mode;
        packet->param2.val32 = 0;
        memcpy(packet->data, aes_in, TA_AES_DATA_SIZE);
        packet->length = ATCA_UINT16_HOST_TO_BE(TA_AES_DATA_SIZE + TA_CMD_SIZE_MIN);

        status = talib_execute_command(packet, device);

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;

            length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;
            if (aes_out && (length >= TA_AES_DATA_SIZE))
            {
                memcpy(aes_out, resp_packet->data, TA_AES_DATA_SIZE);
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Perform an AES-128 GCM encrypt or decrypt operation with a key in the device
 *
 * \param[in] device       Device object that holds the device related informations
 * \param[in] mode              Mode value for AES operation, including encryption or decryption setting
 * \param[in] aad_length        Length of the auth_data to include in GCM operation
 * \param[in] message_length    Length of the message to include in GCM operation
 * \param[in,out] iv                Initialization vector.
 * \param[in] aad               AAD data
 * \param[in] message           Cipher text for decrypt or Plain text for encrypt
 * \param[in,out] tag            Authentication tag to be used or returned
 * \param[out] data_out         The output data plain text or decrypt text.
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_gcm(ATCADevice device, const uint8_t mode, const uint16_t aad_length,
                          const uint16_t message_length, uint8_t* iv, const uint8_t* aad,
                          const uint8_t* message, uint8_t* tag, uint8_t* data_out)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket *packet = NULL;
    ATCA_TA_RspPacket *resp_packet;
    uint16_t length;
    uint8_t *data;

    if (device == NULL)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        do
        {
            // build a AES command
            packet->opcode = TA_OPCODE_AES;
            packet->param1 = mode;
            packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(aad_length);
            packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(message_length);

            data = packet->data;

            if ((aad_length + message_length) > TA_AES_GCM_MAX_DATA_SIZE)
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid length received");
                break;
            }

            if (TA_AES_RAND_IV != (TA_AES_RAND_IV & mode))
            {
                if (NULL == iv)
                {
                    status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
                    break;
                }

                memcpy(data, iv, TA_AES_GCM_IV_LENGTH);
                data += TA_AES_GCM_IV_LENGTH;
            }

            if (aad_length)
            {
                if (NULL == aad)
                {
                    status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
                    break;
                }

                memcpy(data, aad, aad_length);
                data += aad_length;
            }

            if (message_length)
            {
                if (NULL == message)
                {
                    status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
                    break;
                }

                memcpy(data, message, message_length);
                data += message_length;
            }

            if (TA_AES_ACTION_DECRYPT == (TA_AES_ACTION_MASK & mode))
            {
                if (NULL == tag)
                {
                    status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
                    break;
                }

                memcpy(data, tag, TA_AES_GCM_TAG_LENGTH);
                data += TA_AES_GCM_TAG_LENGTH;
            }

            //Update length including length, opcode, param1, param2 and CRC
            packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) + ATCA_CMD_BUILD_MIN_LENGTH);

            if (ATCA_SUCCESS != (status = talib_execute_command(packet, device)))
            {
                status = ATCA_TRACE(status, "talib_aes_gcm - Execution failed");
                break;
            }

            resp_packet = (ATCA_TA_RspPacket*)packet;
            data = resp_packet->data;

            length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;
            if (length >= message_length)
            {
                if (data_out)
                {
                    memcpy(data_out, data, message_length);
                }

                data += message_length;
                length -= message_length;
            }
            else
            {
                status = ATCA_TRACE(ATCA_INVALID_SIZE, "Less bytes received from device");
                break;
            }

            if (TA_AES_ACTION_ENCRYPT == (TA_AES_ACTION_MASK & mode))
            {
                if (length >= TA_AES_GCM_TAG_LENGTH)
                {
                    if (tag)
                    {
                        memcpy(tag, data, TA_AES_GCM_TAG_LENGTH);
                    }
                    data += TA_AES_GCM_TAG_LENGTH;
                    length -= TA_AES_GCM_TAG_LENGTH;
                }
                else
                {
                    status = ATCA_TRACE(ATCA_INVALID_SIZE, "Less bytes received from device");
                    break;
                }
            }

            if (TA_AES_RAND_IV == (TA_AES_RAND_IV & mode))
            {
                if (length >= TA_AES_GCM_IV_LENGTH)
                {
                    if (iv)
                    {
                        memcpy(iv, data, TA_AES_GCM_IV_LENGTH);
                    }
                    data += TA_AES_GCM_IV_LENGTH;
                    length -= TA_AES_GCM_IV_LENGTH;
                }
                else
                {
                    status = ATCA_TRACE(ATCA_INVALID_SIZE, "Less bytes received from device");
                    break;
                }
            }
        }
        while (0);

        talib_packet_free(packet);
    }

    return status;
}


/** \brief Perform an AES-128 encrypt operation with a key in the device.
 *
 * \param[in]  device      Device object that holds the device related informations
 * \param[in]  key_id      Key handle containing the AES key.
 * \param[in]  key_block   Index within the key handle to be used as AES key.
 * \param[in]  plaintext   Input plaintext to be encrypted (16 bytes).
 * \param[out] ciphertext  Output ciphertext is returned here (16 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_encrypt(ATCADevice device, const uint16_t key_id, const uint8_t key_block,
                              const uint8_t* plaintext, uint8_t* ciphertext)
{
    ATCA_STATUS status;

    do
    {
        if (ATCA_SUCCESS != (status = talib_aes_keyload(device, TA_AES_MODE_ECB, 0, key_block, key_id)))
        {
            ATCA_TRACE(status, "talib_aes_keyload - Failed");
            break;
        }

        if (ATCA_SUCCESS != (status = talib_aes_ecb(device, TA_AES_MODE_ECB | TA_AES_ACTION_ENCRYPT, plaintext, ciphertext)))
        {
            ATCA_TRACE(status, "atcab_ta_aes_ecb - Failed");
            break;
        }
    }
    while (0);


    return status;
}

/** \brief Perform an AES-128 decrypt operation with a key in the device.
 *
 * \param[in]   device      Device object that holds the device related informations
 * \param[in]   key_id      Key handle containing the AES key.
 * \param[in]   key_block   Index of the 16-byte block to use within the key
 *                          location for the actual key.
 * \param[in]   ciphertext  Input ciphertext to be decrypted (16 bytes).
 * \param[out]  plaintext   Output plaintext is returned here (16 bytes).
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_decrypt(ATCADevice device, const uint16_t key_id, const uint8_t key_block,
                              const uint8_t* ciphertext, uint8_t* plaintext)
{
    ATCA_STATUS status;

    do
    {
        if (ATCA_SUCCESS != (status = talib_aes_keyload(device, TA_AES_MODE_ECB, 0, key_block, key_id)))
        {
            ATCA_TRACE(status, "talib_aes_keyload - Failed");
            break;
        }

        if (ATCA_SUCCESS != (status = talib_aes_ecb(device, TA_AES_MODE_ECB | TA_AES_ACTION_DECRYPT, ciphertext, plaintext)))
        {
            ATCA_TRACE(status, "talib_aes_ecb - Failed");
            break;
        }
    }
    while (0);


    return status;
}


/** \brief Performs loading of an AES-128 key to the engine in device.
 *
 * \param[in]   device      Device object that holds the device related informations
 * \param[in]   key_id      Key handle containing the AES key.
 * \param[in]   key_block   Index of the byte block to use within the key
 *                          location for the actual key.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_gcm_keyload(ATCADevice device, const uint16_t key_id, const uint8_t key_block)
{
    return talib_aes_keyload(device, TA_AES_ACTION_KEY_LOAD | TA_AES_MODE_GCM, 0, key_block,
                             key_id);
}


/** \brief Performs loading of an AES-128 key & 4 byte iv to the engine in device.
 *
 * \param[in]   device      Device object that holds the device related informations
 * \param[in]   key_id      Key handle containing the AES key.
 * \param[in]   key_block   Index of the byte block to use within the key
 *                          location for the actual key.
 * \param[in]   iv_index    Index to the 4 byte IV in the key_id handle for GCM operation.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_gcm_keyload_with_implicit_iv(ATCADevice device, const uint16_t key_id,
                                                   const uint8_t key_block, const uint8_t iv_index)
{
    return talib_aes_keyload(device, TA_AES_ACTION_KEY_LOAD | TA_AES_MODE_GCM | TA_AES_TLS_IV,
                             iv_index, key_block, key_id);
}


/** \brief TA API - Perform an AES-128 GCM encrypt operation with a key in the device and with given
 *  Additional authentication data, Initialization vector and the plain text.
 *
 * \param[in] device            Device object that holds the device related informations
 * \param[in] aad               AAD data
 * \param[in] aad_length        Length of the auth_data to include in GCM operation
 * \param[in] iv                The 12 byte Initialization vector for GCP operation.
 * \param[in] plaintext         Plain text to be encrypted
 * \param[in] plaintext_length  Length of the plaintext to include in GCM operation
 * \param[out] ciphertext       The output cipher text
 * \param[out] tag              Authentication tag to be returned
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_gcm_encrypt(ATCADevice device, const uint8_t* aad, const uint16_t aad_length,
                                  const uint8_t* iv, const uint8_t* plaintext, const uint16_t plaintext_length, uint8_t* ciphertext, uint8_t* tag)
{
    return talib_aes_gcm(device, TA_AES_MODE_GCM | TA_AES_ACTION_ENCRYPT, aad_length,
                         plaintext_length, (uint8_t*)iv, aad, plaintext, tag, ciphertext);
}


/** \brief TA API - Perform an AES-128 GCM encrypt operation with a key in the device, with
 *   given Additional authentication data, plain text and random Initialization vector generated
 *   within device.
 *
 * \param[in] device            Device object that holds the device related informations
 * \param[in] aad               AAD data
 * \param[in] aad_length        Length of the auth_data to include in GCM operation
 * \param[in] plaintext         Plain text to be encrypted
 * \param[in] plaintext_length  Length of the plaintext to include in GCM operation
 * \param[out] ciphertext       The output cipher text
 * \param[out] tag              Authentication tag to be returned
 * \param[out] iv               The 12 byte Initialization vector returned.
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_gcm_encrypt_with_rand_iv(ATCADevice device, const uint8_t* aad,
                                               const uint16_t aad_length, const uint8_t* plaintext, const uint16_t plaintext_length, uint8_t* ciphertext, uint8_t* tag, uint8_t* iv)
{
    return talib_aes_gcm(device, TA_AES_MODE_GCM | TA_AES_ACTION_ENCRYPT | TA_AES_RAND_IV, aad_length,
                         plaintext_length, iv, aad, plaintext, tag, ciphertext);
}


/** \brief TA API - Perform an AES-128 GCM decrypt operation with a key in the device and with given
 *  Additional authentication data, Initialization vector, TAG and the cipher text.
 *
 * \param[in] device             Device object that holds the device related informations
 * \param[in] aad                AAD data
 * \param[in] aad_length         Length of the auth_data to include in GCM operation
 * \param[in] iv                 The 12 byte Initialization vector for GCP operation
 * \param[in] tag                Authentication tag to be verified
 * \param[in] ciphertext         Cipher text to be decrypted
 * \param[in] ciphertext_length  Length of the ciphertext to include in GCM operation
 * \param[out] plaintext         The output cipher text
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_aes_gcm_decrypt(ATCADevice device, const uint8_t* aad, const uint16_t aad_length,
                                  const uint8_t* iv, const uint8_t* tag, const uint8_t* ciphertext, const uint16_t ciphertext_length, uint8_t* plaintext)
{
    return talib_aes_gcm(device, TA_AES_MODE_GCM | TA_AES_ACTION_DECRYPT, aad_length,
                         ciphertext_length, (uint8_t*)iv, aad, ciphertext, (uint8_t*)tag, plaintext);
}
