#ifndef TALIB_FASTCRYPTO_H_
#define TALIB_FASTCRYPTO_H_


/** \defgroup TALIB_ Basic TA100 API methods (talib_)
 *
 * \brief
 * These methods provide the most convenient, simple API to TA100 chips
 *
   @{ */

#ifdef __cplusplus
extern "C" {
#endif

/* TA Fast Crypto Engine */

#define ATCA_FAST_CRYPTO_RD_FSR                         0xB0
#define ATCA_FAST_CRYPTO_WR_FCR                         0xA0
#define ATCA_FAST_CRYPTO_WR_FCC                         0xE0
#define ATCA_FAST_CRYPTO_RD_FAST_FIRST                  0x90
#define ATCA_FAST_CRYPTO_RD_FAST_ADDL                   0xD0
#define ATCA_FAST_CRYPTO_WR_FAST_DATA                   0x80
#define ATCA_FAST_CRYPTO_WR_FAST_LAST                   0xC0
#define ATCA_FAST_CRYPTO_WR_FAST_MASK                   0x30
#define ATCA_FAST_CRYPTO_FSR_FERROR_MASK                0x80
#define ATCA_FAST_CRYPTO_FSR_FINPUT_MASK                0x20
#define ATCA_FAST_CRYPTO_FSR_FOUPUT_MASK                0x10
#define ATCA_FAST_CRYPTO_FSR_FINIT_MASK                 0x01
#define ATCA_FAST_CRYPTO_SHA_BLOCK_SIZE                 64
#define ATCA_FAST_CRYPTO_HMAC_BLOCK_SIZE                64
#define ATCA_FAST_CRYPTO_CMAC_BLOCK_SIZE                16
#define ATCA_FAST_CRYPTO_SHA_SIZE                       32
#define ATCA_FAST_CRYPTO_HMAC_SIZE                      32
#define ATCA_FAST_CRYPTO_CMAC_SIZE                      16
#define ATCA_FAST_CRYPTO_CMAC_MODE                      4
#define ATCA_FAST_CRYPTO_FKEY_POS                       3

/* TA Fast Crypto Modes */
#define ATCA_FCE_MODE_SHA                               0
#define ATCA_FCE_MODE_HMAC                              1
#define ATCA_FCE_MODE_CMAC                              2

/* fce_ctx_t contains device context, internal buffer and its size */
typedef struct fce_ctx
{
    ATCADevice device;        /**< Device context pointer */
    uint8_t    mode;          /**< SHA/HMAC/CMAC */
    uint8_t    buffer[64];    /**< Temporary buffer to accumulate partial data */
    uint16_t   counter;       /**< Bytes held in the buffer */
} fce_ctx_t;

//Fast Crypto Instruction functions

ATCA_STATUS talib_execute_instruction(ATCA_TA_InstrPacket* packet, ATCADevice device);
ATCA_STATUS talib_fce_init(ATCADevice device, const uint8_t mode, const uint32_t key_handle, uint32_t* const written_map);
ATCA_STATUS talib_fce_execute(ATCADevice device, ATCA_TA_InstrPacket* packet);

ATCA_STATUS talib_fce_sha_start(fce_ctx_t* ctx);
ATCA_STATUS talib_fce_sha_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block);
ATCA_STATUS talib_fce_sha_finish(fce_ctx_t* ctx, uint8_t* const digest);
ATCA_STATUS talib_fce_sha(ATCADevice device, const uint8_t* message, const size_t message_length, uint8_t* const digest);

ATCA_STATUS talib_fce_hmac_start(fce_ctx_t* ctx, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map);
ATCA_STATUS talib_fce_hmac_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block);
ATCA_STATUS talib_fce_hmac_finish(fce_ctx_t* ctx, uint8_t* const hmac);
ATCA_STATUS talib_fce_hmac(ATCADevice device, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map, const uint8_t* message, const size_t message_length, uint8_t* const hmac);

ATCA_STATUS talib_fce_cmac_start(fce_ctx_t* ctx, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map);
ATCA_STATUS talib_fce_cmac_update(fce_ctx_t* ctx, const uint8_t* message, const size_t message_length, const bool is_last_block);
ATCA_STATUS talib_fce_cmac_finish(fce_ctx_t* ctx, uint8_t* const cmac);
ATCA_STATUS talib_fce_cmac(ATCADevice device, const uint8_t mode, const uint16_t key_handle, const uint8_t key_index, uint32_t* const written_map, const uint8_t* message, const size_t message_length, uint8_t* const cmac);

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* TALIB_FASTCRYPTO_H_ */
