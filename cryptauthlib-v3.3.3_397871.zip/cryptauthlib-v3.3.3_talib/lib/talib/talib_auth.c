/**
 * \file
 * \brief Auth Session commands for Trust Anchor Devices.
 *
 * The Lock command prevents future modifications of the Configuration handle,
 * non volatile shared data element and setup phase.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"
#include "atca_device.h"

static const char talib_auth_label_hmac[] = "\001hmac_key\000";
static const char talib_auth_label_cmac[] = "\001cmac_key\000";
static const char talib_auth_label_gcm[] = "\001gcm__key\000";

/** \brief TA API - Calculate the session key for the authenticated session
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_hmac_kdf(
    ATCADevice device,      /**< [in] Device context pointer */
    uint16_t   max_cmd,     /**< [in] Maximum number of commands allowed in the session */
    uint16_t   auth_flags,  /**< [in] authorization flag */
    uint8_t    i_nonce[16], /**< [in] Initiator nonce value */
    uint8_t    r_nonce[16]  /**< [in] Responder nonce value */
    )
{
    ATCA_STATUS status = ATCA_SUCCESS;
    atcac_hmac_sha256_ctx ctx;
    uint16_t temp16;
    size_t outlen;

    if (!device || !i_nonce || !r_nonce)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }

    if (ATCA_SUCCESS == status)
    {
        status = atcac_sha256_hmac_init(&ctx, device->session_key, device->session_key_len);
    }

    if (ATCA_SUCCESS == status)
    {
        if (TA_AUTH_STATE_HMAC == device->session_state)
        {
            (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)talib_auth_label_hmac, 10);
            outlen = 256;
        }
        else if (TA_AUTH_STATE_CMAC == device->session_state)
        {
            (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)talib_auth_label_cmac, 10);
            outlen = 128;
        }
        else
        {
            (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)talib_auth_label_gcm, 10);
            outlen = 208;
        }

        (void)atcac_sha256_hmac_update(&ctx, i_nonce, 16);
        (void)atcac_sha256_hmac_update(&ctx, r_nonce, 16);

        temp16 = ATCA_UINT16_HOST_TO_BE(max_cmd);
        (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)&temp16, 2);

        temp16 = ATCA_UINT16_HOST_TO_LE(auth_flags);
        (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)&temp16, 2);

        temp16 = ATCA_UINT16_HOST_TO_BE((uint16_t)outlen);
        (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)&temp16, 2);

        outlen /= 8;

        status = atcac_sha256_hmac_finish(&ctx, device->session_key, &outlen);
    }

    return status;
}

/** \brief TA API - Create an hmac for a packet in an authenticated session
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_create_hmac(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t *  data,            /**< [in] Data to create an HMAC for */
    size_t     data_len,        /**< [in] Length of the input data */
    uint8_t *  hmac_out,        /**< [out] Buffer to place the resulting hmac digest */
    size_t *   hmac_len         /**< [in.out] Length of the hmac buffer */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (device && data && hmac_out && hmac_len)
    {
        atcac_hmac_sha256_ctx ctx;
        uint16_t counter = ATCA_UINT16_HOST_TO_BE(device->session_counter);

        atcac_sha256_hmac_init(&ctx, device->session_key, device->session_key_len);
        (void)atcac_sha256_hmac_update(&ctx, (uint8_t*)&counter, 2);
        (void)atcac_sha256_hmac_update(&ctx, data, data_len);

        status = atcac_sha256_hmac_finish(&ctx, hmac_out, hmac_len);
    }
    return status;
}

#ifdef ATCA_TA100_AES_AUTH_SUPPORT

/** \brief TA API - Create a CMAC for a packet in an authenticated session
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_create_cmac(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t*   data,            /**< [in] Data to create an CMAC for */
    size_t     data_len,        /**< [in] Length of the input data */
    uint8_t*   cmac_out,        /**< [out] Buffer to place the resulting cmac digest */
    size_t*    cmac_len         /**< [in.out] Length of the hmac buffer */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (device && data && cmac_out && cmac_len)
    {
        atcac_aes_cmac_ctx ctx;
        uint16_t counter = ATCA_UINT16_HOST_TO_BE(device->session_counter);

        (void)atcac_aes_cmac_init(&ctx, device->session_key, device->session_key_len);
        (void)atcac_aes_cmac_update(&ctx, (uint8_t*)&counter, 2);
        (void)atcac_aes_cmac_update(&ctx, data, data_len);

        status = atcac_aes_cmac_finish(&ctx, cmac_out, cmac_len);
    }
    return status;
}

/** \brief TA API - Encrypt a packet with AES-GCM and append the tag
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_encrypt_gcm(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t *  data,            /**< [in] Data to encrypt and MAC */
    size_t     data_len,        /**< [in] Length of the input data */
    uint8_t *  aad,             /**< [in] Additional Authentication Data */
    size_t     aad_len,         /**< [in] length of the additional auth data */
    uint8_t *  out,             /**< [out] output buffer for ciphertext+tag */
    size_t     tag_len          /**< [in] length of the tag to append to the ciphertext */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint8_t buf[12];

    if (device && out && tag_len && (aad_len < sizeof(buf) - 2))
    {
        atcac_aes_gcm_ctx ctx;
        uint16_t counter = ATCA_UINT16_HOST_TO_BE(device->session_counter);
        size_t outlen = data_len;

        memcpy(buf, (uint8_t*)&counter, 2);
        memcpy(&buf[2], &device->session_key[16], 10);

        atcac_aes_gcm_encrypt_start(&ctx, device->session_key, 16, buf, 12);

        memcpy(&buf[2], aad, aad_len);

#ifdef ATCA_WOLFSSL
        status = atcac_aes_gcm_encrypt(&ctx, data, data_len, out, &out[outlen],
                                       tag_len, buf, aad_len + 2);
#else
        (void)atcac_aes_gcm_aad_update(&ctx, buf, aad_len + 2);
        if (data && data_len)
        {
            (void)atcac_aes_gcm_encrypt_update(&ctx, data, data_len, out, &outlen);
        }
        status = atcac_aes_gcm_encrypt_finish(&ctx, &out[outlen], tag_len);
#endif
    }
    return status;
}

/** \brief TA API - Decrypt an AES-GCM packet and verify the authentication tag
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_decrypt_gcm(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t*   data,            /**< [in] Ciphertext to decrypt */
    size_t     data_len,        /**< [in] Length of the input ciphertext */
    uint8_t*   aad,             /**< [in] Additional Authentication Data */
    size_t     aad_len,         /**< [in] length of the additional auth data */
    uint8_t*   out,             /**< [out] output buffer for plaintext */
    size_t     tag_len          /**< [in] length of the tag to verify */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint8_t buf[12];

    if (device && data && out && (aad_len < sizeof(buf) - 2))
    {
        bool is_verified = false;
        atcac_aes_gcm_ctx ctx;
        uint16_t counter = ATCA_UINT16_HOST_TO_BE(device->session_counter);
        size_t outlen = data_len;

        memcpy(buf, (uint8_t*)&counter, 2);
        memcpy(&buf[2], &device->session_key[16], 10);

        atcac_aes_gcm_decrypt_start(&ctx, device->session_key, 16, buf, 12);
        memcpy(&buf[2], aad, aad_len);

#ifdef ATCA_WOLFSSL
        status = atcac_aes_gcm_decrypt(&ctx, data, data_len, out, &data[data_len],
                                       tag_len, buf, aad_len + 2, &is_verified);
#else
        (void)atcac_aes_gcm_aad_update(&ctx, buf, aad_len + 2);

        (void)atcac_aes_gcm_decrypt_update(&ctx, data, data_len, out, &outlen);
        status = atcac_aes_gcm_decrypt_finish(&ctx, &data[data_len], tag_len, &is_verified);
#endif
        if (ATCA_SUCCESS == status)
        {
            if (!is_verified)
            {
                status = TA_VALIDATION_ERROR;
            }
        }
    }
    return status;
}
#endif

/** \brief TA API - Exchange nonces between host and device
 *  \note This step establishes the "i_nonce"
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_generate_nonce(
    ATCADevice device,      /**< [in] Device context pointer */
    uint16_t   auth_handle, /**< [in] Handle Id to hold the auth session context - must be empty/invalid */
    uint16_t   options,     /**< [in] Option flags */
    uint8_t    i_nonce[16]  /**< [in,out] nonce value */
    )
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket * packet = NULL;
    uint16_t length;

    /* Check options & parameters for the correct combination */
    if (!device || !i_nonce)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        /* Storing option bytes in device context, will be used and cleared in setup phase */
        device->options = options;
        /* Clear any existing session state information */
        device->session_state = 0;

        /* Determine the auth session options */
        if (options & TA_AUTH_GENERATE_OPT_DIR_MASK)
        {
            /* Target Device is the Responder */
            if (options & TA_AUTH_GENERATE_OPT_NONCE_SRC_MASK)
            {
                device->session_state |= TA_AUTH_STATE_RESPONDER_RAND;
            }
            if (options & TA_AUTH_GENERATE_OPT_RANDOM_MASK)
            {
                device->session_state |= TA_AUTH_STATE_INITIATOR_RAND;
            }
        }
        else
        {
            /* Target is the initiator */
            if (options & TA_AUTH_GENERATE_OPT_NONCE_SRC_MASK)
            {
                device->session_state |= TA_AUTH_STATE_INITIATOR_RAND;
            }
            if (options & TA_AUTH_GENERATE_OPT_RANDOM_MASK)
            {
                device->session_state |= TA_AUTH_STATE_RESPONDER_RAND;
            }
        }

        packet->opcode = TA_OPCODE_AUTHORIZE;
        packet->param1 = TA_AUTH_MODE_GENERATE_NONCE;

        /* See section 12.2.1 Options section */
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_LE(options);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(auth_handle);

        device->session_key_id = auth_handle;

        length = ATCA_CMD_BUILD_MIN_LENGTH;

        if (!(options & TA_AUTH_GENERATE_OPT_NONCE_SRC_MASK))
        {
            memcpy(packet->data, i_nonce, 16);
            length += 16;
        }

        /* Update length including length, opcode, param1, param2 and CRC */
        packet->length = ATCA_UINT16_HOST_TO_BE(length);

        status = talib_execute_command_raw(packet, device);

        if (ATCA_SUCCESS == status && (options & TA_AUTH_GENERATE_OPT_NONCE_SRC_MASK))
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t rx_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (rx_length == 16)
            {
                memcpy(i_nonce, resp_packet->data, 16);
            }
            else
            {
                status = ATCA_GEN_FAIL;
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Initiate an authorization session
 *  \note This step accepts a nonce that is identified as "r_nonce"
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_startup(
    ATCADevice device,                     /**< [in] Device context pointer */
    uint16_t   key_handle,                 /**< [in] Handle of symmetric key */
    uint8_t    alg_id,                     /**< [in] Alg_ID - only HMAC, CMAC or GCM supported */
    uint16_t   max_cmd,                    /**< [in] Maximum number of commands that can be executed */
    uint8_t    key_len,                    /**< [in] Session Key length */
    uint8_t    key[32],                    /**< [in] Session Key */
    uint8_t    i_nonce[16],                /**< [in] Initiator nonce value */
    uint8_t    r_nonce[16]                 /**< [in] Responder nonce value */
    )
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint16_t length = ATCA_CMD_BUILD_MIN_LENGTH;
    uint16_t auth_opt_flags = 0;

    if (!device || !r_nonce || !key || key_len < 16)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid key length received");
    }
    else
    {
        auth_opt_flags = (device->session_state & 0xF0) >> 4;
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_AUTHORIZE;
        packet->param1 = TA_AUTH_MODE_SETUP_SESSION;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(key_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(device->session_key_id);

        packet->data[0] = alg_id;
        packet->data[1] = (max_cmd >> 8) & 0xFF;
        packet->data[2] = (max_cmd & 0xFF);

        length += 3;

        /* Determine the auth session options */
        if (device->options & TA_AUTH_GENERATE_OPT_DIR_MASK)
        {
            /* Target Device is the Responder */
            memcpy(&packet->data[3], i_nonce, 16);
        }
        else
        {
            /* Target Device is the initiator */
            memcpy(&packet->data[3], r_nonce, 16);
        }
        /* Clearing options bytes */
        device->options = 0;

        length += 16;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(length);

        status = ATCA_TRACE(talib_execute_command_raw(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            device->session_key = key;
            device->session_key_len = key_len;

            if (TA_AUTH_ALG_ID_HMAC == alg_id)
            {
                device->session_state = TA_AUTH_STATE_HMAC;
            }
#ifdef ATCA_TA100_AES_AUTH_SUPPORT
            else if (TA_AUTH_ALG_ID_CMAC == alg_id)
            {
                device->session_state = TA_AUTH_STATE_CMAC;
            }
            else if (TA_AUTH_ALG_ID_GCM == alg_id)
            {
                device->session_state = TA_AUTH_STATE_GCM;
            }
#endif
            else
            {
                status = ATCA_BAD_PARAM;
            }
        }
        talib_packet_free(packet);
    }

    if (ATCA_SUCCESS == status)
    {
        status = ATCA_TRACE(talib_auth_hmac_kdf(device, max_cmd, auth_opt_flags, i_nonce, r_nonce), "");
    }

    return status;
}

/** \brief TA API - Executes a nested command
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_execute_nested(
    ATCADevice         device,          /**< [in] Device context pointer */
    ATCA_TA_CmdPacket* packet_in,       /**< [in] Packet to send wrapped in an auth session */
    uint16_t           options          /**< [in] Sequence support flags */
    )
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket * packet = NULL;
    uint16_t length;
    size_t mac_len = 0;

    ATCA_TA_RspPacket* resp_packet = NULL;
    ATCA_TA_RspPacket* resp_packet_in = (ATCA_TA_RspPacket*)packet_in;

    if (!device || !packet_in)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        int didx = 0;

        packet->opcode = TA_OPCODE_AUTHORIZE;
        packet->param1 = TA_AUTH_MODE_EXECUTE_NESTED;
        if (options)
        {
            packet->param1 |= TA_AUTH_MODE_WITHTIN_SEQ;
        }
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(options);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(device->session_key_id);

        /* Copy opcode, param1 & param 2 into the data section as this is always in the clear */
        memcpy(&packet->data[didx], (uint8_t*)&packet_in->opcode, 6);
        didx += 6;

        /* Get packet data length */
        length = ATCA_UINT16_BE_TO_HOST(packet_in->length);
        length -= ATCA_CMD_BUILD_MIN_LENGTH;

        /* HMAC & CMAC are not encrypted so copy the data directly to the output */
        if (TA_AUTH_STATE_GCM != device->session_state)
        {
            memcpy(&packet->data[didx], packet_in->data, length);
            didx += length;
        }

        /* Calculate the MAC (and ciphertext for GCM) */
        if (TA_AUTH_STATE_HMAC == device->session_state)
        {
            mac_len = 32;
            status = talib_auth_create_hmac(device, packet->data, (size_t)didx, &packet->data[didx], &mac_len);

        }
#ifdef ATCA_TA100_AES_AUTH_SUPPORT
        else if (TA_AUTH_STATE_CMAC == device->session_state)
        {
            mac_len = 16;
            status = talib_auth_create_cmac(device, packet->data, didx, &packet->data[didx], &mac_len);
        }
        else if (TA_AUTH_STATE_GCM == device->session_state)
        {
            mac_len = 16;
            status = talib_auth_encrypt_gcm(device, packet_in->data, length, packet->data, 6, &packet->data[didx], mac_len);
            didx += length;
        }
#endif
        else
        {
            status = ATCA_FUNC_FAIL;
        }

        length = (uint16_t)didx + (uint16_t)mac_len + ATCA_CMD_BUILD_MIN_LENGTH;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(length);

        /* Send the resulting packet */
        if (ATCA_SUCCESS == status)
        {
            status = talib_execute_command_raw(packet, device);
        }

        /* Process the response */
        if (ATCA_SUCCESS == status)
        {
            resp_packet = (ATCA_TA_RspPacket*)packet;

            /* Ge the interior message length */
            length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            /* Propagate the response code to the packet returned to the upper API*/
            resp_packet_in->resp_code = resp_packet->resp_code;

            /* Update the message counter (responses are +1 from the command) */
            device->session_counter++;

            if (TA_AUTH_STATE_HMAC == device->session_state)
            {
                mac_len = 32;

                length -= (uint16_t)mac_len;
                memcpy(resp_packet_in->data, resp_packet->data, length);

                status = talib_auth_create_hmac(device, (uint8_t*)&resp_packet_in->resp_code, (size_t)length + 1, &resp_packet_in->data[length], &mac_len);
            }
#ifdef ATCA_TA100_AES_AUTH_SUPPORT
            else if (TA_AUTH_STATE_CMAC == device->session_state)
            {
                mac_len = 16;

                length -= (uint16_t)mac_len;
                memcpy(resp_packet_in->data, resp_packet->data, length);

                status = talib_auth_create_cmac(device, (uint8_t*)&resp_packet_in->resp_code, (size_t)length + 1, &resp_packet_in->data[length], &mac_len);
            }
            else if (TA_AUTH_STATE_GCM == device->session_state)
            {
                mac_len = 16;
                length -= (uint16_t)mac_len;

                status = talib_auth_decrypt_gcm(device, resp_packet->data, length, (uint8_t*)&resp_packet->resp_code, 1, resp_packet_in->data, mac_len);
            }
#endif
            else
            {
                status = ATCA_FUNC_FAIL;
            }
        }

        /* Verify the resulting packet integritity */
        if (ATCA_SUCCESS == status)
        {
            if (TA_AUTH_STATE_GCM != device->session_state &&
                memcmp(&resp_packet->data[length], &resp_packet_in->data[length], mac_len))
            {
                status = ATCA_PARSE_ERROR;
            }
            else
            {
                resp_packet_in->length = ATCA_UINT16_HOST_TO_BE(length + ATCA_CMD_PARSE_MIN_LENGTH);
            }
        }

        /* Update the message counter for the next outgoing message */
        if (ATCA_SUCCESS == status)
        {
            device->session_counter++;
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Terminate an authorization session
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_auth_terminate(ATCADevice device)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket * packet = NULL;

    if (!device)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        device->session_state = TA_AUTH_STATE_IDLE;
        device->session_counter = 0;

        packet->opcode = TA_OPCODE_AUTHORIZE;
        packet->param1 = TA_AUTH_MODE_CLOSE_SESSION;
        packet->param2.val16[0] = 0;
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(device->session_key_id);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = talib_execute_command(packet, device);

        talib_packet_free(packet);
    }

    return status;
}
