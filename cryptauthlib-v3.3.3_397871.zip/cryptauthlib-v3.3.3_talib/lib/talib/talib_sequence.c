/**
 * \file
 * \brief CryptoAuthLib Basic API methods. These methods provide a simpler way
 *        to access the core crypto methods.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - To pass data from host to TA100 or TA100 to host for sequence calculation.
 *
 * \param[in]   device          Device object that holds the device related informations
 * \param[in]   mode            Mode value for sequence operation
 * \param[in]   param           TA100 parameter for sequence command
 * \param[in]   data_in         Input data for the sequence command
 * \param[in]   data_in_length  Input data length
 * \param[out]  data_out        Output data buffer where sequence command output is copied
 * \param[in, out]  data_out_length     As input, the size of the data_out buffer and as output
 *                                       the size of the data.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_base(ATCADevice device, const uint8_t mode, const uint32_t param,
                                const uint8_t* data_in, const uint16_t data_in_length,
                                uint8_t* const data_out, uint16_t* const data_out_length)
{
    ATCA_TA_CmdPacket* packet = NULL;
    ATCA_TA_RspPacket* resp_packet;
    ATCA_STATUS status = ATCA_SUCCESS;
    uint16_t rsp_length;

    if (device == NULL)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_SEQUENCE;
        packet->param1 = mode;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(param);

        if (data_in && data_in_length)
        {
            memcpy(packet->data, data_in, data_in_length);
        }

        packet->length = ATCA_UINT16_HOST_TO_BE(TA_CMD_SIZE_MIN + data_in_length);

        status = talib_execute_command(packet, device);
        if (ATCA_SUCCESS == status)
        {
            if (data_out)
            {
                resp_packet = (ATCA_TA_RspPacket*)packet;
                rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

                if (data_out_length)
                {
                    *data_out_length = *data_out_length < rsp_length ? *data_out_length : rsp_length;
                    memcpy(data_out, resp_packet->data, *data_out_length);
                }
            }
        }
        talib_packet_free(packet);
    }
    return status;
}

/** \brief TA API - To initialize share key sequence context with given input parameters.
 *
 * \param[in]  ctx                       Share key sequence object that holds the share key related informations
 * \param[in]  target_handle             Handle where shared secret to be created
 * \param[in]  ephe_handle               Handle where local ephemeral to be created
 * \param[in]  sign_handle               Signing handle to create singature to be send to remote
 * \param[in]  cert_handle               Handle where remote certificate is extracted
 * \param[in]  symm_key_size             Share key size to be created
 * \param[in]  is_local_first            It is Set, if local nonce and public key to be used in first for TBS message
 * \param[in]  sharekey_cb               Call back function used to share IO buffers between application and CAL
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sharekey_sequence_init(ATCADevice device, sharekey_ctx_t* ctx, const uint16_t target_handle,
                                         const uint16_t ephe_handle, const uint16_t sign_handle,
                                         const uint16_t cert_handle, const uint16_t symm_key_size,
                                         const bool is_local_first, sharekey_cb_t sharekey_cb)
{
    ATCA_STATUS status;

    if ((ctx == NULL) || (sharekey_cb == NULL))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        /* Clearing context */
        memset(ctx, 0, sizeof(sharekey_ctx_t));
        ctx->device = device;
        ctx->target_handle = target_handle;
        ctx->ephemeral_handle = ephe_handle;
        ctx->sign_handle = sign_handle;
        ctx->cert_handle = cert_handle;
        ctx->is_local_first = is_local_first;
        ctx->sharekey_cb = sharekey_cb;
        ctx->symm_key_size = symm_key_size;

        /* Must always init the context - otherwise one has to track the context
           init status for a clean de-init */
        status = (ATCA_STATUS)atcac_sw_sha2_256_init(&ctx->sha_ctx);

        if (ATCA_SUCCESS == (status = ctx->sharekey_cb(ctx, SHARE_KEY_STEP_INIT, NULL, 0, NULL, NULL)))
        {
            ctx->step = SHARE_KEY_STEP_RANDOM;
        }
    }
    return status;
}

/** \brief Share Key - Step 1: Random
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step1(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        ctx->device->options = TA_SHARE_KEY_START_SEQ;
        memset(ctx->scratchpad + TA_RANDOM_MIN_RESP_LENGTH, 0, TA_RANDOM_STIR_DATA_LENGTH);
        /* Stir data for nonce generation */
        /* scratchpad - 32 bytes (nonce) + 16 bytes Stir data */
        status = talib_random(ctx->device, ctx->scratchpad + TA_RANDOM_MIN_RESP_LENGTH, ctx->scratchpad, TA_RANDOM_MIN_RESP_LENGTH);
        if (status == ATCA_SUCCESS)
        {
            size_t length = TA_SHARE_SEQ_NONCE_LEN;
            status = ctx->sharekey_cb(ctx, ctx->step, NULL, 0, ctx->scratchpad, &length);
        }
        ctx->device->options = 0;
    }
    return status;
}

/** \brief Share Key - Step 2: Remote Nonce
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step2(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        size_t length = TA_SHARE_SEQ_NONCE_LEN;
        status = ctx->sharekey_cb(ctx, ctx->step, NULL, 0, ctx->scratchpad + TA_SHARE_SEQ_NONCE_LEN, &length);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
            /* FIXME */
            //if (ctx->is_local_first) {
            if (!ctx->is_local_first)
            {
                ctx->device->options |= TA_SHARE_KEY_LOCAL_FIRST_MASK;
            }
            status = talib_sequence_base(ctx->device, 0, 0, ctx->scratchpad + TA_SHARE_SEQ_NONCE_LEN,
                                         length, NULL, NULL);
            if (status == ATCA_SUCCESS)
            {
                if (ctx->is_local_first == true)
                {
                    status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, ctx->scratchpad, (2 * TA_SHARE_SEQ_NONCE_LEN));
                }
                else
                {
                    status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, ctx->scratchpad + TA_SHARE_SEQ_NONCE_LEN, TA_SHARE_SEQ_NONCE_LEN);
                    if (status == ATCA_SUCCESS)
                    {
                        status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, ctx->scratchpad, TA_SHARE_SEQ_NONCE_LEN);
                    }
                }
            }
            ctx->device->options = 0;
        }
    }
    return status;
}

/** \brief Share Key - Step 3: Create Target Handle
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step3(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        size_t length = sizeof(ta_element_attributes_t);

        status = ctx->sharekey_cb(ctx, ctx->step, NULL, 0, (uint8_t*)&ctx->target_attr, &length);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
            status = talib_create_element_with_handle(ctx->device, ctx->target_handle, &ctx->target_attr);
            ctx->device->options = 0;
        }
    }
    return status;
}

/** \brief Share Key - Step 4: Create Ephemeral Key Handle
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step4(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    ta_element_attributes_t ephemeral_attr;

    if (ctx)
    {
        size_t length = sizeof(ta_element_attributes_t);
        status = ctx->sharekey_cb(ctx, ctx->step, NULL, 0, (uint8_t*)&ephemeral_attr, &length);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
            status = talib_create_ephemeral_element_with_handle(ctx->device, TA_CREATE_DETAILS_EPHEMERAL_PRIV_AND_KDF_REQ,
                                                                ctx->ephemeral_handle, &ephemeral_attr);
            ctx->device->options = 0;
        }
    }
    return status;
}

/** \brief Share Key - Step 5: Key Gen Ephemeral Private Key
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step5(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        size_t length = TA_ECC256_PUB_KEY_SIZE;
        ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
        status = talib_genkey(ctx->device, ctx->ephemeral_handle, ctx->scratchpad, &length);
        ctx->device->options = 0;
        if (status == ATCA_SUCCESS)
        {
            status = ctx->sharekey_cb(ctx, ctx->step, ctx->scratchpad, length, NULL, NULL);
        }
    }
    return status;
}

/** \brief Share Key - Step 6: Receive Remote Ephemeral Public Key
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step6(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        size_t length = TA_ECC256_PUB_KEY_SIZE;
        status = ctx->sharekey_cb(ctx, ctx->step, NULL, 0, ctx->r_ephe_pubkey, &length);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
            memcpy(ctx->scratchpad + TA_ECC256_PUB_KEY_SIZE, ctx->r_ephe_pubkey, length);
            status = talib_sequence_base(ctx->device, 0, 0, ctx->scratchpad + TA_ECC256_PUB_KEY_SIZE,
                                         length, NULL, NULL);
            if (status == ATCA_SUCCESS)
            {
                if (ctx->is_local_first == true)
                {
                    status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, ctx->scratchpad, (2 * TA_ECC256_PUB_KEY_SIZE));
                }
                else
                {
                    status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, ctx->scratchpad + TA_ECC256_PUB_KEY_SIZE,
                                                                   TA_ECC256_PUB_KEY_SIZE);
                    if (status == ATCA_SUCCESS)
                    {
                        status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, ctx->scratchpad, TA_ECC256_PUB_KEY_SIZE);
                    }
                }
                status = (ATCA_STATUS)atcac_sw_sha2_256_update(&ctx->sha_ctx, (uint8_t*)&ctx->target_attr,
                                                               sizeof(ta_element_attributes_t));
                if (status == ATCA_SUCCESS)
                {
                    status = (ATCA_STATUS)atcac_sw_sha2_256_finish(&ctx->sha_ctx, ctx->scratchpad);
                }
            }
            ctx->device->options = 0;
        }
    }
    return status;
}

/** \brief Share Key - Step 7: Sign
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step7(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        size_t length = TA_SIGN_P256_SIG_SIZE;
        ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
        status = talib_sign_external(ctx->device, TA_SIGN_MODE_EXTERNAL_MSG | TA_KEY_TYPE_ECCP256,
                                     ctx->sign_handle, TA_HANDLE_INPUT_BUFFER, ctx->scratchpad, TA_SIGN_P256_MSG_SIZE,
                                     ctx->scratchpad + TA_SIGN_P256_MSG_SIZE, (uint16_t*)&length);
        ctx->device->options = 0;
        if (status == ATCA_SUCCESS)
        {
            status = ctx->sharekey_cb(ctx, ctx->step, ctx->scratchpad + TA_SIGN_P256_MSG_SIZE, length, NULL, NULL);
        }
    }
    return status;
}

/** \brief Share Key - Step 8: Verify Remote Signature
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step8(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    bool is_verified = false;

    if (ctx)
    {
        size_t length = TA_SIGN_P256_SIG_SIZE;
        status = ctx->sharekey_cb(ctx, ctx->step, ctx->scratchpad, TA_SIGN_P256_MSG_SIZE, &ctx->scratchpad[TA_SIGN_P256_MSG_SIZE], &length);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
            status = talib_verify(ctx->device, TA_KEY_TYPE_ECCP256, TA_HANDLE_INPUT_BUFFER, ctx->cert_handle, ctx->scratchpad + TA_SIGN_P256_MSG_SIZE, TA_SIGN_P256_SIG_SIZE, ctx->scratchpad,
                                  TA_VERIFY_P256_MSG_SIZE, NULL, 0, &is_verified);
            ctx->device->options = 0;
            if (status == ATCA_SUCCESS)
            {
                status = (is_verified == true) ? ATCA_SUCCESS : ATCA_CHECKMAC_VERIFY_FAILED;
            }
        }
    }
    return status;
}

/** \brief Share Key - Step 9: Ephemeral ECDH
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step9(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        status = ctx->sharekey_cb(ctx, ctx->step, NULL, 0, NULL, NULL);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_CONTINUE_SEQ;
            status = talib_ecdh_to_handle(ctx->device, ctx->ephemeral_handle,
                                          ctx->ephemeral_handle, ctx->r_ephe_pubkey, TA_ECC256_PUB_KEY_SIZE);
            ctx->device->options = 0;
        }
    }
    return status;
}

/** \brief Share Key - Step 10: KDF (HMAC-counter)
 *
 * \param[in]  ctx   Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sequence_sharekey_step10(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        memmove(&ctx->scratchpad[6], ctx->scratchpad, 26);
        status = ctx->sharekey_cb(ctx, ctx->step, ctx->scratchpad, TA_SIGN_P256_MSG_SIZE, NULL, NULL);
        if (status == ATCA_SUCCESS)
        {
            ctx->device->options = TA_SHARE_KEY_TERMINATE_SEQ;
            status = talib_kdf_hmac_counter_stored(ctx->device, ctx->ephemeral_handle, (uint8_t*)TA_SHARE_KEY_SEQ_LABEL,
                                                   (uint16_t)strlen(TA_SHARE_KEY_SEQ_LABEL), ctx->scratchpad, TA_SIGN_P256_MSG_SIZE,
                                                   ctx->target_handle, &ctx->symm_key_size);
        }
        // Resetting options bytes to default
        ctx->device->options = 0;
    }
    return status;
}

/** \brief TA API - To execute share key sequence steps.
 *
 * \param[in]   ctx          Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sharekey_sequence_execute(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status;

    if (ctx == NULL)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        switch (ctx->step)
        {
        case SHARE_KEY_STEP_RANDOM:
            status = talib_sequence_sharekey_step1(ctx);
            break;

        case SHARE_KEY_STEP_SEQ_REMOTE_NONCE:
            status = talib_sequence_sharekey_step2(ctx);
            break;

        case SHARE_KEY_STEP_CREATE_TARGET:
            status = talib_sequence_sharekey_step3(ctx);
            break;

        case SHARE_KEY_STEP_CREATE_EPHEMERAL:
            status = talib_sequence_sharekey_step4(ctx);
            break;

        case SHARE_KEY_STEP_KEY_GEN:
            status = talib_sequence_sharekey_step5(ctx);
            break;

        case SHARE_KEY_STEP_SEQ_REMOTE_PUBKEY:
            status = talib_sequence_sharekey_step6(ctx);
            break;

        case SHARE_KEY_STEP_SIGN:
            status = talib_sequence_sharekey_step7(ctx);
            break;

        case SHARE_KEY_STEP_VERIFY:
            status = talib_sequence_sharekey_step8(ctx);
            break;

        case SHARE_KEY_STEP_ECDH:
            status = talib_sequence_sharekey_step9(ctx);
            break;

        case SHARE_KEY_STEP_KDF:
            status = talib_sequence_sharekey_step10(ctx);
            break;

        default:
            status = ATCA_FUNC_FAIL;
            break;
        }

        ctx->step = (ATCA_SUCCESS == status) ? (share_key_step_number_t)(ctx->step + 1) : SHARE_KEY_STEP_TERMINATE;
    }
    return status;
}

/** \brief TA API - To terminate the share key sequence steps.
 *
 * \param[in]   ctx          Share key sequence object that holds the share key related informations
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sharekey_sequence_terminate(sharekey_ctx_t* ctx)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (ctx)
    {
        /* Resetting options bytes to default */
        if (ctx->device)
        {
            ctx->device->options = 0;
        }

        /* Terminating auth session */
        status = ctx->sharekey_cb(ctx, SHARE_KEY_STEP_TERMINATE, NULL, 0, NULL, NULL);

        /* Clean up the sha context if it hasn't been already */
        (void)atcac_sw_sha2_256_finish(&ctx->sha_ctx, NULL);

        /* Clearing the context */
        atcab_memset_s(ctx, sizeof(sharekey_ctx_t), 0, sizeof(sharekey_ctx_t));
    }
    return status;
}
