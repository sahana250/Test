/**
 * \file
 * \brief TA100 Packet Definitions and Utilities
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "cryptoauthlib.h"
#include "talib_packet.h"
#include "atca_bool.h"

#ifdef ATCA_NO_HEAP

#ifndef TA_MAX_PACKET_CACHE
#define TA_MAX_PACKET_CACHE     (3)
#elif TA_MAX_PACKET_CACHE < 2
#error TA_MAX_PACKET_CACHE must be greater than or equal to 2 if ATCA_NO_HEAP is set
#endif

typedef struct talib_packet_cache_s
{
    ATCA_TA_CmdPacket packet;
    bool              used;
} talib_packet_cache_t;

static talib_packet_cache_t talib_packet_cache[TA_MAX_PACKET_CACHE];

ATCA_TA_CmdPacket* talib_packet_alloc(void)
{
    ATCA_TA_CmdPacket* ptr = NULL;
    int i;

    for (i = 0; i < TA_MAX_PACKET_CACHE; i++)
    {
        if (!talib_packet_cache[i].used)
        {
            ptr = &talib_packet_cache[i].packet;
            talib_packet_cache[i].used = true;
            break;
        }
    }

    return ptr;
}

void talib_packet_free(ATCA_TA_CmdPacket* packet)
{
    int i;

    for (i = 0; i < TA_MAX_PACKET_CACHE; i++)
    {
        if (&talib_packet_cache[i].packet == packet)
        {
            talib_packet_cache[i].used = false;
        }
    }
}

#else

ATCA_TA_CmdPacket* talib_packet_alloc(void)
{
    return hal_malloc(sizeof(ATCA_TA_CmdPacket));
}

void talib_packet_free(ATCA_TA_CmdPacket* packet)
{
    /* Make sure we clear any sensitive data from the packet before we give it back*/
    hal_memset_s(packet, sizeof(ATCA_TA_CmdPacket), 0, sizeof(ATCA_TA_CmdPacket));
    hal_free(packet);
}

#endif
