/**
 * \file
 * \brief Basic ECDH and ECBD command for Trust Anchor Devices.
 *
 * The ECDH command implements the Elliptic Curve Diffie-Hellman algorithm to
 * combine an internal private key with an external public key to calculate a
 * shared secret.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in  the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Base function for generating premaster secret key using ECDH.
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  mode                Mode to be used for ECDH computation
 *  \param[in]  priv_handle         Private key handle for ECDH computation, can be Volatile or
 *                                  Shared memory
 *  \param[in]  target_handle       Handle for ECDH computation result, can be IO, Volatile or
 *                                  Shared memory
 *  \param[in]  public_key          Public key input to ECDH calculation. X and Y
 *                                  integers in big-endian format. 64 bytes for P256
 *                                  key , 56 bytes for P224 key and 96 bytes for P384
 *  \param[in]  public_key_size     Length of the Public key parameter
 *  \param[out] pms                 Computed ECDH pre-master secret is returned here (28 or 32
 *                                  or 48 bytes) if returned directly. Otherwise NULL.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_ecdh_base(ATCADevice device, const uint8_t mode, const uint16_t priv_handle,
                            const uint16_t target_handle, const uint8_t* public_key, const size_t
                            public_key_size, uint8_t* const pms)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket * packet = NULL;

    if ((NULL == device) || (NULL == public_key))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_ECDH;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(target_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(priv_handle);

        //Copy public key into input stream
        memcpy(packet->data, public_key, public_key_size);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)public_key_size +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            size_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (pms && (rsp_length >= (public_key_size / 2)))
            {
                memcpy(pms, resp_packet->data, rsp_length);
            }

        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Generate pre master secret using ECDH and secret key copied into output buffer
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  priv_handle         Private key handle for ECDH computation, can be Volatile or
 *                                  Shared memory
 *  \param[in]  public_key          Public key input to ECDH calculation. X and Y
 *                                  integers in big-endian format. 64 bytes for P256
 *                                  key and 56 bytes for P224 key
 *  \param[out] pms                 Computed ECDH pre-master secret is returned here (28 or 32
 *                                  bytes) if returned directly. Otherwise NULL.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_ecdh_compat(ATCADevice device, const uint16_t priv_handle,
                              const uint8_t public_key[TA_ECC256_PUB_KEY_SIZE],
                              uint8_t* const pms)
{
    ATCA_STATUS status;

    do
    {
        if (NULL == pms)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        status = talib_ecdh_base(device, TA_ECDH_X_MODE, priv_handle,
                                 TA_HANDLE_OUTPUT_BUFFER, public_key, TA_ECC256_PUB_KEY_SIZE, pms);
    }
    while (0);

    return status;
}

/** \brief TA API - Generate pre master secret using ECDH and secret key copied into output buffer
 *                  (premaster secret key size is same as the public key size)
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  priv_handle         Private key handle for ECDH computation, can be Volatile or
 *                                  Shared memory
 *  \param[in]  public_key          Public key input to ECDH calculation.
 *  \param[in]  pubkey_len          Length of the Public key parameter
 *  \param[out] pms                 Computed ECDH pre-master secret is returned here (public key size)
 *                                  if returned directly. Otherwise NULL.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_ecdh_xy_in_io_buffer(ATCADevice device, const uint16_t priv_handle, const uint8_t* public_key,
                                       const size_t pubkey_len, uint8_t* const pms)
{
    ATCA_STATUS status;

    do
    {
        if (NULL == pms)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        status = talib_ecdh_base(device, TA_ECDH_X_AND_Y_MODE, priv_handle,
                                 TA_HANDLE_OUTPUT_BUFFER, public_key, pubkey_len, pms);
    }
    while (0);

    return status;
}

/** \brief TA API - Generate pre master secret using ECDH and secret key copied into output buffer
 *                  (premaster secret key size is equal to the public key size divide by 2)
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  priv_handle         Private key handle for ECDH computation, can be Volatile or
 *                                  Shared memory
 *  \param[in]  public_key          Public key input to ECDH calculation.
 *  \param[in]  pubkey_len          Length of the Public key parameter
 *  \param[out] pms                 Computed ECDH pre-master secret is returned here (public key size/2)
 *                                  if returned directly. Otherwise NULL.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_ecdh_io_buffer(ATCADevice device, const uint16_t priv_handle, const uint8_t* public_key,
                                 const size_t pubkey_len, uint8_t* const pms)
{
    ATCA_STATUS status;

    do
    {
        if (NULL == pms)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        status = talib_ecdh_base(device, TA_ECDH_X_MODE, priv_handle,
                                 TA_HANDLE_OUTPUT_BUFFER, public_key, pubkey_len, pms);
    }
    while (0);

    return status;
}

/** \brief TA API - Generating premaster secret key using ECDH and stores in shared data or
 *                  volatile register.(premaster secret key size is same as the public key size)
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  priv_handle         Private key handle for ECDH computation, can be Volatile or
 *                                  Shared memory
 *  \param[in]  target_handle       Handle for ECDH computation result can go to Volatile or
 *                                  Shared memory
 *  \param[in]  public_key          Public key input to ECDH calculation. X and Y
 *                                  integers in big-endian format. 64 bytes for P256
 *                                  key and 56 bytes for P224 key
 *  \param[in]  pubkey_len          Length of the Public key parameter
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_ecdh_xy_to_handle(ATCADevice device, const uint16_t priv_handle, const uint16_t
                                    target_handle, const uint8_t* public_key, const size_t pubkey_len)
{
    return talib_ecdh_base(device, TA_ECDH_X_AND_Y_MODE, priv_handle, target_handle,
                           public_key, pubkey_len, NULL);
}

/** \brief TA API - Generating premaster secret key using ECDH and stores in shared data or
 *                  volatile register (premaster secret key size is equal to the public key size divided by 2)
 *
 *  \param[in]  device              Device context pointer
 *  \param[in]  priv_handle         Private key handle for ECDH computation, can be Volatile or
 *                                  Shared memory
 *  \param[in]  target_handle       Handle for ECDH computation result can go to Volatile or
 *                                  Shared memory
 *  \param[in]  public_key          Public key input to ECDH calculation. X and Y
 *                                  integers in big-endian format. 64 bytes for P256
 *                                  key and 56 bytes for P224 key
 *  \param[in]  pubkey_len          Length of the Public key parameter
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_ecdh_to_handle(ATCADevice device, const uint16_t priv_handle, const uint16_t
                                 target_handle, const uint8_t* public_key, const size_t pubkey_len)
{
    return talib_ecdh_base(device, TA_ECDH_X_MODE, priv_handle, target_handle,
                           public_key, pubkey_len, NULL);
}
