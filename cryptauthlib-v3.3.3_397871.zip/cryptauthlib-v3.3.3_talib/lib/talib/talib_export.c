/**
 * \file
 * \brief Basic Export commands for Trust Anchor Devices.
 *
 * Exports the contents of a key/data element in the shared data memory.
 * The resulting blob can only be loaded back into the same device from which it was exported.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheet for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes the Export command, which exports the contents of a key/data element
 *                  in the shared data memory.
 *
 *  \param[in]      device                Device context pointer
 *  \param[in]      key_handle            The key_handle that contains key/data to be exported.
 *  \param[out]     export_data           The buffer to the store the exported data.
 *  \param[in,out]  export_data_length    As input, the size of the export_data buffer and as output
 *                                       the size of the exported data.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_export(ATCADevice device, const uint16_t key_handle, uint8_t* const export_data,
                         uint16_t* const export_data_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    if ((NULL == device) || (NULL == export_data) || (NULL == export_data_length))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_EXPORT;
        packet->param1 = 0;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE((uint32_t)key_handle);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (*export_data_length >= length)
            {
                memcpy(export_data, resp_packet->data, length);
                *export_data_length = length;
            }
            else
            {
                status = ATCA_TRACE(ATCA_SMALL_BUFFER, "Small buffer received");
            }
        }
        talib_packet_free(packet);
    }

    return status;
}
