/**
 * \file
 * \brief Basic MAC commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - ATTA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes MAC command for CMAC and HMAC calculations.
 *
 *  \param[in]  device        Device context pointer
 *	\param[in]  key_handle    Handle of the Symmetric key to be used either present in
 *                            Shared data or Volatile register
 *	\param[in]  key_index     Key index in the Key grup if handle points to a group
 *	\param[in]  message       Challenge message of max size 1022 bytes
 *  \param[in] msg_length     Carries the message length
 *	\param[out] digest        CMAC or HMAC response is returned here (16 or 32 bytes)
 *  \param[in,out] mac_length  As input, digest buffer size
 *                            As output, mac size in digest buffer

 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_mac_base(ATCADevice device, const uint16_t key_handle, const uint16_t key_index, const
                           uint8_t* message, const uint16_t msg_length, uint8_t* const digest, const
                           uint16_t* mac_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if ((NULL == device) || (NULL == message) || (NULL == mac_length) || (msg_length <= 0) || (msg_length > TA_MAC_MAX_MSG_LENGTH))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or Invalid length received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_MAC;
        packet->param1 = TA_MAC_MODE;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(key_index);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(key_handle);

        data = packet->data;
        // copy message length into input stream buffer
        tmp16 = ATCA_UINT16_HOST_TO_BE(msg_length);
        memcpy(data, &tmp16, sizeof(msg_length));
        data += sizeof(msg_length);
        //copy message into input stream buffer
        memcpy(data, message, msg_length);
        data += msg_length;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t mac_rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (digest && mac_rsp_length)
            {
                if (*mac_length < mac_rsp_length)
                {
                    status = ATCA_TRACE(ATCA_SMALL_BUFFER, "Small buffer received");
                }
                else
                {
                    memcpy(digest, resp_packet->data, *mac_length);
                }
            }

        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief Executes MAC command for CMAC calculations.
 *
 *  \param[in]  device      Device context pointer
 *	\param[in]  key_handle  Handle of the Symmetric key to be used either present in
 *                          Shared data or Volatile register
 *	\param[in]  key_index   Key index in the Key grup if handle points to a group
 *	\param[in]  message     Challenge message of max size 1022 bytes
 *  \param[in]  length      carries the message length
 *	\param[out] cmac        CMAC response is returned here (16 bytes)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_cmac(ATCADevice device, const uint16_t key_handle, const uint16_t key_index,
                       const uint8_t* message, const uint16_t length, uint8_t* const cmac)
{
    ATCA_STATUS status;
    uint8_t digest[TA_MAC_COMMAND_CMAC_SIZE];
    const uint16_t mac_resp_length = sizeof(digest);

    do
    {
        if (NULL == message)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        if (ATCA_SUCCESS != (status = talib_mac_base(device, key_handle, key_index, message, length,
                                                     digest, &mac_resp_length)))
        {
            ATCA_TRACE(status, "talib_calc_cmac - Failed");
            break;
        }

        if (mac_resp_length != TA_MAC_COMMAND_CMAC_SIZE)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid cmac response length received");
            break;
        }

        if (cmac)
        {
            memcpy(cmac, digest, mac_resp_length);
        }

    }
    while (0);

    return status;
}

/** \brief Executes MAC command for HMAC calculations.
 *
 *  \param[in]  device      Device context pointer
 *	\param[in]  key_handle  Handle of the Symmetric key to be used either present in
 *                          Shared data or Volatile register
 *	\param[in]  key_index   Key index in the Key grup if handle points to a group
 *	\param[in]  message     Challenge message of max size 1022 bytes
 *  \param[in]  length      carries the message length
 *	\param[out] hmac        HMAC response is returned here (32 bytes)
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_hmac(ATCADevice device, const uint16_t key_handle, const uint16_t key_index,
                       const uint8_t* message, const uint16_t length, uint8_t* const hmac)
{
    ATCA_STATUS status;
    uint8_t digest[TA_MAC_COMMAND_HMAC_SIZE];
    const uint16_t mac_resp_length = sizeof(digest);

    do
    {
        if (NULL == message)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        if (ATCA_SUCCESS != (status = talib_mac_base(device, key_handle, key_index, message, length,
                                                     digest, &mac_resp_length)))
        {
            ATCA_TRACE(status, "talib_calc_hmac - Failed");
            break;
        }

        if (mac_resp_length != TA_MAC_COMMAND_HMAC_SIZE)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid hmac response length received");
            break;
        }

        if (hmac)
        {
            memcpy(hmac, digest, mac_resp_length);
        }

    }
    while (0);

    return status;
}

/** \brief Executes MAC command for HMAC calculation (compatible with sha-hmac command)
 *
 *  \param[in]  device      Device context pointer
 *	\param[in]  data        Challenge message of max size 1022 bytes
 *  \param[in]  data_size   carries the message length
 *	\param[in]  key_slot    Handle of the Symmetric key to be used either present in
 *                          Shared data or Volatile register
 *	\param[out] digest      HMAC response is returned here (32 bytes)
 *  \param[in]  target      Where to save the digest internal to the device.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_hmac_compat(ATCADevice device, const uint8_t* data, size_t data_size, uint16_t key_slot, uint8_t* digest, uint8_t target)
{
    (void)target;
    return talib_hmac(device, key_slot, 0, data, (uint16_t)data_size, digest);
}
