/**
 * \file
 * \brief Basic Lock commands for Trust Anchor Devices.
 *
 * The Lock command prevents future modifications of the Configuration handle,
 * non volatile shared data element and setup phase.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes Lock command to prevent further updates to Configuration or Setup
 *                  or shared data or one time based on the mode. Once locked, these can't be
 *                  unlocked
 *
 * \param[in]  device       Device context pointer
 * \param[in]  mode         Parameter to select the memory type and options to lock
 * \param[in]  param2       CRC if locking Config, Handle if locking a shared element
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_lock(ATCADevice device, const uint8_t mode, const uint32_t param2)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    if (NULL == device)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_LOCK;
        packet->param1 = mode;
        if (mode == TA_LOCK_CONFIG_WITH_CRC)
        {
            packet->param2.val32 = param2;
        }
        else
        {
            packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(param2);
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        talib_packet_free(packet);
    }

    return status;
}

/** \brief Lock the config zone with summary CRC.
 *
 *  The CRC is calculated over the entire config contents.
 *  Lock will fail if the provided CRC doesn't match the internally calculated one.
 *
 *  \param[in] device       Device context pointer
 *  \param[in] summary_crc  Expected CRC over the config zone.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_lock_config_with_crc(ATCADevice device, const uint16_t summary_crc)
{
    return talib_lock(device, TA_LOCK_CONFIG_WITH_CRC, (uint32_t)summary_crc);
}

/** \brief Lock the config zone without CRC.
 *
 *  \param[in]  device       Device context pointer
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_lock_config(ATCADevice device)
{
    return talib_lock(device, TA_LOCK_CONFIG_WITHOUT_CRC, 0);
}

/** \brief Lock an individual handle in the data zone on an ATECC device.
 *
 *  \param[in] device       Device context pointer
 *  \param[in] handle       handle to be locked in nv shared data zone.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_lock_handle(ATCADevice device, const uint16_t handle)
{
    return talib_lock(device, TA_LOCK_SHARED_ELEMENT, (uint32_t)handle);
}

/** \brief Locks Setup memory
 *
 *  \param[in]  device       Device context pointer
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_lock_setup(ATCADevice device)
{
    return talib_lock(device, TA_LOCK_SETUP_LOCK, 0);
}

/** \brief Locks one time latch. Applicable only when enabled in Chip Options
 *
 *  \param[in]  device       Device context pointer
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_lock_onetime_latch(ATCADevice device)
{
    return talib_lock(device, TA_LOCK_ONE_TIME_LOCK, 0);
}
