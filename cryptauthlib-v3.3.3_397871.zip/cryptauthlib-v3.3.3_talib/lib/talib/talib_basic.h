#include "cryptoauthlib.h"
#include "talib_execution.h"
#include "talib_defines.h"
#include "crypto/atca_crypto_sw.h"

#ifndef TALIB_BASIC_H_
#define TALIB_BASIC_H_


/** \defgroup TALIB_ Basic TA100 API methods (talib_)
 *
 * \brief
 * These methods provide the most convenient, simple API to TA100 chips
 *
   @{ */

#ifdef __cplusplus
extern "C" {
#endif

struct sharekey_ctx;

typedef ATCA_STATUS (*sharekey_cb_t)(struct sharekey_ctx* ctx, uint8_t step_number, uint8_t* data, size_t data_len, uint8_t *ret_buf, size_t * ret_buf_len);

typedef enum
{
    SHARE_KEY_STEP_INIT,
    SHARE_KEY_STEP_RANDOM,
    SHARE_KEY_STEP_SEQ_REMOTE_NONCE,
    SHARE_KEY_STEP_CREATE_TARGET,
    SHARE_KEY_STEP_CREATE_EPHEMERAL,
    SHARE_KEY_STEP_KEY_GEN,
    SHARE_KEY_STEP_SEQ_REMOTE_PUBKEY,
    SHARE_KEY_STEP_SIGN,
    SHARE_KEY_STEP_VERIFY,
    SHARE_KEY_STEP_ECDH,
    SHARE_KEY_STEP_KDF,
    SHARE_KEY_STEP_TERMINATE,
} share_key_step_number_t;

typedef struct sharekey_ctx
{
    ATCADevice         device; /* Device context pointer */
    atcac_sha2_256_ctx sha_ctx;
    sharekey_cb_t      sharekey_cb;

    uint16_t target_handle;
    uint16_t ephemeral_handle;
    uint16_t sign_handle;
    uint16_t cert_handle;
    uint16_t symm_key_size;

    uint8_t scratchpad[128];
    /* For storing l_nonce, r_nonce, l_pubkey,
       Dummy_Msg(Digest), Signature */
    uint8_t r_ephe_pubkey[64];

    ta_element_attributes_t target_attr;
    share_key_step_number_t step;
    bool                    is_local_first;
} sharekey_ctx_t;

ATCA_STATUS talib_wakeup(ATCADevice device);
ATCA_STATUS talib_idle(ATCADevice device);
ATCA_STATUS talib_sleep(ATCADevice device);
ATCA_STATUS _talib_exit(ATCADevice device);
ATCA_STATUS talib_get_zone_size(ATCADevice device, uint8_t zone, uint16_t slot, size_t* size);
ATCA_STATUS talib_cfg_discover(ATCAIfaceCfg cfg_array[], int max);

/* AES command functions */
ATCA_STATUS talib_aes_keyload(ATCADevice device, const uint8_t mode, const uint8_t iv_index,
                              const uint8_t key_index, const uint16_t key_handle);
ATCA_STATUS talib_aes_ecb(ATCADevice device, const uint8_t mode, const uint8_t* aes_in,
                          uint8_t* aes_out);
ATCA_STATUS talib_aes_gcm(ATCADevice device, const uint8_t mode, const uint16_t aad_length,
                          const uint16_t message_length, uint8_t* iv, const uint8_t* aad,
                          const uint8_t* message, uint8_t* tag, uint8_t* data_out);
ATCA_STATUS talib_aes_encrypt(ATCADevice device, const uint16_t key_id, const uint8_t key_block,
                              const uint8_t* plaintext, uint8_t* ciphertext);
ATCA_STATUS talib_aes_decrypt(ATCADevice device, const uint16_t key_id, const uint8_t key_block,
                              const uint8_t* ciphertext, uint8_t* plaintext);

ATCA_STATUS talib_aes_gcm_keyload(ATCADevice device, const uint16_t key_id, const uint8_t key_block);
ATCA_STATUS talib_aes_gcm_keyload_with_implicit_iv(ATCADevice device, const uint16_t key_id,
                                                   const uint8_t key_block, const uint8_t iv_index);
ATCA_STATUS talib_aes_gcm_encrypt(ATCADevice device, const uint8_t* aad, const uint16_t aad_length,
                                  const uint8_t* iv, const uint8_t* plaintext, const uint16_t plaintext_length, uint8_t* ciphertext, uint8_t* tag);
ATCA_STATUS talib_aes_gcm_encrypt_with_rand_iv(ATCADevice device, const uint8_t* aad,
                                               const uint16_t aad_length, const uint8_t* plaintext, const uint16_t plaintext_length, uint8_t* ciphertext, uint8_t* tag, uint8_t* iv);
ATCA_STATUS talib_aes_gcm_decrypt(ATCADevice device, const uint8_t* aad, const uint16_t aad_length,
                                  const uint8_t* iv, const uint8_t* tag, const uint8_t* ciphertext, const uint16_t ciphertext_length, uint8_t* plaintext);


/* Authorization Command */
ATCA_STATUS talib_auth_hmac_kdf(ATCADevice device, uint16_t max_cmd, uint16_t auth_flags,
                                uint8_t i_nonce[16], uint8_t r_nonce[16]);
ATCA_STATUS talib_auth_create_hmac(ATCADevice device, uint8_t * data, size_t data_len,
                                   uint8_t * hmac_out, size_t * hmac_len);
ATCA_STATUS talib_auth_generate_nonce(ATCADevice device, uint16_t auth_handle, uint16_t options,
                                      uint8_t i_nonce[16]);
ATCA_STATUS talib_auth_startup(ATCADevice device, uint16_t key_handle, uint8_t alg_id, uint16_t max_cmd, uint8_t key_len,
                               uint8_t key[32], uint8_t i_nonce[16], uint8_t r_nonce[16]);
ATCA_STATUS talib_auth_execute_nested(ATCADevice device, ATCA_TA_CmdPacket* packet_in, uint16_t options);
ATCA_STATUS talib_auth_terminate(ATCADevice device);

/* Counter command functions */
ATCA_STATUS talib_counter(ATCADevice device, const uint8_t mode, const uint16_t counter_id,
                          uint32_t* const counter_value);
ATCA_STATUS talib_counter_read(ATCADevice device, const uint16_t counter_id, uint32_t* const
                               counter_value);
ATCA_STATUS talib_counter_increment(ATCADevice device, const uint16_t counter_id, uint32_t* const
                                    counter_value);

//Create command functions
ATCA_STATUS talib_create(ATCADevice device, const uint8_t mode, const uint16_t details, const
                         uint16_t handle_in, const ta_element_attributes_t* handle_config,
                         uint16_t* const handle_out);

ATCA_STATUS talib_create_element(ATCADevice device, const ta_element_attributes_t* handle_cfg,
                                 uint16_t* const handle_out);

ATCA_STATUS talib_create_element_with_handle(ATCADevice device, const uint16_t handle_in,
                                             const ta_element_attributes_t* handle_config);

ATCA_STATUS talib_create_ephemeral_element_with_handle(ATCADevice device, const uint16_t details,
                                                       const uint16_t handle_in, const ta_element_attributes_t* handle_config);

ATCA_STATUS talib_create_hmac_element(ATCADevice device, const size_t hmac_key_size,
                                      const ta_element_attributes_t* handle_config, uint16_t* const handle_out);

ATCA_STATUS talib_create_hmac_element_with_handle(ATCADevice device, const size_t hmac_key_size,
                                                  const uint16_t handle_in, const ta_element_attributes_t* handle_config);
ATCA_STATUS talib_create_linked_shared_data(ATCADevice device, const uint16_t details, ta_element_attributes_t*
                                            handle_config, uint16_t* const handle_out);

//Delete command functions
ATCA_STATUS talib_delete_base(ATCADevice device, const uint8_t mode, const uint32_t handle);
ATCA_STATUS talib_delete_handle(ATCADevice device, const uint32_t handle);
ATCA_STATUS talib_chip_erase(ATCADevice device);

//Dev_Update command functions
typedef struct talib_devupdate_ctx
{
    uint16_t first_block_size;                  //!< First block size of the update image
    uint16_t remaining_block_size;              //!< Remaining block size of the update image
    uint8_t  block_id;                          //!< block ID to be updated
}talib_devupdate_ctx_t;

ATCA_STATUS talib_devupdate_base(ATCADevice device, const uint8_t mode, const uint8_t* data, const uint16_t
                                 data_length);
ATCA_STATUS talib_devupdate_init_ctx(talib_devupdate_ctx_t* ctx, const uint16_t first_block_size,
                                     const int16_t remaining_block_size);
ATCA_STATUS talib_devupdate_first_block(ATCADevice device, talib_devupdate_ctx_t* ctx, const uint8_t*
                                        first_block);
ATCA_STATUS talib_devupdate_subsequent_block(ATCADevice device, talib_devupdate_ctx_t* ctx, const
                                             uint8_t* block, uint16_t* const block_len);
ATCA_STATUS talib_devupdate_image(ATCADevice device, const uint8_t* image);

//ECDH command functions
ATCA_STATUS talib_ecdh_base(ATCADevice device, const uint8_t mode, const uint16_t priv_handle,
                            const uint16_t target_handle, const uint8_t* public_key, const size_t
                            public_key_size, uint8_t* const pms);
ATCA_STATUS talib_ecdh_compat(ATCADevice device, const uint16_t priv_handle,
                              const uint8_t public_key[TA_ECC256_PUB_KEY_SIZE],
                              uint8_t* const pms);
ATCA_STATUS talib_ecdh_io_buffer(ATCADevice device, const uint16_t priv_handle, const uint8_t* public_key,
                                 const size_t pubkey_len, uint8_t* const pms);
ATCA_STATUS talib_ecdh_xy_in_io_buffer(ATCADevice device, const uint16_t priv_handle, const uint8_t* public_key,
                                       const size_t pubkey_len, uint8_t* const pms);
ATCA_STATUS talib_ecdh_to_handle(ATCADevice device, const uint16_t priv_handle, const uint16_t
                                 target_handle, const uint8_t* public_key, const size_t pubkey_len);
ATCA_STATUS talib_ecdh_xy_to_handle(ATCADevice device, const uint16_t priv_handle, const uint16_t
                                    target_handle, const uint8_t* public_key, const size_t pubkey_len);

//Export command functions
ATCA_STATUS talib_export(ATCADevice device, const uint16_t key_handle, uint8_t* const export_data,
                         uint16_t* const export_data_length);

//FC config command functions
ATCA_STATUS talib_fcconfig_base(ATCADevice device, const uint8_t mode, const uint32_t handle,
                                uint32_t* const written_map);

//Import command functions
ATCA_STATUS talib_import_base(ATCADevice device, const uint8_t mode, const uint32_t handle, const
                              uint8_t* blob, const uint16_t blob_length);
ATCA_STATUS talib_import_handle(ATCADevice device, const uint16_t handle, const uint8_t* blob, const
                                uint16_t blob_length);
ATCA_STATUS talib_import_handle_with_target_links(ATCADevice device, const uint16_t handle, const uint8_t*
                                                  blob, const uint16_t blob_length);

//Info command functions
ATCA_STATUS talib_info_base(ATCADevice device, uint8_t mode, uint32_t param2, uint8_t* out_data,
                            size_t* data_size);
ATCA_STATUS talib_info(ATCADevice device, uint8_t revision[8]);
ATCA_STATUS talib_info_compat(ATCADevice device, uint8_t revision[4]);
ATCA_STATUS talib_info_serial_number(ATCADevice device, uint8_t serial_number[8]);
ATCA_STATUS talib_info_serial_number_compat(ATCADevice device, uint8_t serial_number[9]);
ATCA_STATUS talib_info_get_nv_remain(ATCADevice device, uint32_t* nv_remain);
ATCA_STATUS talib_is_handle_valid(ATCADevice device, uint32_t target_handle, uint8_t* is_valid);
ATCA_STATUS talib_info_get_handle_info(ATCADevice device, uint32_t target_handle, uint8_t handle_info[TA_HANDLE_INFO_SIZE]);
ATCA_STATUS talib_info_get_handles_array(ATCADevice device, uint16_t* handle_array, size_t* array_size);
ATCA_STATUS talib_info_get_handle_size(ATCADevice device, uint32_t target_handle, size_t* out_size);
ATCA_STATUS talib_is_auth_session_valid(ATCADevice device, uint8_t auth_session_id, uint8_t* is_valid);
ATCA_STATUS talib_is_volatile_register_valid(ATCADevice device, uint8_t volatile_register_id, uint8_t* is_valid);
ATCA_STATUS talib_info_get_dedicated_memory(ATCADevice device, uint8_t* dedicated_memory);
ATCA_STATUS talib_info_get_chip_status(ATCADevice device, uint8_t chip_status[TA_CHIP_STATUS_SIZE]);
ATCA_STATUS talib_is_config_locked(ATCADevice device, bool* is_locked);
ATCA_STATUS talib_is_setup_locked(ATCADevice device, bool* is_locked);
ATCA_STATUS talib_is_locked_compat(ATCADevice device, uint8_t zone, bool* is_locked);
ATCA_STATUS talib_info_get_vcc_latch(ATCADevice device, uint8_t* latch_value);
ATCA_STATUS talib_info_get_failure_log(ATCADevice device, uint8_t* failure_log);
ATCA_STATUS talib_info_get_rom_id(ATCADevice device, uint16_t* rom_id);
ATCA_STATUS talib_info_get_crl_handle(ATCADevice device, uint8_t* crl_handle);
ATCA_STATUS talib_is_handle_locked(ATCADevice device, uint16_t slot, bool* is_locked);
ATCA_STATUS talib_is_private(ATCADevice device, uint16_t handle, bool* is_private);

//KDF command functions
ATCA_STATUS talib_kdf_aesA(ATCADevice device, const uint16_t msg_handle, const uint16_t key_handle,
                           const uint16_t output_handle, const uint8_t* message, uint8_t* const
                           kdf_out);
ATCA_STATUS talib_kdf_aesA_io(ATCADevice device, const uint16_t key_handle, const uint16_t
                              msg_handle, const uint8_t* message, uint8_t* const kdf_output);
ATCA_STATUS talib_kdf_aesA_stored(ATCADevice device, const uint16_t key_handle, const uint16_t
                                  message_handle, const uint8_t* message, const uint16_t output_handle);
ATCA_STATUS talib_kdf_aesB(ATCADevice device, const uint16_t msg_handle, const uint16_t key_handle,
                           const uint16_t output_handle, const uint8_t* input_data, uint8_t* const
                           kdf_out);
ATCA_STATUS talib_kdf_aesB_io(ATCADevice device, const uint16_t key_handle,
                              const uint16_t message_handle, const uint8_t* input_data, uint8_t* const kdf_output);
ATCA_STATUS talib_kdf_aesB_stored(ATCADevice device, const uint16_t key_handle, const uint16_t
                                  output_handle, const uint16_t message_handle, const uint8_t* input_data);
ATCA_STATUS talib_hkdf(ATCADevice device, const uint16_t key_handle, const uint16_t output_handle,
                       const uint16_t salt_len, const uint16_t info_len, const uint8_t* salt, const
                       uint8_t* info, uint8_t* const kdf_out, uint16_t* const kdf_length);
ATCA_STATUS talib_hkdf_io(ATCADevice device, const uint16_t key_handle, const uint8_t* salt, const
                          uint16_t salt_len, const uint8_t* info, const uint16_t info_len, uint8_t*
                          const kdf_output, uint16_t* const kdf_length);
ATCA_STATUS talib_hkdf_stored(ATCADevice device, const uint16_t key_handle, const uint8_t* salt,
                              const size_t salt_len, const uint8_t* info, const size_t info_len,
                              const uint16_t target_handle, uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_prf(ATCADevice device, const uint16_t key_handle, const uint16_t
                          output_handle, const uint16_t input_len, const uint8_t* input_data,
                          uint8_t* const kdf_out, uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_prf_io(ATCADevice device, const uint16_t key_handle, const uint8_t
                             src_key_length, const uint8_t* input, const uint16_t input_len,
                             uint8_t* const kdf_output, uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_prf_stored(ATCADevice device, const uint16_t key_handle, const uint8_t
                                 src_key_length, const uint8_t* input, const uint16_t input_len,
                                 const uint16_t target_handle, uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_hmac_counter(ATCADevice device, const uint16_t key_handle, const uint16_t
                                   output_handle, const uint16_t label_len, const uint16_t
                                   context_len, const uint8_t* label, const uint8_t* context,
                                   uint8_t* const kdf_out, uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_hmac_counter_io(ATCADevice device, const uint16_t key_handle, const uint8_t*
                                      label, const uint16_t label_len, const uint8_t* context,
                                      const uint16_t context_len, uint8_t* const kdf_output,
                                      uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_hmac_counter_stored(ATCADevice device, const uint16_t key_handle, const
                                          uint8_t* label, const uint16_t label_len, const uint8_t*
                                          context, const uint16_t context_len, const uint16_t
                                          target_handle, uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_sha256(ATCADevice device, const uint16_t key_handle, const uint16_t
                             output_handle, const uint8_t* pre_pad, const uint16_t pre_len, const
                             uint8_t* post_pad, const uint16_t post_len, uint8_t* const kdf_out,
                             uint16_t* const kdf_length);
ATCA_STATUS talib_kdf_sha256_io(ATCADevice device, const uint16_t key_handle, const uint8_t*
                                pre_pad, const uint16_t pre_pad_len, const uint8_t* post_pad,
                                const uint16_t post_pad_len, uint8_t* const kdf_output, uint16_t*
                                const kdf_length);
ATCA_STATUS talib_kdf_sha256_stored(ATCADevice device, const uint16_t key_handle, const uint8_t*
                                    pre_pad, const uint16_t pre_pad_len, const uint8_t* post_pad,
                                    const uint16_t post_pad_len, const uint16_t target_handle,
                                    uint16_t* const kdf_length);

//KeyGen command functions
ATCA_STATUS talib_genkey_base(ATCADevice device, const uint8_t mode, const uint32_t key_handle,
                              uint8_t* const public_key, size_t * pubkey_len);
ATCA_STATUS talib_genkey(ATCADevice device, const uint16_t key_handle, uint8_t* const public_key, size_t * pubkey_len);
ATCA_STATUS talib_genkey_compat(ATCADevice device, const uint16_t key_handle, uint8_t public_key[64]);
ATCA_STATUS talib_get_pubkey_compat(ATCADevice device, const uint16_t key_handle, uint8_t public_key[64]);
ATCA_STATUS talib_get_pubkey(ATCADevice device, const uint16_t key_handle, uint8_t* const public_key,
                             size_t* pubkey_len);
ATCA_STATUS talib_genkey_symmetric_key(ATCADevice device, const uint16_t key_handle);

//Lock command functions
ATCA_STATUS talib_lock(ATCADevice device, const uint8_t mode, const uint32_t param2);
ATCA_STATUS talib_lock_config(ATCADevice device);
ATCA_STATUS talib_lock_config_with_crc(ATCADevice device, const uint16_t summary_crc);
ATCA_STATUS talib_lock_handle(ATCADevice device, const uint16_t handle);
ATCA_STATUS talib_lock_setup(ATCADevice device);
ATCA_STATUS talib_lock_onetime_latch(ATCADevice device);

//MAC command functions
ATCA_STATUS talib_mac_base(ATCADevice device, const uint16_t key_handle, const uint16_t key_index, const uint8_t* message,
                           const uint16_t msg_length, uint8_t* const digest, const uint16_t* mac_length);
ATCA_STATUS talib_cmac(ATCADevice device, const uint16_t key_handle, const uint16_t key_index,
                       const uint8_t* message, const uint16_t length, uint8_t* const cmac);
ATCA_STATUS talib_hmac(ATCADevice device, const uint16_t key_handle, const uint16_t key_index,
                       const uint8_t* message, const uint16_t length, uint8_t* const hmac);
ATCA_STATUS talib_hmac_compat(ATCADevice device, const uint8_t* data, size_t data_size, uint16_t key_slot,
                              uint8_t* digest, uint8_t target);

//Managecert command functions
ATCA_STATUS talib_manage_cert(ATCADevice device, const uint8_t mode, const uint16_t parent_handle,
                              const uint16_t target_handle, const uint16_t source_handle,
                              const uint8_t* in_cert, const uint16_t length);
ATCA_STATUS talib_store_extracted_cert_io(ATCADevice device, const uint16_t parent_handle,
                                          const uint16_t target_handle, const uint8_t* in_cert,
                                          const uint16_t cert_length);
ATCA_STATUS talib_store_extracted_cert(ATCADevice device, const uint16_t parent_handle,
                                       const uint16_t target_handle, const uint16_t source_handle);
ATCA_STATUS talib_verify_cert_io(ATCADevice device, const uint16_t parent_handle,
                                 const uint8_t* in_cert, const uint16_t cert_length);
ATCA_STATUS talib_verify_cert(ATCADevice device, const uint16_t parent_handle,
                              const uint16_t source_handle);

//Power command functions
ATCA_STATUS talib_power(ATCADevice device, const uint8_t mode);
ATCA_STATUS talib_power_reboot(ATCADevice device);
ATCA_STATUS talib_power_sleep(ATCADevice device);

//Random command functions
ATCA_STATUS talib_random(ATCADevice device, const uint8_t stir_data[16], uint8_t* const rand_out,
                         const uint32_t rand_length);
ATCA_STATUS talib_random_compat(ATCADevice device, uint8_t rand_out[32]);

//Read command functions
ATCA_STATUS talib_read(ATCADevice device, const uint8_t mode, const uint16_t transfer_handle,
                       const uint16_t key_handle, const uint16_t offset, uint16_t* const length,
                       uint8_t* const data_read, const uint8_t* mac);
ATCA_STATUS talib_read_element(ATCADevice device, const uint16_t key_handle, uint16_t* length, uint8_t*
                               data_out);
ATCA_STATUS talib_read_partial_element(ATCADevice device, const uint16_t key_handle, const uint16_t offset,
                                       uint16_t* length, uint8_t* data);
ATCA_STATUS talib_read_config_zone(ATCADevice device, uint8_t* config_data);
ATCA_STATUS talib_read_gpio_pin_state(ATCADevice device, uint16_t gpio_handle, uint8_t* pin_state);
ATCA_STATUS talib_read_pubkey_compat(ATCADevice device, const uint16_t handle, uint8_t public_key[TA_ECC256_PUB_KEY_SIZE]);
ATCA_STATUS talib_read_bytes_zone(ATCADevice device, const uint8_t zone, const uint16_t slot, const size_t offset,
                                  uint8_t* data, const size_t length);
ATCA_STATUS talib_read_sig_compat(ATCADevice device, const uint16_t handle, uint8_t signature[64]);
ATCA_STATUS talib_read_data_transfer(ATCADevice device, const uint16_t transfer_handle,
                                     uint8_t* const data, const uint8_t* transfer_mac);
ATCA_STATUS talib_cmp_config_zone(ATCADevice device, const uint8_t config_data[TA_CONFIG_SIZE],
                                  bool* same_config);

//RSAEnc command functions
ATCA_STATUS talib_rsaenc(ATCADevice device, const uint8_t mode, const uint16_t in_length, const
                         uint16_t handle, const uint8_t* data_in, uint8_t* const data_out, const
                         uint8_t* public_key, uint16_t* const out_length);
ATCA_STATUS talib_rsaenc_encrypt(ATCADevice device, const uint16_t handle, const uint16_t text_size,
                                 const uint8_t* plain_text, const uint16_t cipher_text_size,
                                 uint8_t* const cipher_text);
ATCA_STATUS talib_rsaenc_encrypt_with_iobuffer(ATCADevice device, const uint8_t* pub_key,
                                               const uint16_t text_size, const uint8_t* plain_text,
                                               const uint16_t cipher_text_size,
                                               uint8_t* const cipher_text);
ATCA_STATUS talib_rsaenc_decrypt(ATCADevice device, const uint16_t handle, const uint16_t
                                 text_size, const uint8_t* cipher_text, const uint16_t
                                 plain_text_size, uint8_t* const plain_text);

//Secureboot command functions
ATCA_STATUS talib_secureboot_full_asymmetric(ATCADevice device, const uint16_t dig_handle,
                                             const uint16_t pub_handle, const uint8_t* digest,
                                             const uint8_t* signature, const size_t sig_len,
                                             bool* is_validated);
ATCA_STATUS talib_secureboot_preset(ATCADevice device, const uint8_t mode, const uint16_t
                                    dig_handle, const uint16_t param, const uint8_t* digest);
ATCA_STATUS talib_secureboot_update(ATCADevice device, const uint8_t mode, const uint16_t
                                    dig_handle, const uint16_t pub_handle, const uint8_t* digest,
                                    const uint8_t* signature, const size_t sig_len,
                                    bool* is_validated);
ATCA_STATUS talib_secureboot_boot(ATCADevice device, const uint8_t mode, const uint16_t dig_handle,
                                  const uint8_t* digest, bool* is_validated);
ATCA_STATUS talib_secureboot_fullstore_preset(ATCADevice device, const uint8_t* digest);
ATCA_STATUS talib_secureboot_fullstore_update(ATCADevice device, const uint16_t dig_handle,
                                              const uint16_t pub_handle, const uint8_t* digest,
                                              const uint8_t* signature, const size_t sig_len,
                                              bool* is_validated);
ATCA_STATUS talib_secureboot_fullstore_boot(ATCADevice device, const uint16_t dig_handle,
                                            const uint8_t* digest, bool* is_validated);
ATCA_STATUS talib_secureboot_partial_preset(ATCADevice device);
ATCA_STATUS talib_secureboot_partial_setup(ATCADevice device, const uint32_t code_size);
ATCA_STATUS talib_secureboot_partial_code_base(ATCADevice device, const uint8_t mode, const uint8_t*
                                               code, const size_t code_size);
ATCA_STATUS talib_secureboot_partial_code(ATCADevice device, const uint8_t* code);
ATCA_STATUS talib_secureboot_partial_final(ATCADevice device, const uint8_t* code, const size_t
                                           code_size);
ATCA_STATUS talib_secureboot_partial_complete(ATCADevice device, const uint16_t pub_handle, const
                                              uint8_t* signature, const size_t sig_len,
                                              bool* is_validated);
ATCA_STATUS talib_secureboot_partial_address(ATCADevice device, uint32_t* const begin, uint32_t*
                                             const end);
ATCA_STATUS talib_secureboot_partial_boot(ATCADevice device, const uint16_t dig_handle,
                                          const uint8_t* digest, bool* is_validated);
ATCA_STATUS talib_secureboot_preboot_preset(ATCADevice device, const uint8_t* digest);
ATCA_STATUS talib_secureboot_preboot_update(ATCADevice device, const uint16_t dig_handle,
                                            const uint16_t pub_handle, const uint8_t* digest,
                                            const uint8_t* signature, const size_t sig_len,
                                            bool* is_validated);
ATCA_STATUS talib_secureboot_preboot_boot(ATCADevice device, const uint16_t dig_handle,
                                          const uint8_t* digest, bool* is_validated);
ATCA_STATUS talib_secureboot_common_lock(ATCADevice device);

//Self_Test command functions
ATCA_STATUS talib_selftest(ATCADevice device, const uint8_t mode, uint32_t tests_bitmap,
                           uint32_t* const result_bitmap);

//SHA command functions
ATCA_STATUS talib_sha_base(ATCADevice device, const uint8_t mode, const uint16_t length, const
                           uint16_t context_handle, const uint8_t* message, uint8_t* const data_out,
                           uint16_t* const data_out_size);
ATCA_STATUS talib_sha_base_compat(ATCADevice device, uint8_t mode, const uint16_t length,
                                  const uint8_t* message, uint8_t* const digest, uint16_t* const
                                  digest_size);
ATCA_STATUS talib_sha_start(ATCADevice device);
ATCA_STATUS talib_sha_start_with_handle(ATCADevice device, const uint16_t context_handle);
ATCA_STATUS talib_sha_update(ATCADevice device, const uint16_t message_length, const uint8_t
                             *message);
ATCA_STATUS talib_sha_update_with_handle(ATCADevice device, const uint16_t context_handle, const
                                         uint16_t message_length, const uint8_t *message);
ATCA_STATUS talib_sha_update_compat(ATCADevice device, const uint8_t* message);
ATCA_STATUS talib_sha_end(ATCADevice device, uint8_t* digest);
ATCA_STATUS talib_sha_end_with_handle(ATCADevice device, const uint16_t context_handle, uint8_t*
                                      digest);
ATCA_STATUS talib_sha_end_compat(ATCADevice device, uint8_t *digest, uint16_t length, const
                                 uint8_t* message);
ATCA_STATUS talib_sha(ATCADevice device, const uint16_t length, const uint8_t* message,
                      uint8_t digest[TA_SHA256_DIGEST_SIZE]);
ATCA_STATUS talib_sha_with_handle(ATCADevice device, const uint16_t context_handle, const uint16_t
                                  length, const uint8_t* message, uint8_t* const digest);
ATCA_STATUS talib_sha_read_context(ATCADevice device, uint8_t* const context, uint16_t* const
                                   context_size);
ATCA_STATUS talib_sha_read_context_with_handle(ATCADevice device, const uint16_t context_handle,
                                               uint8_t* const context, uint16_t* const
                                               context_size);
ATCA_STATUS talib_sha_write_context(ATCADevice device, const uint8_t* context, const uint16_t
                                    context_size);
ATCA_STATUS talib_sha_write_context_with_handle(ATCADevice device, const uint16_t context_handle,
                                                const uint8_t* context, const uint16_t
                                                context_size);
/*ATCA_STATUS talib_hw_sha2_256_init(ATCADevice device, atca_sha256_ctx_t* ctx);
   ATCA_STATUS talib_hw_sha2_256_update(ATCADevice device, atca_sha256_ctx_t* ctx, const uint8_t* data,
   size_t data_size);
   ATCA_STATUS talib_hw_sha2_256_finish(ATCADevice device, atca_sha256_ctx_t* ctx, uint8_t* digest);
   ATCA_STATUS talib_hw_sha2_256(ATCADevice device, const uint8_t * data, size_t data_size, uint8_t*
   digest);
 */

//Sign command funtions
ATCA_STATUS talib_sign_internal(ATCADevice device, const uint8_t mode, const uint16_t priv_handle,
                                const uint16_t template_handle, const uint16_t target_handle,
                                uint8_t* const signature, uint16_t* const sign_size);
ATCA_STATUS talib_sign_external(ATCADevice device, const uint8_t mode, const uint16_t priv_handle,
                                const uint16_t msg_handle, const uint8_t* message, const uint16_t
                                message_length, uint8_t* const signature, uint16_t* const sign_size);
ATCA_STATUS talib_sign_compat(ATCADevice device, const uint16_t key_id, const uint8_t msg[32],
                              uint8_t signature[64]);

//Verify command functions
ATCA_STATUS talib_verify(ATCADevice device, const uint8_t mode, const uint16_t msg_handle, const
                         uint16_t pub_handle, const uint8_t* signature, const uint16_t sign_size,
                         const uint8_t* message, const uint16_t message_len, const uint8_t* public_key, const uint16_t
                         pubkey_len, bool* is_verified);
ATCA_STATUS talib_verify_extern_compat(ATCADevice device, const uint8_t message[TA_VERIFY_P256_MSG_SIZE],
                                       const uint8_t signature[TA_SIGN_P256_SIG_SIZE],
                                       const uint8_t public_key[TA_ECC256_PUB_KEY_SIZE], bool* is_verified);
ATCA_STATUS talib_verify_stored_compat(ATCADevice device, const uint8_t message[TA_VERIFY_P256_MSG_SIZE],
                                       const uint8_t signature[TA_SIGN_P256_SIG_SIZE], const uint16_t key_id,
                                       bool* is_verified);
ATCA_STATUS talib_verify_point_exp(ATCADevice device, const uint8_t y_odd, const uint8_t* x_val,
                                   uint8_t* const y_val);

//Write command functions
ATCA_STATUS talib_write(ATCADevice device, const uint8_t mode, const uint16_t source_handle,
                        const uint16_t target_handle, const uint16_t length, const uint16_t offset,
                        const uint8_t* write_data, uint8_t* mac);
ATCA_STATUS talib_write_element(ATCADevice device, const uint16_t target_handle, const uint16_t length,
                                const uint8_t* write_data);
ATCA_STATUS talib_write_partial_element(ATCADevice device, const uint16_t target_handle, const uint16_t length,
                                        const uint16_t offset, const uint8_t* write_data);
ATCA_STATUS talib_write_config_zone(ATCADevice device, const uint8_t config_data[TA_CONFIG_SIZE]);
ATCA_STATUS talib_write_pubkey_compat(ATCADevice device, const uint16_t handle,
                                      const uint8_t public_key[TA_ECC256_PUB_KEY_SIZE]);
ATCA_STATUS talib_write_zone(ATCADevice device, const uint8_t zone, const uint16_t handle,
                             const uint8_t block, const uint8_t offset, const uint8_t* data, uint8_t len);
ATCA_STATUS talib_write_bytes_zone(ATCADevice device, const uint8_t zone, const uint16_t handle,
                                   const size_t offset_bytes, const uint8_t* data, const size_t length);
ATCA_STATUS talib_write_gpio_pin_state(ATCADevice device, const uint16_t gpio_handle,
                                       const uint8_t* pin_state);
ATCA_STATUS talib_write_volatile_shared_transfer(ATCADevice device, const uint16_t source_handle,
                                                 const uint16_t target_handle);
ATCA_STATUS talib_write_priv_key(ATCADevice device, const uint16_t key_handle, const uint16_t length,
                                 const uint8_t* private_key);
ATCA_STATUS talib_write_pub_key(ATCADevice device, const uint16_t key_handle, const uint16_t length,
                                const uint8_t* public_key);

//Helper functions for creating the Handle Attributes

ATCA_STATUS talib_handle_init_public_key(ta_element_attributes_t *element_attributes,
                                         const uint8_t key_type, const uint8_t alg_mode,
                                         const uint8_t secure_boot_enable, const uint8_t root_key_enable);

ATCA_STATUS talib_handle_init_private_key(ta_element_attributes_t *element_attributes,
                                          const uint8_t key_type, const uint8_t alg_mode,
                                          const uint8_t sign_use, const uint8_t key_agreement_use);

ATCA_STATUS talib_handle_init_symmetric_key(ta_element_attributes_t *element_attributes,
                                            const uint8_t key_type, const uint8_t sym_usage);

ATCA_STATUS talib_handle_init_data(ta_element_attributes_t *element_attributes, const uint16_t data_size);

ATCA_STATUS talib_handle_init_extracated_certificate(ta_element_attributes_t *element_attributes,
                                                     const uint8_t key_type, const uint8_t alg_mode,
                                                     const uint8_t secure_boot_use, const uint8_t intermediate_CA_enable);

ATCA_STATUS talib_handle_init_fast_crypto_key_group(ta_element_attributes_t * element_attributes,
                                                    const uint8_t key_type, const uint8_t no_of_keys,
                                                    const uint8_t handles);

ATCA_STATUS talib_handle_set_permissions(ta_element_attributes_t *element_attributes, const uint8_t usage_perm, const uint8_t write_perm,
                                         const uint8_t read_perm, const uint8_t delete_perm);

ATCA_STATUS talib_handle_set_usage_permission(ta_element_attributes_t* element_attributes, const uint8_t usage_perm);
ATCA_STATUS talib_handle_set_write_permission(ta_element_attributes_t* element_attributes, const uint8_t write_perm);
ATCA_STATUS talib_handle_set_read_permission(ta_element_attributes_t* element_attributes, const uint8_t read_perm);
ATCA_STATUS talib_handle_set_delete_permission(ta_element_attributes_t* element_attributes, const uint8_t delete_perm);


//Sequence command functions
ATCA_STATUS talib_sequence_base(ATCADevice device, const uint8_t mode, const uint32_t param,
                                const uint8_t* data_in, const uint16_t data_in_length,
                                uint8_t* const data_out, uint16_t* const data_out_length);
ATCA_STATUS talib_sharekey_sequence_init(ATCADevice device, sharekey_ctx_t* ctx, const uint16_t target_handle,
                                         const uint16_t ephe_handle, const uint16_t sign_handle,
                                         const uint16_t cert_handle, const uint16_t symm_key_size,
                                         const bool is_local_first, sharekey_cb_t sharekey_cb);
ATCA_STATUS talib_sequence_sharekey_step1(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step2(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step3(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step4(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step5(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step6(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step7(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step8(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step9(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sequence_sharekey_step10(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sharekey_sequence_execute(sharekey_ctx_t* ctx);
ATCA_STATUS talib_sharekey_sequence_terminate(sharekey_ctx_t* ctx);

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* TALIB_BASIC_H_ */
