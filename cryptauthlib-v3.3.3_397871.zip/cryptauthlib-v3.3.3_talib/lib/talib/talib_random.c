/**
 * \file
 * \brief Basic Random command for Trust Anchor Devices.
 *
 * The Random command generates a random number.
 *
 * \note List of devices that support this command - ATTA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes Random command and returns requested number of random bytes
 *
 * \param[in] device            Device context pointer
 * \param[in] stir_data         Extra data to be stirred into the random number calculation.
 *                              Should be 16 bytes
 * \param[out] rand_out         Requested number of random bytes are returned here
 * \param[in] rand_length       Contains number of random bytes to read
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_random(ATCADevice device, const uint8_t stir_data[16], uint8_t* const rand_out,
                         const uint32_t rand_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint32_t length;

    if ((NULL == device) || (NULL == rand_out) || !rand_length || (rand_length > TA_RANDOM_MAX_RESP_LENGTH))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid rand length received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        // calculate number of iterations required for given rand_length
        length = (rand_length / 32) + ((rand_length % 32) != 0);

        packet->opcode = TA_OPCODE_RANDOM;
        packet->param1 = TA_RANDOM_MODE;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(length);

        if (stir_data)
        {
            memcpy(packet->data, stir_data, TA_RANDOM_STIR_DATA_LENGTH);
        }
        else
        {
            memset(packet->data, 0, TA_RANDOM_STIR_DATA_LENGTH);
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(TA_RANDOM_STIR_DATA_LENGTH +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {

            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (length)
            {
                memcpy(rand_out, resp_packet->data, (size_t)rand_length);
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief Compatibility mode which generates a 32 byte random number
 *          from the TA100 device.
 *
 * \param[in]  device    Device context pointer
 * \param[out] rand_out  32 bytes of random data is returned here.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_random_compat(ATCADevice device, uint8_t rand_out[32])
{
    uint8_t stir_data[16] = { 0 };

    return talib_random(device, stir_data, rand_out, 32);
}
