/**
 * \file
 * \brief Basic write commands for the Trust Anchor Devices
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

#ifndef ATCA_BLOCK_SIZE
/* Cryptoauth compatibility */
#define ATCA_BLOCK_SIZE         (32)
#endif

#ifndef ATCA_WORD_SIZE
/* Cryptoauth compatibility */
#define ATCA_WORD_SIZE          (4)
#endif

/** \brief TA API - Executes Write command to write an element.
 *              This supports both partial and completed writes
 *              Restrictions apply based on attributes of the element
 *
 *  \param[in]     device              Device context pointer
 *  \param[in]     mode                mode parameter for the write operations
 *  \param[in]     source_handle       Memory handle to source data from...
 *                                      Must be IO buffer or volatile register
 *  \param[in]     target_handle       Target handle to write data
 *  \param[in]     length              Number of bytes to write. Cannot exceed element size
 *  \param[in]     offset              Offset to the first byte to be written...
 *                                      Valid only for partial writes
 *  \param[in]     write_data          Data to write if source_handle points to IO buffer
 *  \param[out]    mac                  MAC returned for the transfer function.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write(ATCADevice device, const uint8_t mode, const uint16_t source_handle,
                        const uint16_t target_handle, const uint16_t length, const uint16_t offset,
                        const uint8_t* write_data, uint8_t* mac)
{
    ATCA_STATUS status = ATCA_SUCCESS;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;
    uint16_t tmp16;

    if (device == NULL)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_WRITE;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(source_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(target_handle);

        data = packet->data;
        if ((mode & TA_WRITE_ENTIRE_ELEMENT) != TA_WRITE_ENTIRE_ELEMENT)
        {
            //Check the write data length whether it is less than 1020 (Partial write mode)
            if (length > TA_WRITE_MAX_PARTIAL_DATA_LEN)
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid length received");
            }
            else
            {
                tmp16 = ATCA_UINT16_HOST_TO_BE(length);
                memcpy(data, &tmp16, sizeof(length));
                data += sizeof(length);
                tmp16 = ATCA_UINT16_HOST_TO_BE(offset);
                memcpy(data, &tmp16, sizeof(offset));
                data += sizeof(offset);
            }
        }
        else
        {
            //Check the write data length whether it is less than 1024 (entire write mode)

            if ((length > TA_WRITE_MAX_DATA_LENGTH) && ((mode & TA_WRITE_FOR_TRANSFER) != TA_WRITE_FOR_TRANSFER))
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid length received");
            }
        }

        if (ATCA_SUCCESS == status)
        {
            //copy write_data into input stream
            if ((source_handle & TA_HANDLE_INPUT_BUFFER) == TA_HANDLE_INPUT_BUFFER)
            {
                if (write_data == NULL)
                {
                    status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
                }
                memcpy(data, write_data, length);
                data += length;
            }
        }

        if (ATCA_SUCCESS == status)
        {
            //Update length including length, opcode, param1, param2 and CRC
            packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) + ATCA_CMD_BUILD_MIN_LENGTH);

            status = ATCA_TRACE(talib_execute_command(packet, device), "");
        }

        if (ATCA_SUCCESS == status)
        {
            //In transfer authorize session there must be mac appended to the command
            if ((mode & TA_WRITE_FOR_TRANSFER) == TA_WRITE_FOR_TRANSFER)
            {
                if (mac)
                {
                    data = (uint8_t*)packet;
                    memcpy(mac, ++data, TA_WRITE_TRANSFER_MAC_SIZE);
                }
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes Write command to write an entire element.
 *
 *  \param[in]     device              Device context pointer
 *  \param[in]     target_handle       Target handle to write data
 *  \param[in]     length              Number of bytes to write. Cannot exceed element size
 *                                      Valid only for partial writes
 *  \param[in]     write_data          Data to write if source_handle points to IO buffer
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_element(ATCADevice device, const uint16_t target_handle, const uint16_t length,
                                const uint8_t* write_data)
{
    return talib_write(device, TA_WRITE_ENTIRE_ELEMENT, TA_HANDLE_INPUT_BUFFER,
                       target_handle, length, 0, write_data, NULL);
}

/** \brief TA API - Executes Write command to write a partial element.
 *
 *  \param[in]     device              Device context pointer
 *  \param[in]     target_handle       Target handle to write data
 *  \param[in]     length              Number of bytes to write. Cannot exceed element size
 *  \param[in]     offset              Offset to the first byte to be written...
 *                                      Valid only for partial writes
 *  \param[in]     write_data          Data to write if source_handle points to IO buffer
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_partial_element(ATCADevice device, const uint16_t target_handle, const uint16_t length,
                                        const uint16_t offset, const uint8_t* write_data)
{
    return talib_write(device, TA_WRITE_PARTIAL_ELEMENT, TA_HANDLE_INPUT_BUFFER,
                       target_handle, length, offset, write_data, NULL);
}

/** \brief Executes the Write command, which writes the configuration zone.
 *
 *  This command may fail if UserExtra and/or Selector bytes have
 *  already been set to non-zero values.
 *
 *  \param[in] device       Device context pointer
 *  \param[in] config_data  Data to the config zone data. .
 *
 *  \returns ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_config_zone(ATCADevice device, const uint8_t config_data[TA_CONFIG_SIZE])
{
    return talib_write_element(device, TA_HANDLE_CONFIG_MEMORY, TA_CONFIG_SIZE,
                               config_data);
}

/** \brief Executes the Write command, which writes a public key to a data handle
 *          in the device format.
 *
 *  \param[in] device      Device context pointer
 *  \param[in] handle      refer to handle where public key reside
 *  \param[in] public_key  Public key to write into the handle specified. X and Y
 *                         integers in big-endian format. 64 bytes for P256
 *                         curve.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_pubkey_compat(ATCADevice device, const uint16_t handle, const uint8_t public_key[TA_ECC256_PUB_KEY_SIZE])
{
    return talib_write_element(device, handle, TA_ECC256_PUB_KEY_SIZE, public_key);
}

/** \brief Executes the Write command in compability mode
 *
 * Config zone must be unlocked for writes to that zone.
 *
 *  \param[in] device        Device context pointer
 *  \param[in] zone          Unused parameter
 *  \param[in] handle        the handle number to write to.
 *  \param[in] block         Block number (cryptoauth block size is 32 bytes)
 *  \param[in] offset        Byte offset within the "block" to write to.
 *  \param[in] data          Data to be written.
 *  \param[in] length        Number of bytes to be written.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_zone(ATCADevice device, const uint8_t zone, const uint16_t handle,
                             const uint8_t block, const uint8_t offset, const uint8_t* data, uint8_t length)
{
    (void)zone;
    uint16_t offset_bytes = (uint16_t)block * ATCA_BLOCK_SIZE + (uint16_t)offset * ATCA_WORD_SIZE;
    return talib_write_partial_element(device, handle, length, offset_bytes, data);
}

/** \brief Executes the Write command
 *
 * Config zone must be unlocked for writes to that zone.
 *
 *  \param[in] device        Device context pointer
 *  \param[in] zone          Unused parameter
 *  \param[in] handle        the handle number to write to.
 *  \param[in] offset_bytes  Byte offset within the handle to write to.
 *  \param[in] data          Data to be written.
 *  \param[in] length        Number of bytes to be written.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_bytes_zone(ATCADevice device, const uint8_t zone, const uint16_t handle,
                                   const size_t offset_bytes, const uint8_t* data, const size_t length)
{
    (void)zone;
    if (0 == offset_bytes && ATCA_CMD_DATA_MAX_LENGTH > length)
    {
        return talib_write_element(device, handle, (uint16_t)length, data);
    }
    else
    {
        return talib_write_partial_element(device, handle, (uint16_t)length, (uint16_t)offset_bytes, data);
    }
}

/** \brief Executes write command to write the gpio pin state
 *
 *  \param[in]  device       Device context pointer
 *  \param[in]  gpio_handle  refer to gpio handle (gpio1, gpio2, gpio2)
 *  \param[in]  pin_state    state of the gpio pin
 *
 *  \returns ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_gpio_pin_state(ATCADevice device, const uint16_t gpio_handle, const uint8_t* pin_state)
{
    ATCA_STATUS status;

    do
    {
        if ((gpio_handle < TA_HANDLE_GPIO1 || gpio_handle > TA_HANDLE_GPIO3))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid gpio handle received");
            break;
        }

        status = talib_write_element(device, gpio_handle, 1, pin_state);
    }
    while (0);

    return status;
}

/** \brief Executes write command to transfer key from vol_reg to shared data
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  source_handle  handle from data will be copied
 *  \param[in]  target_handle  handle where data will be written
 *
 *  \returns ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_volatile_shared_transfer(ATCADevice device, const uint16_t source_handle,
                                                 const uint16_t target_handle)
{
    return talib_write(device, TA_WRITE_TRANSFER_KEY_VOL_SHARED, source_handle, target_handle,
                       0, 0, NULL, NULL);
}

/** \brief TA API - Executes Write command to write a private key.
 *
 *  \param[in]     device              Device context pointer
 *  \param[in]     key_handle          Target handle to write data
 *  \param[in]     length              Number of bytes to write. Cannot exceed element size
 *                                      Valid only for partial writes
 *  \param[in]     private_key         private key to write into key_handle mentioned
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_priv_key(ATCADevice device, const uint16_t key_handle, const uint16_t length,
                                 const uint8_t* private_key)
{
    return talib_write_element(device, key_handle, length, private_key);
}

/** \brief TA API - Executes Write command to write a public key.
 *
 *  \param[in]     device              Device context pointer
 *  \param[in]     key_handle          Target handle to write data
 *  \param[in]     length              The size of the public key. Cannot exceed element size
 *  \param[in]     public_key          Public key to write into key_handle mentioned
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_write_pub_key(ATCADevice device, const uint16_t key_handle, const uint16_t length,
                                const uint8_t* public_key)
{
    return talib_write_element(device, key_handle, length, public_key);
}
