#ifndef TALIB_DEFINES_H
#define TALIB_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

#define ATCA_CMD_DATA_MAX_LENGTH                        1024
#define ATCA_FAST_CRYPTO_DATA_MAX_LENGTH                64
#define ATCA_CMD_PARSE_MIN_LENGTH                       5
#define ATCA_CMD_BUILD_MIN_LENGTH                       10
#define ATCA_CMD_PARSE_MAX_LENGTH                       (ATCA_CMD_DATA_MAX_LENGTH + ATCA_CMD_PARSE_MIN_LENGTH)
#define ATCA_CMD_BUILD_MAX_LENGTH                       (ATCA_CMD_DATA_MAX_LENGTH + 8) //Excluding CRC

#define TA_RSP_DATA_IDX                                 (3)                            //!< buffer index of data in response
#define TA_CMD_SIZE_MIN                                 (10)                           //! minimum number of bytes in command (from count byte to second CRC byte)

#define TA_CONFIG_SIZE                                  (48)
#define TA_GPIO_MODE_MASK                               0x07
#define TA_GPIO_PIN_STATE_MASK                          0x01
#define TA_COPY_VOL_REG_MASK                            0x02

/* TA Handles */
#define TA_HANDLE_MASK                                  0xFFFF
#define TA_HANDLE_SHA_CONTEXT0                          0x4000
#define TA_HANDLE_SHA_CONTEXT1                          0x4001
#define TA_HANDLE_AUTH_SESSION                          0x4100
#define TA_HANDLE_GPIO1                                 0x4300
#define TA_HANDLE_GPIO2                                 0x4301
#define TA_HANDLE_GPIO3                                 0x4302
#define TA_HANDLE_VOLATILE_REGISTER0                    0x4400
#define TA_HANDLE_VOLATILE_REGISTER1                    0x4401
#define TA_HANDLE_VOLATILE_REGISTER2                    0x4402
#define TA_HANDLE_VOLATILE_REGISTER3                    0x4403
#define TA_HANDLE_INPUT_BUFFER                          0x4800
#define TA_HANDLE_OUTPUT_BUFFER                         0x4801
#define TA_HANDLE_FAST_CRYPTO_OUTPUT                    0x4C00
#define TA_HANDLE_LINKED_SHARED_DATA                    0x8000
#define TA_HANDLE_SECURE_BOOT_DATA_HANDLE0              0xBFFE
#define TA_HANDLE_SECURE_BOOT_DATA_HANDLE1              0xBFFF
#define TA_HANDLE_SHARED_DATA                           0x8100
#define TA_HANDLE_CONFIG_MEMORY                         0xC000
#define TA_HANDLE_COUNTER0                              0xD100
#define TA_HANDLE_COUNTER1                              0xD101
#define TA_HANDLE_COUNTER2                              0xD102
#define TA_HANDLE_COUNTER3                              0xD103


/* TA Key Types & Info */
#define TA_KEY_TYPE_ECCP256                             (0)
#define TA_KEY_TYPE_ECCP256_SIZE                        (32)
#define TA_KEY_TYPE_ECCP224                             (1)
#define TA_KEY_TYPE_ECCP224_SIZE                        (28)
#define TA_KEY_TYPE_ECCP384                             (2)
#define TA_KEY_TYPE_ECCP384_SIZE                        (48)
#define TA_KEY_TYPE_RSA1024                             (4)
#define TA_KEY_TYPE_RSA1024_SIZE                        (128)
#define TA_KEY_TYPE_RSA2048                             (5)
#define TA_KEY_TYPE_RSA2048_SIZE                        (256)
#define TA_KEY_TYPE_RSA3072                             (6)
#define TA_KEY_TYPE_RSA3072_SIZE                        (384)
#define TA_KEY_TYPE_HMAC                                (8)
#define TA_KEY_TYPE_SECP256K1                           (9)
#define TA_KEY_TYPE_ECCP256K1_SIZE                      (32)
#define TA_KEY_TYPE_ECCBP256R1                          (10)
#define TA_KEY_TYPE_ECCBP256R1_SIZE                     (32)
#define TA_KEY_TYPE_AES128                              (12)
#define TA_KEY_TYPE_AES128_SIZE                         (16)

/* TA Algorithm Modes */
#define TA_ALG_MODE_SHIFT                               (4)
#define TA_ALG_MODE_MASK                                (0xF << TA_ALG_MODE_SHIFT)
#define TA_ALG_MODE(v)                                  (TA_ALG_MODE_MASK & (v << TA_ALG_MODE_SHIFT))
#define TA_ALG_MODE_SHA256_DIGEST                       (0)
#define TA_ALG_MODE_SHA256_HMAC                         (1)
#define TA_ALG_MODE_AES128_CMAC                         (0)
#define TA_ALG_MODE_AES128_GCM                          (1)
#define TA_ALG_MODE_RSA_SSA_1_5                         (0)
#define TA_ALG_MODE_RSA_SSA_PSS                         (1)
#define TA_ALG_MODE_ECC_ECDSA                           (0)
#define TA_ALG_MODE_ECC_ECDH                            (1)

/* Algorithm ID - Alg_ID */
#define TA_ALG_ID(kt, m)                                (kt | TA_ALG_MODE(m))

/* Handle Class Types */
#define TA_CLASS_PUBLIC_KEY                             0x00
#define TA_CLASS_PRIVATE_KEY                            0x01
#define TA_CLASS_SYMMETRIC_KEY                          0x02
#define TA_CLASS_DATA                                   0x03
#define TA_CLASS_EXTRACTED_CERT                         0x04
#define TA_CLASS_RESERVED                               0x05
#define TA_CLASS_FAST_CRYPTO_KEY_GROUP                  0x06
#define TA_CLASS_CRL                                    0x07

/* Handle configuration key usage_perm/PERM_WRITE/PERM_READ macro definitions */
#define TA_PERM_NEVER                                   0x00
#define TA_PERM_ALWAYS                                  0x01
#define TA_PERM_AUTH                                    0x02
#define TA_PERM_RIGHTS                                  0x03

#define TA_PERM_ALL_ALWAYS                              0x55
#define TA_PERM_ALL_AUTH                                0xAA
#define TA_PERM_ALL_RIGHTS                              0xFF

#define TA_PERM_USAGE_SHIFT                             (0)
#define TA_PERM_USAGE_MASK                              (0x03 << TA_PERM_USAGE_SHIFT)
#define TA_PERM_USAGE(v)                                (TA_PERM_USAGE_MASK & (v << TA_PERM_USAGE_SHIFT))

#define TA_PERM_WRITE_SHIFT                             (2)
#define TA_PERM_WRITE_MASK                              (0x03 << TA_PERM_WRITE_SHIFT)
#define TA_PERM_WRITE(v)                                (TA_PERM_WRITE_MASK & (v << TA_PERM_WRITE_SHIFT))

#define TA_PERM_READ_SHIFT                              (4)
#define TA_PERM_READ_MASK                               (0x03 << TA_PERM_READ_SHIFT)
#define TA_PERM_READ(v)                                 (TA_PERM_READ_MASK & (v << TA_PERM_READ_SHIFT))

#define TA_PERM_DELETE_SHIFT                            (6)
#define TA_PERM_DELETE_MASK                             (0x03 << TA_PERM_DELETE_SHIFT)
#define TA_PERM_DELETE(v)                               (TA_PERM_DELETE_MASK & (v << TA_PERM_DELETE_SHIFT))

#define TA_EXPORTABLE_SHIFT                             (3)
#define TA_NOT_EXPORTABLE_FROM_CHIP                     0x00
#define TA_NOT_EXPORTABLE_FROM_CHIP_MASK                (TA_NOT_EXPORTABLE_FROM_CHIP << TA_EXPORTABLE_SHIFT)
#define TA_EXPORTABLE_FROM_CHIP                         0x01
#define TA_EXPORTABLE_FROM_CHIP_MASK                    (TA_EXPORTABLE_FROM_CHIP << TA_EXPORTABLE_SHIFT)

#define TA_LOCKABLE_SHIFT                               (4)
#define TA_PERMANENTLY_NOT_LOCKABLE                     0x00
#define TA_PERMANENTLY_NOT_LOCKABLE_MASK                (TA_PERMANENTLY_NOT_LOCKABLE << TA_LOCKABLE_SHIFT)
#define TA_PERMANENTLY_LOCKABLE                         0x01
#define TA_PERMANENTLY_LOCKABLE_MASK                    (TA_PERMANENTLY_LOCKABLE << TA_LOCKABLE_SHIFT)

/* Handle configuration key Access limit macro definitions */
#define TA_ACCESS_LIMIT_SHIFT                          (5)
#define TA_ACCESS_LIMIT_ALWAYS                          0x00
#define TA_ACCESS_LIMIT_ALWAYS_MASK                     (TA_ACCESS_LIMIT_ALWAYS << TA_ACCESS_LIMIT_SHIFT)
#define TA_ACCESS_LIMIT_SECURE_BOOT                     0x01
#define TA_ACCESS_LIMIT_SECURE_BOOT_MASK                (TA_ACCESS_LIMIT_SECURE_BOOT << TA_ACCESS_LIMIT_SHIFT)
#define TA_ACCESS_LIMIT_ONE_TIME_CLEAR                  0x02
#define TA_ACCESS_LIMIT_ONE_TIME_CLEAR_MASK             (TA_ACCESS_LIMIT_ONE_TIME_CLEAR << TA_ACCESS_LIMIT_SHIFT)
#define TA_ACCESS_LIMIT_ONE_TIME_SET                    0x03
#define TA_ACCESS_LIMIT_ONE_TIME_SET_MASK               (TA_ACCESS_LIMIT_ONE_TIME_SET << TA_ACCESS_LIMIT_SHIFT)

/* Public key properties macro definitions */
#define TA_PROP_PATH_LEN_NO_RES                         0xFF

#define TA_PROP_SECURE_BOOT_SHIFT                       (8)
#define TA_PROP_VAL_NO_SECURE_BOOT_SIGN                 0x00
#define TA_PROP_VAL_NO_SECURE_BOOT_SIGN_MASK            (0x00u << TA_PROP_SECURE_BOOT_SHIFT)
#define TA_PROP_VAL_SECURE_BOOT_SIGN                    0x01
#define TA_PROP_VAL_SECURE_BOOT_SIGN_MASK               (0x01u << TA_PROP_SECURE_BOOT_SHIFT)

#define TA_PROP_ROOT_SHIFT                              (9)
#define TA_PROP_ROOT_PUB_KEY_VERIFY                     0x00
#define TA_PROP_ROOT_PUB_KEY_VERIFY_MASK                (0x00u << TA_PROP_ROOT_SHIFT)
#define TA_PROP_ROOT_PUB_KEY_SECURE_BOOT                0x03
#define TA_PROP_ROOT_PUB_KEY_SECURE_BOOT_MASK           (0x03u << TA_PROP_ROOT_SHIFT)
#define TA_PROP_ROOT_PUB_KEY_MANAGE_CERT                0x03
#define TA_PROP_ROOT_PUB_KEY_MANAGE_CERT_MASK           (0x03u << TA_PROP_ROOT_SHIFT)

#define TA_PUB_PROP_CRL_SHIFT                           (11)
#define TA_PROP_PUB_KEY_CRL_SIGN_NOK                    0x00
#define TA_PROP_PUB_KEY_CRL_SIGN_NOK_MASK               (0x00u << TA_PUB_PROP_CRL_SHIFT)
#define TA_PROP_PUB_KEY_CRL_SIGN_OK                     0x01
#define TA_PROP_PUB_KEY_CRL_SIGN_OK_MASK                (0x01u << TA_PUB_PROP_CRL_SHIFT)

#define TA_PROP_SIGN_CERT_SHIFT                         (12)
#define TA_PROP_SIGN_ANY_CERT                           0x00
#define TA_PROP_SIGN_ANY_CERT_MASK                      (0x00u << TA_PROP_SIGN_CERT_SHIFT)
#define TA_PROP_SIGN_ONLY_SPL_CERT                      0x01
#define TA_PROP_SIGN_ONLY_SPL_CERT_MASK                 (0x01u << TA_PROP_SIGN_CERT_SHIFT)

/* Private key properties macro definitions */
#define TA_PROP_SESSION_KEY_SHIFT                       (8)
#define TA_PROP_SESSION_KEY_SEQ_USE                     0x01
#define TA_PROP_SESSION_KEY_SEQ_USE_MASK                (0x01u << TA_PROP_SESSION_KEY_SHIFT)

#define TA_PROP_KEY_GEN_SHIFT                           (9)
#define TA_PROP_EXECUTE_ONLY_KEY_GEN                    0x01
#define TA_PROP_EXECUTE_ONLY_KEY_GEN_MASK               (0x01u << TA_PROP_KEY_GEN_SHIFT)

#define TA_PROP_SIGN_USE_SHIFT                          (10)
#define TA_PROP_NO_SIGN_GENERATION                      0x00
#define TA_PROP_NO_SIGN_GENERATION_MASK                 (0x00u << TA_PROP_SIGN_USE_SHIFT)
#define TA_PROP_SIGN_INT_EXT_DIGEST                     0x01
#define TA_PROP_SIGN_INT_EXT_DIGEST_MASK                (0x01u << TA_PROP_SIGN_USE_SHIFT)
#define TA_PROP_SIGN_ONLY_INT_DIGEST                    0x02
#define TA_PROP_SIGN_ONLY_INT_DIGEST_MASK               (0x02u << TA_PROP_SIGN_USE_SHIFT)
#define TA_PROP_SIGN_ONLY_EXT_DIGEST                    0x03
#define TA_PROP_SIGN_ONLY_EXT_DIGEST_MASK               (0x03u << TA_PROP_SIGN_USE_SHIFT)

#define TA_PROP_KEY_AGREEMENT_SHIFT                     (12)
#define TA_PROP_NO_KEY_AGREEMENT                        0x00
#define TA_PROP_NO_KEY_AGREEMENT_MASK                   (0x00u << TA_PROP_KEY_AGREEMENT_SHIFT)
#define TA_PROP_KEY_AGREEMENT_OUT_BUFF                  0x01
#define TA_PROP_KEY_AGREEMENT_OUT_BUFF_MASK             (0x01u << TA_PROP_KEY_AGREEMENT_SHIFT)
#define TA_PROP_KEY_AGREEMENT_DATA_MEM                  0x02
#define TA_PROP_KEY_AGREEMENT_DATA_MEM_MASK             (0x02u << TA_PROP_KEY_AGREEMENT_SHIFT)
#define TA_PROP_KEY_AGREEMNET_VOL_REG                   0x02
#define TA_PROP_KEY_AGREEMNET_VOL_REG_MASK              (0x02u << TA_PROP_KEY_AGREEMENT_SHIFT)
#define TA_PROP_KEY_AGREEMENT_USAGE_RES                 0x03
#define TA_PROP_KEY_AGREEMENT_USAGE_RES_MASK            (0x03u << TA_PROP_KEY_AGREEMENT_SHIFT)

/* Symmetric key properties macro definitions */
#define TA_PROP_SYM_USAGE_SHIFT                         (8)
#define TA_PROP_SYMM_KEY_USAGE_MAC                      0x00
#define TA_PROP_SYMM_KEY_USAGE_MAC_MASK                 (0x00u << TA_PROP_SYM_USAGE_SHIFT)
#define TA_PROP_SYMM_KEY_USAGE_ENC                      0x01
#define TA_PROP_SYMM_KEY_USAGE_ENC_MASK                 (0x01u << TA_PROP_SYM_USAGE_SHIFT)
#define TA_PROP_SYMM_KEY_USAGE_ANY                      0x02
#define TA_PROP_SYMM_KEY_USAGE_ANY_MASK                 (0x02u << TA_PROP_SYM_USAGE_SHIFT)
#define TA_PROP_SYMM_KEY_USAGE_KDF_SHA                  0x03
#define TA_PROP_SYMM_KEY_USAGE_KDF_SHA_MASK             (0x03u << TA_PROP_SYM_USAGE_SHIFT)

#define TA_PROP_SYMM_KEY_SESSION_SHIFT                  (10)
#define TA_PROP_SYMM_KEY_NEVER_AUTH_USE                 0x00
#define TA_PROP_SYMM_KEY_NEVER_AUTH_USE_MASK            (0x00u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_EITHER_OPTIONAL                0x01
#define TA_PROP_SYMM_KEY_EITHER_OPTIONAL_MASK           (0x01u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_EITHER_RANDOM                  0x02
#define TA_PROP_SYMM_KEY_EITHER_RANDOM_MASK             (0x02u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_EITHER_ENC_RANDOM              0x03
#define TA_PROP_SYMM_KEY_EITHER_ENC_RANDOM_MASK         (0x03u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_ONLY_ALL                       0x04
#define TA_PROP_SYMM_KEY_ONLY_ALL_MASK                  (0x04u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_ONLY_OPTIONAL                  0x05
#define TA_PROP_SYMM_KEY_ONLY_OPTIONAL_MASK             (0x05u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_ONLY_RANDOM                    0x06
#define TA_PROP_SYMM_KEY_ONLY_RANDOM_MASK               (0x06u << TA_PROP_SYMM_KEY_SESSION_SHIFT)
#define TA_PROP_SYMM_KEY_ONLY_ENC_RANDOM                0x07
#define TA_PROP_SYMM_KEY_ONLY_ENC_RANDOM_MASK           (0x07u << TA_PROP_SYMM_KEY_SESSION_SHIFT)

#define TA_PROP_KEY_GROUP_SHIFT                         (13)
#define TA_PROP_KEY_GROUP_NOK                           0x00
#define TA_PROP_KEY_GROUP_NOK_MASK                      (0x00u << TA_PROP_KEY_GROUP_SHIFT)
#define TA_PROP_KEY_GROUP_OK                            0x01
#define TA_PROP_KEY_GROUP_OK_MASK                       (0x01u << TA_PROP_KEY_GROUP_SHIFT)

/* FCE Key Group Properties */
#define TA_PROP_FCE_NUM_KEYS_SHIFT                      (0)
#define TA_PROP_FCE_NUM_KEYS_MASK                       (0x1Fu << TA_PROP_FCE_NUM_KEYS_SHIFT)
#define TA_PROP_FCE_HANDLES_SHIFT                       (5)
#define TA_PROP_FCE_HANDLES_MASK                        (0x01u << TA_PROP_FCE_HANDLES_SHIFT)

/* Data properties macro definitions */
#define TA_DATA_TEMPLATE_SHIFT                          (12)
#define TA_ELEMENT_DATA_PROP_MASK(t, s)                 ((t << TA_DATA_TEMPLATE_SHIFT) | s)
#define TA_ELEMENT_MAX_DATA_SIZE                        (2048)

/* Certificate properties macro definitions */
#define TA_CERT_PROP_SEC_BOOT_SHIFT                     (8)
#define TA_PROP_VAL_SECURE_BOOT_DIGEST                  0x01
#define TA_PROP_VAL_SECURE_BOOT_DIGEST_MASK             (0x01u << TA_CERT_PROP_SEC_BOOT_SHIFT)

#define TA_CERT_PROP_CA_OK_SHIFT                        (9)
#define TA_PROP_CERT_CA_NOK                             0x00
#define TA_PROP_CERT_CA_NOK_MASK                        (0x00u << TA_CERT_PROP_CA_OK_SHIFT)
#define TA_PROP_CERT_CA_OK                              0x01
#define TA_PROP_CERT_CA_OK_MASK                         (0x01u << TA_CERT_PROP_CA_OK_SHIFT)

#define TA_CERT_PROP_CA_PARENT_SHIFT                    (10)
#define TA_PROP_CA_PARENT_NOK                           0x00
#define TA_PROP_CA_PARENT_NOK_MASK                      (0x00u << TA_CERT_PROP_CA_PARENT_SHIFT)
#define TA_PROP_CA_PARENT_OK                            0x01
#define TA_PROP_CA_PARENT_OK_MASK                       (0x01u << TA_CERT_PROP_CA_PARENT_SHIFT)

#define TA_CERT_CRL_SIGN_SHIFT                          (11)
#define TA_CERT_CRL_SIGN_NOK                            0x00
#define TA_CERT_CRL_SIGN_NOK_MASK                       (0x00u << TA_CERT_CRL_SIGN_SHIFT)
#define TA_CERT_CRL_SIGN_OK                             0x01
#define TA_CERT_CRL_SIGN_OK_MASK                        (0x01u << TA_CERT_CRL_SIGN_SHIFT)

#define TA_CERT_SIGN_SPL_SHIFT                          (12)
#define TA_CERT_SIGN_ANY_CERT                           0x00
#define TA_CERT_SIGN_ANY_CERT_MASK                      (0x00u << TA_CERT_SIGN_SPL_SHIFT)
#define TA_CERT_SIGN_ONLY_SPL_CERT                      0x01
#define TA_CERT_SIGN_ONLY_SPL_CERT_MASK                 (0x01u << TA_CERT_SIGN_SPL_SHIFT)

#define ATCA_MAIN_PROCESSOR_WR_CMD                      0x00
#define ATCA_MAIN_PROCESSOR_RD_CMD                      0x10
#define ATCA_MAIN_PROCESSOR_WR_CCR                      0x20
#define ATCA_MAIN_PROCESSOR_RD_CSR                      0x30
#define ATCA_REGISTER_CSR_STATUS_MASK                   0x06
#define ATCA_REGISTER_CSR_RRDY_MASK                     0x10
#define ATCA_REGISTER_CSR_STATUS_AVAILABLE_MASK         0x00
#define ATCA_REGISTER_CSR_STATUS_AVAILABLE_FIRST_MASK   0x02

#define TA_AUTH_SESSION_MAX                             (2)
#define TA_VOLATILE_REGISTER_MAX                        (4)
#define TA_DEDICATED_MEMORY_SIZE                        (16)
#define TA_CHIP_STATUS_SIZE                             (6)
#define TA_HANDLE_INFO_SIZE                             (9)
#define TA_REVISION_NUMBER_SIZE                         (8)
#define TA_NV_REMAIN_MODE_OUTPUT_LENGTH                 (4)
#define TA_HANDLE_VALID_OUTPUT_LENGTH                   (1)
#define TA_FAILURE_LOG_SIZE                             (64)
#define TA_ROM_ID_SIZE                                  (2)
#define TA_CRL_HANDLE_SIZE                              (2)
#define TA_SERIAL_NUMBER_SIZE                           (8)

/* AES Command */
#define TA_OPCODE_AES                                   0x1A
#define TA_AES_ACTION_MASK                              0x03
#define TA_AES_ACTION_KEY_LOAD                          0x00
#define TA_AES_ACTION_ENCRYPT                           0x01
#define TA_AES_ACTION_DECRYPT                           0x02
#define TA_AES_MODE_MASK                                0x1C
#define TA_AES_MODE_ECB                                 0x04
#define TA_AES_MODE_GCM                                 0x08
#define TA_AES_UNLOAD                                   0x40
#define TA_AES_RAND_IV                                  0x80
#define TA_AES_TLS_IV                                   0x80
#define TA_AES_ECB_TEXT_SIZE                            16
#define TA_AES_GCM_IV_LENGTH                            12
#define TA_AES_GCM_TAG_LENGTH                           16
#define TA_AES_DATA_SIZE                                16                    //!< size of AES encrypt/decrypt data
#define TA_AES_GCM_MAX_DATA_SIZE                        996                   //!< Maximum size of AES GCM data

/* Authorization Command */
#define TA_OPCODE_AUTHORIZE                             0x16
#define TA_AUTH_STATE_IDLE                              (0)
#define TA_AUTH_STATE_CMAC                              (1)
#define TA_AUTH_STATE_HMAC                              (2)
#define TA_AUTH_STATE_GCM                               (3)
#define TA_AUTH_STATE_INITIATOR_RAND                    (0x10)
#define TA_AUTH_STATE_RESPONDER_RAND                    (0x20)

#define TA_AUTH_MODE_GENERATE_NONCE                     (0)
#define TA_AUTH_MODE_SETUP_SESSION                      (1)
#define TA_AUTH_MODE_EXECUTE_NESTED                     (2)
#define TA_AUTH_MODE_CLOSE_SESSION                      (3)
#define TA_AUTH_MODE_WITHTIN_SEQ                        (0x80)

#define TA_AUTH_GENERATE_OPT_DIR_SHIFT                  (0)
/* Mask to find whether Target Device is Initiator or Responder */
#define TA_AUTH_GENERATE_OPT_DIR_MASK                   (0x1 << TA_AUTH_GENERATE_OPT_DIR_SHIFT)
#define TA_AUTH_GENERATE_OPT_NONCE_SRC_SHIFT            (1)
#define TA_AUTH_GENERATE_OPT_NONCE_SRC_MASK             (0x1 << TA_AUTH_GENERATE_OPT_NONCE_SRC_SHIFT)
#define TA_AUTH_GENERATE_OPT_RANDOM_SHIFT               (2)
#define TA_AUTH_GENERATE_OPT_RANDOM_MASK                (0x1 << TA_AUTH_GENERATE_OPT_RANDOM_SHIFT)

#define TA_AUTH_ALG_ID_GCM                              TA_ALG_ID(TA_KEY_TYPE_AES128, TA_ALG_MODE_AES128_GCM)
#define TA_AUTH_ALG_ID_CMAC                             TA_ALG_ID(TA_KEY_TYPE_AES128, TA_ALG_MODE_AES128_CMAC)
#define TA_AUTH_ALG_ID_HMAC                             TA_ALG_ID(TA_KEY_TYPE_HMAC, TA_ALG_MODE_SHA256_HMAC)

/* Counter Command */
#define TA_OPCODE_COUNTER                               0x0E
#define TA_COUNTER_MODE_MASK                            0x01
#define TA_COUNTER_MODE_READ                            0x00
#define TA_COUNTER_MODE_INCREMENT                       0x01

/* Create Command */
#define TA_OPCODE_CREATE                                0x06
#define TA_CREATE_MODE_EPHEMERAL_ELEMENT                0x01
#define TA_CREATE_MODE_HANDLE_TYPE_MASK                 0x02
#define TA_CREATE_MODE_HANDLE_BY_VEGA                   0x02
#define TA_CREATE_MODE_HANDLE_BY_HOST                   0x00
#define TA_CREATE_DETAILS_EXECUTE_KDF                   0x0010
#define TA_CREATE_DETAILS_VOLATILE_DESTINATION          0x0040
#define TA_CREATE_DETAILS_HMAC_KEY_LENGTH(x)            (x << 8)
#define TA_CREATE_DETAILS_HMAC_MIN_LENGTH               16
#define TA_CREATE_DETAILS_HMAC_MAX_LENGTH               64
#define TA_CREATE_CONFIGURATION_SIZE                    8
#define TA_CREATE_RESPONSE_SIZE_WITH_HANDLE             (ATCA_CMD_PARSE_MIN_LENGTH + 2)

/* Delete Command */
#define TA_OPCODE_DELETE                                0x13
#define TA_DELETE_MODE_HANDLE                           0x00
#define TA_DELETE_MODE_CHIP_ERASE                       0x01

/* Dev Update Command */
#define TA_OPCODE_DEVUPDATE                             0x0B
#define TA_DEV_UPDATE_MAX_BLOCK_SIZE                    1024UL
#define TA_DEV_UPDATE_MAX_BLOCK                         255UL
#define TA_DEV_UPDATE_MAX_IMAGE_SIZE                    (TA_DEV_UPDATE_MAX_BLOCK * TA_DEV_UPDATE_MAX_BLOCK_SIZE)

/* ECDH Command */
#define TA_OPCODE_ECDH                                  0x11
#define TA_ECDH_X_MODE                                  0x00
#define TA_ECDH_X_AND_Y_MODE                            0x02
#define TA_ECDH_ECCP224_PMS_SIZE                        28
#define TA_ECDH_ECCP224_XY_PMS_SIZE                     56
#define TA_ECDH_ECCP256_PMS_SIZE                        32
#define TA_ECDH_ECCP256_XY_PMS_SIZE                     64
#define TA_ECDH_ECCP384_PMS_SIZE                        48
#define TA_ECDH_ECCP384_XY_PMS_SIZE                     96

/* Export Command */
#define TA_OPCODE_EXPORT                                0x05
#define TA_EXPORT_BLOB_MIN_LEN                          53
#define TA_EXPORT_BLOB_MAX_LEN                          584

/* FC Config command */
#define TA_OPCODE_FCCONFIG                              0x02
#define TA_FCCONFIG_SHA256_MODE                         0x01
#define TA_FCCONFIG_MAC_ALL_KEYS_MODE                   0x00
#define TA_FCCONFIG_MAC_ATLEAST_ONE_KEY_MODE            0x80

/* Import command */
#define TA_OPCODE_IMPORT                                0x04
#define TA_IMPORT_MODE_LINKS_WITH_EXPORTED_BLOB         0x00
#define TA_IMPORT_MODE_LINKS_WITH_TARGET_HANDLE         0x01
#define TA_IMPORT_BLOB_MIN_LEN                          53
#define TA_IMPORT_BLOB_MAX_LEN                          584

/* Info Command */
#define TA_OPCODE_INFO                                  0x00
#define TA_INFO_MODE_REV                                0x00
#define TA_INFO_MODE_NV_REMAIN                          0x01
#define TA_INFO_MODE_HANDLE_VALID                       0x02
#define TA_INFO_MODE_HANDLE_INFO                        0x03
#define TA_INFO_MODE_HANDLE_ARRAY                       0x04
#define TA_INFO_MODE_AUTH_STATUS                        0x05
#define TA_INFO_MODE_VOLATILE_REG_STATUS                0x06
#define TA_INFO_MODE_DEDICATED_MEMORY                   0x07
#define TA_INFO_MODE_CHIP_STATUS                        0x08
#define TA_INFO_MODE_FAILURE_LOG                        0x09
#define TA_INFO_MODE_ROM_ID                             0x0A
#define TA_INFO_MODE_CRL_HANDLE                         0x0B

#define TA_HANDLE_INFO_CLASS_SHIFT                      (0)
#define TA_HANDLE_INFO_CLASS_MASK                       (0x07 << TA_HANDLE_INFO_CLASS_SHIFT)
#define TA_HANDLE_INFO_KEY_TYPE_SHIFT                   (3)
#define TA_HANDLE_INFO_KEY_TYPE_MASK                    (0x0F << TA_HANDLE_INFO_KEY_TYPE_SHIFT)
#define TA_HANDLE_INFO_ALG_MODE_SHIFT                   (7)
#define TA_HANDLE_INFO_ALG_MODE_MASK                    (0x01 << TA_HANDLE_INFO_ALG_MODE_SHIFT)

/* KDF Command */
#define TA_OPCODE_KDF                                   0x17
#define TA_KDF_HKDF_MODE                                0x00
#define TA_KDF_HMAC_MODE                                0x01
#define TA_KDF_PRF_MODE                                 0x02
#define TA_KDF_SHA256_MODE                              0x03
#define TA_KDF_AESA_MODE                                0x04
#define TA_KDF_AESB_MODE                                0x05
#define TA_KDF_HKDF_OUT_LEN_MIN_SIZE                    16
#define TA_KDF_HKDF_OUT_LEN_MAX_SIZE                    128
#define TA_KDF_HKDF_SALT_MIN_LEN                        1
#define TA_KDF_HKDF_SALT_MAX_LEN                        64
#define TA_KDF_HKDF_INFO_MAX_LEN                        256
#define TA_KDF_PRF_INPUT_MAX_LEN                        256
#define TA_KDF_AES_A_MESSAGE_LEN                        32
#define TA_KDF_AES_B_INPUT_LEN                          16
#define TA_KDF_AES_RESULT_LEN                           16
#define TA_KDF_SHA_OUT_LEN_MIN_SIZE                     16
#define TA_KDF_SHA_OUT_LEN_MAX_SIZE                     32
#define TA_KDF_SHA_PAD_LENGTH_MAX                       256
#define TA_KDF_HMAC_LABEL_MAX_LEN                       256
#define TA_KDF_HMAC_CONTEXT_MAX_LEN                     256

/* Keygen Command */
#define TA_OPCODE_KEYGEN                                0x12
#define TA_KEYGEN_MODE_NEWKEY                           0x00
#define TA_KEYGEN_MODE_PUBKEY                           0x01
#define TA_ECC256_PUB_KEY_SIZE                          64
#define TA_ECC224_PUB_KEY_SIZE                          56
#define TA_ECC384_PUB_KEY_SIZE                          96

/* Lock Command */
#define TA_OPCODE_LOCK                                  0x0D
#define TA_LOCK_CONFIG_WITHOUT_CRC                      0x00
#define TA_LOCK_CONFIG_WITH_CRC                         0x01
#define TA_LOCK_SHARED_ELEMENT                          0x03
#define TA_LOCK_SETUP_LOCK                              0x04
#define TA_LOCK_ONE_TIME_LOCK                           0x05

/* MAC Command */
#define TA_OPCODE_MAC                                   0x0A
#define TA_MAC_COMMAND_CMAC_SIZE                        16
#define TA_MAC_COMMAND_HMAC_SIZE                        32
#define TA_MAC_MAX_MSG_LENGTH                           1022
#define TA_MAC_MODE                                     0x00

/* Manage Certificate Command */
#define TA_OPCODE_MANAGECERT                            0x0C
#define TA_MAX_CERTIFICATE_SIZE                         (2048)
#define TA_MAX_INPUT_CERTIFICATE_SIZE                   (1020)
#define TA_CERTIFICATE_STORED                           0x00
#define TA_IO_COMPLETE_CERT                             0x00
#define TA_IO_CERT_FIRST                                0x01
#define TA_IO_CERT_CONTINUE                             0x10
#define TA_IO_CERT_FINISH                               0x11
#define TA_CERT_VERIFY_ONLY                             0xFFFF

/* Power Command */
#define TA_OPCODE_POWER                                 0x03
#define TA_POWER_MODE_SLEEP                             0x01
#define TA_POWER_MODE_REBOOT                            0x02
#define TA_POWER_SOFT_REBOOT_CONFIG                     0x01

/* Random Command */
#define TA_OPCODE_RANDOM                                0x09
#define TA_RANDOM_STIR_DATA_LENGTH                      16
#define TA_RANDOM_MIN_RESP_LENGTH                       (1 * 32)
#define TA_RANDOM_MAX_RESP_LENGTH                       (32 * 32)
#define TA_RANDOM_MODE                                  0x00

/* Read Command */
#define TA_OPCODE_READ                                  0x07
#define TA_READ_MIN_DATA_LENGTH                         1
#define TA_READ_MAX_DATA_LENGTH                         1024
#define TA_READ_ENTIRE_ELEMENT                          0x01
#define TA_READ_PARTIAL_ELEMENT                         0x00
#define TA_READ_FOR_TRANSFER                            0x80
#define TA_READ_TRANSFER_MAC_SIZE                       16

/* RSA Encrypt Command */
#define TA_OPCODE_RSAENC                                0x18
#define TA_RSAENC_ENCRYPT                               0x01
#define TA_RSAENC_DECRYPT                               0x00
#define TA_RSAENC_PLAIN_TEXT_MIN_SIZE                   1
#define TA_RSAENC_PLAIN_TEXT_MAX_SIZE                   62
#define TA_RSAENC_CIPHER_TEXT_SIZE                      128
#define TA_RSAENC_KEY_SIZE                              1024
#define TA_RSAENC_PUB_KEY_SIZE                          128

/* Secure Boot command */
#define TA_OPCODE_SECUREBOOT                            0x01
#define TA_SECUREBOOT_MODE_FULL_ASYMMETRIC              0x01
#define TA_SECUREBOOT_MODE_FULLSTORE_PRESET             0x10
#define TA_SECUREBOOT_MODE_FULLSTORE_UPDATE             0x11
#define TA_SECUREBOOT_MODE_FULLSTORE_BOOT               0x12
#define TA_SECUREBOOT_MODE_PARTIAL_PRESET               0x20
#define TA_SECUREBOOT_MODE_PARTIAL_SETUP                0x21
#define TA_SECUREBOOT_MODE_PARTIAL_CODE                 0x22
#define TA_SECUREBOOT_MODE_PARTIAL_FINAL                0x23
#define TA_SECUREBOOT_MODE_PARTIAL_COMPLETE             0x24
#define TA_SECUREBOOT_MODE_PARTIAL_ADDRESS              0x25
#define TA_SECUREBOOT_MODE_PARTIAL_BOOT                 0x26
#define TA_SECUREBOOT_MODE_COMMON_LOCK                  0x30
#define TA_SECUREBOOT_MODE_PREBOOT_PRESET               0x40
#define TA_SECUREBOOT_MODE_PREBOOT_UPDATE               0x41
#define TA_SECUREBOOT_MODE_PREBOOT_BOOT                 0x42
#define TA_SECUREBOOT_PARTIAL_CODE_SIZE_MAX             64
#define TA_SECUREBOOT_PARTIAL_ADDRESS_BEGIN_SIZE        4
#define TA_SECUREBOOT_PARTIAL_ADDRESS_END_SIZE          4
#define TA_SECUREBOOT_CONFIG_MODE_MASK                  0x11
#define TA_SECUREBOOT_CONFIG_FULL_ASYMM_MODE            0x01
#define TA_SECUREBOOT_CONFIG_FULL_STORE_MODE            0x10
#define TA_SECUREBOOT_CONFIG_PARTIAL_MODE               0x11
#define TA_SECUREBOOT_CONFIG_PREBOOT_ENABLE_MASK        0x80

/* Selftest Command */
#define TA_OPCODE_SELFTEST                              0x14
#define TA_SELFTEST_MODE_USEMAP                         0x00
#define TA_SELFTEST_MODE_USECONFIG                      0x01

#define SELFTEST_MAP_ALL                            ((uint32_t)0x0002fbef)
#define SELFTEST_MAP_FC_AES                         ((uint32_t)(0x01 << 0))
#define SELFTEST_MAP_FC_SHA                         ((uint32_t)(0x01 << 1))
#define SELFTEST_MAP_CMAC                           ((uint32_t)(0x01 << 2))
#define SELFTEST_MAP_GCM                            ((uint32_t)(0x01 << 3))
#define SELFTEST_MAP_SHA                            ((uint32_t)(0x01 << 5))
#define SELFTEST_MAP_PRF                            ((uint32_t)(0x01 << 6))
#define SELFTEST_MAP_HKDF                           ((uint32_t)(0x01 << 7))
#define SELFTEST_MAP_NRBG                           ((uint32_t)(0x01 << 8))
#define SELFTEST_MAP_DRBG                           ((uint32_t)(0x01 << 9))
#define SELFTEST_MAP_ECDSA                          ((uint32_t)(0x01 << 11))
#define SELFTEST_MAP_ECDH                           ((uint32_t)(0x01 << 12))
#define SELFTEST_MAP_RSA                            ((uint32_t)(0x01 << 13))
#define SELFTEST_MAP_ECBD                           ((uint32_t)(0x01 << 14))
#define SELFTEST_MAP_KEY                            ((uint32_t)(0x01 << 15))
#define SELFTEST_MAP_ROM                            ((uint32_t)(0x01 << 17))


/* SHA Command */
#define TA_OPCODE_SHA                                   0x19
#define TA_SHA_MODE_START                               0x00
#define TA_SHA_MODE_UPDATE                              0x01
#define TA_SHA_MODE_END                                 0x02
#define TA_SHA_MODE_ENTIRE_MSG                          0x03
#define TA_SHA_MODE_DIGEST_TO_CONTEXT                   0x80
#define TA_SHA_UPDATE_BLOCK_SIZE                        1024
#define TA_SHA_MAX_MSG_LEN                              1024
#define TA_SHA256_DIGEST_SIZE                           32

/* Sign Command */
#define TA_OPCODE_SIGN                                  0x0F
#define TA_SIGN_MODE_INTERNAL_MSG                       0x20
#define TA_SIGN_MODE_EXTERNAL_MSG                       0x00
#define TA_SIGN_P256_MSG_SIZE                           32
#define TA_SIGN_P256_SIG_SIZE                           64
#define TA_SIGN_P224_MSG_SIZE                           28
#define TA_SIGN_P224_SIG_SIZE                           56
#define TA_SIGN_P384_MSG_SIZE                           48
#define TA_SIGN_P384_SIG_SIZE                           96
#define TA_SIGN_OTHER_KEY_TYPE_MSG_SIZE                 32
#define TA_SIGN_RSA2048_SIG_SIZE                        256
#define TA_SIGN_RSA3072_SIG_SIZE                        384

/* Verify Command */
#define TA_OPCODE_VERIFY                                0x10
#define TA_VERIFY_P256_MSG_SIZE                         32
#define TA_VERIFY_P224_MSG_SIZE                         28
#define TA_VERIFY_P384_MSG_SIZE                         48
#define TA_VERIFY_OTHER_KEY_TYPE_MSG_SIZE               32
#define TA_VERIFY_POINT_EXPANSION                       0x80
#define TA_VERIFY_X_VAL_MAX_SIZE                        32
#define TA_VERIFY_Y_VAL_MAX_SIZE                        32
#define TA_VERIFY_Y_IS_EVEN                             2
#define TA_VERIFY_Y_IS_ODD                              3

/* Write Command */
#define TA_OPCODE_WRITE                                 0x08
#define TA_WRITE_MIN_DATA_LENGTH                        1
#define TA_WRITE_MAX_DATA_LENGTH                        1024
#define TA_WRITE_MAX_PARTIAL_DATA_LEN                   1020
#define TA_WRITE_ENTIRE_ELEMENT                         0x01
#define TA_WRITE_PARTIAL_ELEMENT                        0x00
#define TA_WRITE_TRANSPORT_KEY                          0x02
#define TA_WRITE_TRANSFER_KEY_VOL_SHARED                0x00
#define TA_WRITE_FOR_TRANSFER                           0x81
#define TA_WRITE_TRANSFER_MAC_SIZE                      16
#define TA_WRITE_PACKET_OPCODE_MODE_PARAM               6

/* Sequence Command */
#define TA_OPCODE_SEQUENCE                              0x15
#define TA_SHARE_SEQ_NONCE_LEN                          16
#define TA_CREATE_DETAILS_EPHEMERAL_PRIV_AND_KDF_REQ    0x10
#define TA_SHARE_KEY_LOCAL_FIRST_MASK                   0x0100
#define TA_SHARE_KEY_START_SEQ                          0x04
#define TA_SHARE_KEY_CONTINUE_SEQ                       0x08
#define TA_SHARE_KEY_TERMINATE_SEQ                      0x0C
#define TA_SHARE_KEY_SEQ_LABEL                          "Share_Key"

#ifndef ATCA_NO_PRAGMA_PACK
#pragma pack(push, 1)
#define ATCA_PACKED
#else
#define ATCA_PACKED     __attribute__ ((packed))
#endif

/* TA_ElementAttributes contains data element attributes of the handle which is of 8 byte */
typedef struct
{
    uint8_t  element_CKA;     //!< contains class, key_type & Algorithm mode
    uint16_t property;        //!< properties of the element
    uint8_t  usage_key;       //!< usage key
    uint8_t  write_key;       //!< write key
    uint8_t  read_key;        //!< read key
    uint8_t  permission;      //!< permission of the element usage|write|read|delete perm
    uint8_t  byte7_settings;  //!< Byte 7 attributes use_count|exportable|lockable|access_limit
} ATCA_PACKED ta_element_attributes_t;

#ifndef ATCA_NO_PRAGMA_PACK
#pragma pack(pop)
#endif

#ifdef __cplusplus
}
#endif

#endif
