/**
 * \file
 * \brief Basic Helper functions for creating Handle Attributes in the Trust Anchor Devices
 *
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include <stdint.h>

#include "cryptoauthlib.h"
#include "talib_defines.h"
#include "talib_basic.h"

/** \brief TA API - Helper function to create the Handle attributes for Public key.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[out] element_attributes     Pointer to store the 8 byte Handle attributes.
 *  \param[in]  key_type               The key type for the Handle.
 *  \param[in]  alg_mode               The algorithm mode for the key_type and is applicable to rsa key only.
 *  \param[in]  secure_boot_enable     Mode for the Secure boot functions.
 *  \param[in]  root_key_enable        Mode for the Public key functions.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_init_public_key(ta_element_attributes_t *element_attributes,
                                         const uint8_t key_type, const uint8_t alg_mode,
                                         const uint8_t secure_boot_enable, const uint8_t root_key_enable)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        memset(element_attributes, 0, sizeof(ta_element_attributes_t));

        element_attributes->element_CKA = TA_CLASS_PUBLIC_KEY | (uint8_t)(key_type << TA_HANDLE_INFO_KEY_TYPE_SHIFT) | (uint8_t)(alg_mode << TA_HANDLE_INFO_ALG_MODE_SHIFT);
        element_attributes->property = (uint16_t)(secure_boot_enable << TA_PROP_SECURE_BOOT_SHIFT) | (uint16_t)(root_key_enable << TA_PROP_ROOT_SHIFT);
        element_attributes->permission = TA_PERM_ALL_ALWAYS;
        element_attributes->byte7_settings = TA_PERMANENTLY_LOCKABLE_MASK;

        status = ATCA_SUCCESS;
    }
    return status;
}

/** \brief TA API - Helper function to create the Handle attributes for Private key.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[out] element_attributes     Pointer to store the 8 byte Handle attributes.
 *  \param[in]  key_type               The key type for the Handle.
 *  \param[in]  alg_mode               The algorithm mode for the key_type and is applicable to rsa key only.
 *  \param[in]  sign_use               Modes for signature generation.
 *  \param[in]  key_agreement_use      Modes for Key agreement.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */

ATCA_STATUS talib_handle_init_private_key(ta_element_attributes_t *element_attributes,
                                          const uint8_t key_type, const uint8_t alg_mode,
                                          const uint8_t sign_use, const uint8_t key_agreement_use)

{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        memset(element_attributes, 0, sizeof(ta_element_attributes_t));
        element_attributes->element_CKA = TA_CLASS_PRIVATE_KEY | (uint8_t)(key_type << TA_HANDLE_INFO_KEY_TYPE_SHIFT) | (uint8_t)(alg_mode << TA_HANDLE_INFO_ALG_MODE_SHIFT);
        element_attributes->property = (uint16_t)(sign_use << TA_PROP_SIGN_USE_SHIFT) | (uint16_t)(key_agreement_use << TA_PROP_KEY_AGREEMENT_SHIFT) | TA_PROP_EXECUTE_ONLY_KEY_GEN_MASK;
        element_attributes->permission = TA_PERM_USAGE(TA_PERM_ALWAYS) | TA_PERM_DELETE(TA_PERM_ALWAYS);
        element_attributes->byte7_settings = TA_PERMANENTLY_LOCKABLE_MASK;

        status = ATCA_SUCCESS;
    }
    return status;
}



/** \brief TA API - Helper function to create the Handle attributes for Symmetric key.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[out] element_attributes     Pointer to store the 8 byte Handle attributes.
 *  \param[in]  key_type               The key type for the Handle.
 *  \param[in]  sym_usage              Modes for MAC/ENC/KDF operations.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_init_symmetric_key(ta_element_attributes_t *element_attributes,
                                            const uint8_t key_type, const uint8_t sym_usage)

{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        memset(element_attributes, 0, sizeof(ta_element_attributes_t));

        element_attributes->element_CKA = TA_CLASS_SYMMETRIC_KEY | (uint8_t)(key_type << TA_HANDLE_INFO_KEY_TYPE_SHIFT);

        element_attributes->property = (uint16_t)(sym_usage << TA_PROP_SYM_USAGE_SHIFT);
        element_attributes->permission = TA_PERM_ALL_ALWAYS;
        element_attributes->byte7_settings = TA_PERMANENTLY_LOCKABLE_MASK;

        status = ATCA_SUCCESS;
    }
    return status;
}


/** \brief TA API - Helper function to create the Handle attributes for Symmetric key.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[out] element_attributes     Pointer to store the 8 byte Handle attributes.
 *  \param[in]  data_size              The size of the data element and the maximum size is 2048.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_init_data(ta_element_attributes_t *element_attributes,
                                   const uint16_t           data_size)

{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes && TA_ELEMENT_MAX_DATA_SIZE > data_size)
    {
        memset(element_attributes, 0, sizeof(ta_element_attributes_t));

        element_attributes->element_CKA = TA_CLASS_DATA;
        element_attributes->property = data_size;
        element_attributes->permission = TA_PERM_WRITE(TA_PERM_ALWAYS) | TA_PERM_READ(TA_PERM_ALWAYS) | TA_PERM_DELETE(TA_PERM_ALWAYS);
        element_attributes->byte7_settings = TA_PERMANENTLY_LOCKABLE_MASK;

        status = ATCA_SUCCESS;
    }
    return status;
}


/** \brief TA API - Helper function to create the Handle attributes for Extracted Certificates.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[out] element_attributes          Pointer to store the 8 byte Handle attributes.
 *  \param[in]  key_type                    The key type the extracted cert.
 *  \param[in]  alg_mode                    The algorithm mode for the extracted cert and is applicable to rsa key only.
 *  \param[in]  secure_boot_use             Modes for the Secure boot use.
 *  \param[in]  intermediate_CA_enable      Mode for the extracted cert use as parent CA or not.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_init_extracated_certificate(ta_element_attributes_t *element_attributes,
                                                     const uint8_t key_type, const uint8_t alg_mode, const uint8_t secure_boot_use, const uint8_t intermediate_CA_enable)

{
    uint8_t ca_parent = 0;
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        memset(element_attributes, 0, sizeof(ta_element_attributes_t));

        if ((TA_CERT_PROP_CA_OK_SHIFT & intermediate_CA_enable) == TA_PROP_CERT_CA_OK)
        {
            ca_parent = TA_PROP_CA_PARENT_OK;
        }

        element_attributes->element_CKA = TA_CLASS_EXTRACTED_CERT | (uint8_t)(key_type << TA_HANDLE_INFO_KEY_TYPE_SHIFT)
                                          | (uint8_t)(alg_mode << TA_HANDLE_INFO_ALG_MODE_SHIFT);
        element_attributes->property = (uint16_t)(secure_boot_use << TA_CERT_PROP_SEC_BOOT_SHIFT)
                                       | (uint16_t)(intermediate_CA_enable << TA_CERT_PROP_CA_OK_SHIFT)
                                       | (uint16_t)(ca_parent << TA_CERT_PROP_CA_PARENT_SHIFT);
        element_attributes->permission = TA_PERM_ALL_ALWAYS;
        element_attributes->byte7_settings = TA_PERMANENTLY_LOCKABLE_MASK;

        status = ATCA_SUCCESS;
    }
    return status;
}


/** \brief TA API - Helper function to create the Handle attributes for Fast Crypto key group.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[out] element_attributes      Pointer to store the 8 byte Handle attributes.
 *  \param[in]  key_type                The key type for the handle. Applicable only for symmetric key.
 *  \param[in]  no_of_keys              No of key space in the handle.
 *  \param[in]  handles                 Mode for single key or for a group of keys space.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_init_fast_crypto_key_group(ta_element_attributes_t * element_attributes,
                                                    const uint8_t key_type, const uint8_t no_of_keys,
                                                    const uint8_t handles)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        memset(element_attributes, 0, sizeof(ta_element_attributes_t));

        element_attributes->element_CKA = TA_CLASS_FAST_CRYPTO_KEY_GROUP | (uint8_t)(key_type << TA_HANDLE_INFO_KEY_TYPE_SHIFT);
        element_attributes->property = (uint16_t)(no_of_keys << TA_PROP_FCE_NUM_KEYS_SHIFT) & TA_PROP_FCE_NUM_KEYS_MASK;
        element_attributes->property |= (uint16_t)(handles << TA_PROP_FCE_HANDLES_SHIFT) & TA_PROP_FCE_HANDLES_MASK;
        element_attributes->permission = TA_PERM_ALL_ALWAYS;
        element_attributes->byte7_settings = TA_PERMANENTLY_LOCKABLE_MASK;

        status = ATCA_SUCCESS;
    }
    return status;
}


/** \brief TA API - Helper function to create the permission for the handle.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[in,out] element_attributes    Pointer the handle attributes.
 *  \param[in]  usage_perm              Usage permissions for the handle.
 *  \param[in]  write_perm              Write permissions for the handle.
 *  \param[in]  read_perm               Read permissions for the handle.
 *  \param[in]  delete_perm             Delete permissions for the handle..
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_set_permissions(ta_element_attributes_t *element_attributes, const uint8_t usage_perm,
                                         const uint8_t write_perm, const uint8_t read_perm, const uint8_t delete_perm)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        element_attributes->permission = TA_PERM_USAGE(usage_perm) | TA_PERM_WRITE(write_perm)
                                         | TA_PERM_READ(read_perm) | TA_PERM_DELETE(delete_perm);

        status = ATCA_SUCCESS;
    }
    return status;
}

/** \brief TA API - Helper function to create the permission for the handle.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[in,out] element_attributes    Pointer the handle attributes.
 *  \param[in]  usage_perm              Usage permissions for the handle.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_set_usage_permission(ta_element_attributes_t* element_attributes, const uint8_t usage_perm)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        element_attributes->permission &= ~TA_PERM_USAGE_MASK;
        element_attributes->permission |= TA_PERM_USAGE(usage_perm);

        status = ATCA_SUCCESS;
    }
    return status;
}

/** \brief TA API - Helper function to create the permission for the handle.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[in,out] element_attributes    Pointer the handle attributes.
 *  \param[in]  write_perm              Usage permissions for the handle.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_set_write_permission(ta_element_attributes_t* element_attributes, const uint8_t write_perm)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        element_attributes->permission &= ~TA_PERM_WRITE_MASK;
        element_attributes->permission |= TA_PERM_WRITE(write_perm);

        status = ATCA_SUCCESS;
    }
    return status;
}

/** \brief TA API - Helper function to create the permission for the handle.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[in,out] element_attributes    Pointer the handle attributes.
 *  \param[in]  read_perm              Usage permissions for the handle.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_set_read_permission(ta_element_attributes_t* element_attributes, const uint8_t read_perm)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        element_attributes->permission &= ~TA_PERM_READ_MASK;
        element_attributes->permission |= TA_PERM_READ(read_perm);

        status = ATCA_SUCCESS;
    }
    return status;
}

/** \brief TA API - Helper function to create the permission for the handle.
 *                  This function will not create the handle and it is only a helper function for Create command.
 *
 *  \param[in,out] element_attributes    Pointer the handle attributes.
 *  \param[in]  delete_perm              Usage permissions for the handle.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_handle_set_delete_permission(ta_element_attributes_t* element_attributes, const uint8_t delete_perm)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (element_attributes)
    {
        element_attributes->permission &= ~TA_PERM_DELETE_MASK;
        element_attributes->permission |= TA_PERM_DELETE(delete_perm);

        status = ATCA_SUCCESS;
    }
    return status;
}
