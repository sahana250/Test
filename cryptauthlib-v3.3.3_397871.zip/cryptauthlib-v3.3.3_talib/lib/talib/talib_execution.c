/**
 * \file
 * \brief Implements an execution handler that executes a given command on a
 *        device and returns the results.
 *
 * This implementation wraps Polling and No polling (simple wait) schemes into
 * a single method and use it across the library. Polling is used by default,
 * however, by defining the ATCA_NO_POLL symbol the code will instead wait an
 * estimated max execution time before requesting the result.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"
#include "talib_crc.h"
#include "talib_fce.h"


#ifndef ATCA_POLLING_RSA_KEY_GEN_MAX_TIME_MSEC
#define ATCA_POLLING_RSA_KEY_GEN_MAX_TIME_MSEC       40000
#endif

#ifndef ATCA_TA_WAKEUP_TIME_MSEC
#define ATCA_TA_WAKEUP_TIME_MSEC   5
#endif

/** \brief Send data to the device using the configured hal
 *
 *  \return ATCA_SUCCESS if successful otherwise an error
 */
ATCA_STATUS talib_execute_send(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t    device_address,  /**< [in] The device address if the hal requires it */
    uint8_t*   txdata,          /**< [in] Data to transmit */
    uint16_t   txlength         /**< [in] Length of the transmission */
    )
{
    ATCA_STATUS status = ATCA_COMM_FAIL;

    if (!txdata || !txlength)
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

#ifdef ATCA_HAL_LEGACY_API
    status = atsend(device->mIface, txdata[0], (uint8_t*)txdata, txlength);
#else
    if (atca_iface_is_kit(&device->mIface))
    {
        status = atsend(&device->mIface, txdata[0], (uint8_t*)txdata, (int)txlength);
    }
    else
    {
        status = atcontrol(&device->mIface, ATCA_HAL_CONTROL_SELECT, NULL, 0);
        if (ATCA_UNIMPLEMENTED == status || ATCA_SUCCESS == status)
        {
            /* Send the command packet to the device */
            status = atsend(&device->mIface, device_address, (uint8_t*)txdata, (int)txlength);
        }
        (void)atcontrol(&device->mIface, ATCA_HAL_CONTROL_DESELECT, NULL, 0);
    }
#endif

    return status;
}

#ifndef ATCA_HAL_LEGACY_API
/** \brief Receive raw bytes from the device
 *
 *  \return ATCA_SUCCESS if successful otherwise an error
 */
ATCA_STATUS talib_execute_receive(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t    device_address,  /**< [in] The device address if the hal requires it */
    uint8_t    word_address,    /**< [in] Command byte (word address) for the transfer */
    uint8_t*   rxdata,          /**< [out] Receive buffer */
    uint16_t*  rxlength         /**< [in] Length of the receive buffer, [out] bytes received */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    int retries;

    if (rxlength && rxdata)
    {
        retries = device->mIface.mIfaceCFG->rx_retries + 1;
        do
        {
            (void)atcontrol(&device->mIface, ATCA_HAL_CONTROL_SELECT, NULL, 0);

            status = atsend(&device->mIface, device_address, &word_address, sizeof(word_address));

            if (ATCA_SUCCESS == status)
            {
                status = atreceive(&device->mIface, device_address, rxdata, rxlength);
            }

            (void)atcontrol(&device->mIface, ATCA_HAL_CONTROL_DESELECT, NULL, 0);
        }
        while (retries-- > 0 && status != ATCA_SUCCESS);
    }

    return status;
}

/** \brief Receive a command response from the device
 *
 *  \return ATCA_SUCCESS if successful otherwise an error
 */
ATCA_STATUS talib_execute_receive_cmd(
    ATCADevice device,          /**< [in] Device context pointer */
    uint8_t    device_address,  /**< [in] The device address if the hal requires it */
    uint8_t*   rxdata,          /**< [out] Receive buffer */
    uint16_t*  rxlength         /**< [in] Length of the receive buffer, [out] bytes received */
    )
{
    ATCA_STATUS status = ATCA_COMM_FAIL;
    uint16_t read_length = 2;
    uint8_t word_address = ATCA_MAIN_PROCESSOR_RD_CMD;
    int retries;

    if ((NULL == rxlength) || (NULL == rxdata))
    {
        return ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer encountered");
    }

    do
    {
        (void)atcontrol(&device->mIface, ATCA_HAL_CONTROL_SELECT, NULL, 0);

        /*Send Word address to device...*/
        retries = device->mIface.mIfaceCFG->rx_retries + 1;
        while (retries-- > 0 && status != ATCA_SUCCESS)
        {
            status = atsend(&device->mIface, device_address, &word_address, sizeof(word_address));
        }
        if (ATCA_SUCCESS != status)
        {
            ATCA_TRACE(status, "atsend - failed");
            break;
        }

        /* Read length bytes to know number of bytes to read */
        status = atreceive(&device->mIface, device_address, rxdata, &read_length);
        if (ATCA_SUCCESS != status)
        {
            ATCA_TRACE(status, "atreceive - failed");
            break;
        }

        /*Calculate bytes to read based on device response*/
        read_length =  rxdata[1];
        read_length += (uint16_t)(rxdata[0]) << 8;

        if (read_length > *rxlength)
        {
            status = ATCA_TRACE(ATCA_SMALL_BUFFER, "rxdata is small buffer");
            break;
        }

        if (read_length < 4)
        {
            status = ATCA_TRACE(ATCA_RX_FAIL, "packet size is invalid");
            break;
        }

        /* Read given length bytes from device */
        read_length -= 2;
        status = atreceive(&device->mIface, device_address, &rxdata[2], &read_length);

        if (ATCA_SUCCESS != status)
        {
            status = ATCA_TRACE(status, "atreceive - failed");
            break;
        }

        read_length += 2;

        *rxlength = read_length;
    }
    while (0);

    (void)atcontrol(&device->mIface, ATCA_HAL_CONTROL_DESELECT, NULL, 0);

    return status;
}
#endif

/** \brief TA API - Wakes up device, sends the packet, waits for command completion,
 *         receives response, and puts the device into the idle state.
 *
 * \param[in,out] packet  As input, the packet to be sent. As output, the
 *                       data buffer in the packet structure will contain the
 *                       response.
 * \param[in]    device  CryptoAuthentication device to send the command to.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_execute_command_base(ATCA_TA_CmdPacket* packet, ATCADevice device)
{
    ATCA_STATUS status;
    uint32_t execution_or_wait_time;
    int32_t max_delay_count;
    uint16_t length = ATCA_UINT16_BE_TO_HOST(packet->length);
    uint8_t csr_value;
    uint8_t device_address = atcab_get_device_address(device);

    do
    {
        execution_or_wait_time = ATCA_POLLING_INIT_TIME_MSEC;
        // Set maximum delay for key gen command to execute (for RSA Key gen it takes 20sec typically)
        if ((TA_OPCODE_KEYGEN == packet->opcode) || ((TA_OPCODE_AUTHORIZE == packet->opcode) &&
                                                     (TA_AUTH_MODE_EXECUTE_NESTED == packet->param1) &&
                                                     (TA_OPCODE_KEYGEN == packet->data[0])))
        {
            max_delay_count = ATCA_POLLING_RSA_KEY_GEN_MAX_TIME_MSEC / ATCA_POLLING_FREQUENCY_TIME_MSEC;
        }
        else
        {
            max_delay_count = ATCA_POLLING_MAX_TIME_MSEC / ATCA_POLLING_FREQUENCY_TIME_MSEC;
        }

        // check device is ready to receive commands
        if (ATCA_SUCCESS != (status = talib_is_device_ready(device)))
        {
            status = ATCA_TRACE(status, "Device is not ready to receive command");
            break;
        }

        // send the command
        packet->instr_code = ATCA_MAIN_PROCESSOR_WR_CMD;
        length += 1;
        if (ATCA_SUCCESS != (status = ATCA_TRACE(talib_execute_send(device, device_address, (uint8_t*)packet, length), "")))
        {
            break;
        }

        // Delay for execution time or initial wait before polling
        atca_delay_ms(execution_or_wait_time);

        // Dont attempt to read response for Power command
        if (packet->opcode == TA_OPCODE_POWER)
        {
            ATCA_TRACE(status, "No response for Power command");
            break;
        }

        do
        {
            //Read CSR to check RRDY flag
            status = talib_execute_read_register(device, ATCA_MAIN_PROCESSOR_RD_CSR, &csr_value);
            if ((ATCA_SUCCESS == status) && (ATCA_REGISTER_CSR_RRDY_MASK == (csr_value & ATCA_REGISTER_CSR_RRDY_MASK)))
            {
                memset((uint8_t*)packet, 0, 5); //Clear few bytes before receiving the response
                length = sizeof(ATCA_TA_CmdPacket);


                if (atca_iface_is_kit(&device->mIface))
                {
                    status = atreceive(&device->mIface, ATCA_MAIN_PROCESSOR_RD_CMD, (uint8_t*)packet, &length);
                }
                else
                {
#ifdef ATCA_HAL_LEGACY_API
                    status = atreceive(device->mIface, ATCA_MAIN_PROCESSOR_RD_CMD, (uint8_t*)packet, &length)
#else
                    status = talib_execute_receive_cmd(device, device_address, (uint8_t*)packet, &length);
#endif
                }

                if (ATCA_SUCCESS == status)
                {
                    break;
                }
            }

            // delay for polling frequency time
            atca_delay_ms(ATCA_POLLING_FREQUENCY_TIME_MSEC);

        }
        while (max_delay_count-- > 0);

        if (max_delay_count <= 0)
        {
            status = ATCA_TRACE(ATCA_RX_TIMEOUT, "atreceive - Failed");
            break;
        }

        if (status != ATCA_SUCCESS)
        {
            ATCA_TRACE(status, "atreceive - Failed");
            break;
        }

        // Check response size
        if (length < 5)
        {
            if (length > 0)
            {
                status = ATCA_RX_FAIL;
            }
            else
            {
                status = ATCA_RX_NO_RESPONSE;
            }
            break;
        }

        if (ATCA_SUCCESS != (status = talib_verify_crc((uint8_t*)packet, length - 2)))
        {
            ATCA_TRACE(status, "atca_ta_verify_crc - Failed");
            break;
        }

        if (ATCA_SUCCESS != (status = ((ATCA_TA_RspPacket*)packet)->resp_code))
        {
            if (ATCA_STATUS_AUTH_BIT == (status & ATCA_STATUS_AUTH_BIT))
            {
                status = (ATCA_STATUS)((uint8_t)status & ~ATCA_STATUS_AUTH_BIT); //ATCA_NESTED_CMD_ERROR;
            }
            ATCA_TRACE(status, "atreceive - Failed");
            break;
        }
    }
    while (0);

    return status;
}

/** \brief TA API - Wakes up device, sends the packet, waits for command completion,
 *         receives response, and puts the device into the idle state.
 *
 * \param[in,out] packet  As input, the packet to be sent. As output, the
 *                       data buffer in the packet structure will contain the
 *                       response.
 * \param[in]    device  CryptoAuthentication device to send the command to.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_execute_command_raw(ATCA_TA_CmdPacket* packet, ATCADevice device)
{
    ATCA_STATUS status;
    uint16_t length;

    length = ATCA_UINT16_BE_TO_HOST(packet->length);
    status = talib_add_crc((uint8_t*)&packet->length, length);

    if (ATCA_SUCCESS == status)
    {
        status = talib_execute_command_base(packet, device);
    }

    return status;
}

/** \brief TA API - Wakes up device, sends the packet, waits for command completion,
 *         receives response, and puts the device into the idle state.
 *
 * \param[in,out] packet  As input, the packet to be sent. As output, the
 *                       data buffer in the packet structure will contain the
 *                       response.
 * \param[in]    device  CryptoAuthentication device to send the command to.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_execute_command(ATCA_TA_CmdPacket* packet, ATCADevice device)
{
    ATCA_STATUS status;

    uint16_t length;

    if (TA_AUTH_STATE_IDLE != device->session_state)
    {
        status = talib_auth_execute_nested(device, packet, device->options);
    }
    else
    {
        length = ATCA_UINT16_BE_TO_HOST(packet->length);
        status = talib_add_crc((uint8_t*)&packet->length, length);

        if (ATCA_SUCCESS == status)
        {
            status = talib_execute_command_base(packet, device);
        }
    }

    return status;
}

/** \brief TA API - Read the specified register value
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_execute_read_register(
    ATCADevice device,                  /**< [in] Device context pointer */
    uint8_t    register_id,             /**< [in]  Register command id */
    uint8_t*   value                    /**< [out] Returned register Value */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint16_t rx_length = 1;

    if (device)
    {
        if (atca_iface_is_kit(&device->mIface))
        {
            status = ATCA_TRACE(atreceive(&device->mIface, register_id, value, &rx_length), "");
        }
        else
        {
#ifdef ATCA_HAL_LEGACY_API
            status = ATCA_TRACE(atreceive(device->mIface, register_id, value, &rx_length), "");
#else
            status = talib_execute_receive(device, atcab_get_device_address(device), register_id, value, &rx_length);
#endif
        }

    }

    return status;
}


/** \brief TA API - Update the register with the specified value
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_execute_write_register(
    ATCADevice device,                  /**< [in]  Device context pointer */
    uint8_t    register_id,             /**< [in]  Register command id */
    uint8_t    value                    /**< [in]  Register value to write */
    )
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (device)
    {
        uint8_t tx_value[2];
        tx_value[0] = register_id;
        tx_value[1] = value;
        status = ATCA_TRACE(talib_execute_send(device, atcab_get_device_address(device), tx_value, 2), "");
    }

    return status;
}

/** \brief TA API - Function Read csr value and check whether device is ready to
 *                  receive a command.
 *
 *  \param[in]    device         device context pointer
 *  \return ATCA_SUCCESS on device ready to receive a command, otherwise an error command
 */
ATCA_STATUS talib_is_device_ready(ATCADevice device)
{
    ATCA_STATUS status;
    uint8_t csr_value;
    int8_t no_of_retries_for_wakeup = 2;

    do
    {
        // Read CSR to check device status
        status = talib_execute_read_register(device, ATCA_MAIN_PROCESSOR_RD_CSR, &csr_value);
        if ((ATCA_SUCCESS == status) &&
            (((csr_value & ATCA_REGISTER_CSR_STATUS_MASK) == ATCA_REGISTER_CSR_STATUS_AVAILABLE_MASK) ||
             ((csr_value & ATCA_REGISTER_CSR_STATUS_MASK) == ATCA_REGISTER_CSR_STATUS_AVAILABLE_FIRST_MASK)))
        {
            break;
        }

        // wait for 5ms for device to wake up
        atca_delay_ms(ATCA_TA_WAKEUP_TIME_MSEC);

    }
    while (no_of_retries_for_wakeup-- > 0);

    if (no_of_retries_for_wakeup <= 0)
    {
        status = ATCA_TRACE(ATCA_WAKE_FAILED, "Device is busy or in sleep mode");
    }

    return status;
}
