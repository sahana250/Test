/**
 * \file
 *
 * \brief  Microchip TA Status Codes
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#ifndef _TALIB_STATUS_H
#define _TALIB_STATUS_H
/*lint +flb */

#ifdef __cplusplus
extern "C" {
#endif

#define TA_INTERNAL_ERROR               0x81
#define TA_TA_PARSE_ERROR               0x82
#define TA_EXEC_ERROR                   0x83
#define TA_SPACE_ERROR                  0x84
#define TA_BAD_HANDLE                   0x85
#define TA_AUTHORIZATION                0x86
#define TA_SECURE_BOOT                  0x87
#define TA_LENGTH_ERROR                 0x88
#define TA_PERMISSIONS                  0x89
#define TA_LOCK_ERROR                   0x8A
#define TA_CALCULATION                  0x8B
#define TA_KEY_TYPE                     0x8C
#define TA_CLASS_ERROR                  0x8D
#define TA_UNWRITTEN                    0x8E
#define TA_READ_ERROR                   0x8F
#define TA_WRITE_ERROR                  0x90
#define TA_MEMORY_ERROR                 0x91
#define TA_VOL_REG_ERROR                0x92
#define TA_ALIGNMENT_ERROR              0x93
#define TA_COUNTER_ERROR                0x94
#define TA_SELF_TEST_FAILURE            0x95
#define TA_LINK_ERROR                   0x96
#define TA_IMPORT_ERROR                 0x97
#define TA_REVOCATION_ERROR             0x98
#define TA_USAGE_LIMIT_ERROR            0x99
#define TA_RIGHTS_ERROR                 0x9A
#define TA_VALIDATION_ERROR             0x9B
#define TA_CONFIG_ERROR                 0x9C
#define TA_FAST_CRYPTO_ERROR            0x9D
#define TA_ATTRIBUTE_ERROR              0x9E
#define TA_SIGN_VERIFICATION_ERROR      0x9F
#define TA_SEQUENCE_PRE_ERROR           0xA0
#define TA_SEQUENCE_NESTED_ERROR        0xA1
#define TA_SEQUENCE_ERROR               0xA2
#define TA_ABORT_KEY_GEN                0xA3
#define TA_COMPLIANCE_ERROR             0xA4
#define TA_SIZE_ERROR                   0xA5
#define TA_PROPERTY_ERROR               0xA6
#define TA_DEV_UPDATE_ERROR             0xA7
#define TA_RNG_ERROR                    0xA8
#define TA_HANDLE_EXIST_ERROR           0xA9
#define TA_EXTENSIONS_ERROR             0xAA

#ifdef __cplusplus
}
#endif

/*lint -flb */
#endif /* _TALIB_STATUS_H */
