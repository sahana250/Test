/**
 * \file
 * \brief Basic SelfTest commands for Trust Anchor Devices.
 *
 * The SelfTest command performs a test of one or more of the cryptographic
 * engines within the device.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheet for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"
#include "talib_status.h"

/** \brief TA API - Executes the SelfTest command, which performs a test of one or more
 *          of the cryptographic engines within the chip.
 *
 *  \param[in]  device          Device context pointer
 *  \param[in]  mode            Mode for self test command
 *  \param[in]  tests_bitmap    Bit map of tests to be run for self tests
 *  \param[out] result_bitmap   Bit map of tests that failed self tests
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_selftest(ATCADevice device, const uint8_t mode, uint32_t tests_bitmap, uint32_t*
                           const result_bitmap)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    if (NULL == device)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        //Run all the test indcated in Config.Self_Test.Failure_Clear
        if ((mode & TA_SELFTEST_MODE_USECONFIG) == TA_SELFTEST_MODE_USECONFIG)
        {
            tests_bitmap = 0;
        }

        packet->opcode = TA_OPCODE_SELFTEST;
        packet->param1 = mode;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(tests_bitmap);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if ((ATCA_SUCCESS == status) || (TA_SELF_TEST_FAILURE == status))
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;

            if (result_bitmap)
            {
                uint16_t length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;
                if (length)
                {
                    memcpy(result_bitmap, resp_packet->data, length);
                    *result_bitmap = ATCA_UINT32_BE_TO_HOST(*result_bitmap);
                }
                else
                {
                    *result_bitmap = 0;
                }
            }
        }
        talib_packet_free(packet);
    }

    return status;
}
