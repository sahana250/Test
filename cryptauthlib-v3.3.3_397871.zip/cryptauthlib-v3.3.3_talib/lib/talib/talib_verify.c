/**
 * \file
 * \brief Basic Verify commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheet for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes the Verify command, to Verify a signature using given the message and a
 *                  public key. The message and public key can either be stored within Vega or
 *                  passed on the command line
 *
 * \param[in]  device           Device context pointer
 * \param[in]  mode             Verify command mode options
 * \param[in]  msg_handle       Message handle that contains message used for Signature calculation
 * \param[in]  pub_handle       Public key Handle to be used to verify signature
 * \param[in]  signature        Signature to be verified
 * \param[in]  sign_size        Size of the signature passed. Varies based on Key type and
 *                              Algorithm
 * \param[in]  message          If msg_handle is IO buffer, message used for Signature calculation.
 *                              NULL if message is coming from other than IO buffer
 * \param[in]  message_len      input message length
 * \param[in]  public_key       If pub_handle is IO buffer, the public key to be used for
 *                              verification. NULL if Public key is stored internally
 * \param[in]  pubkey_len       Size of the public_key passed. Varies based on Key type and
 *                              Algorithm
 * \param[out] is_verified      if verified true returned here or else false.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_verify(ATCADevice device, const uint8_t mode, const uint16_t msg_handle, const
                         uint16_t pub_handle, const uint8_t* signature, const uint16_t sign_size,
                         const uint8_t* message, const uint16_t message_len, const uint8_t* public_key, const uint16_t
                         pubkey_len, bool* is_verified)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t* data;

    if ((NULL == device) || (NULL == signature)
        || ((message == NULL) && (msg_handle & TA_HANDLE_INPUT_BUFFER))
        || ((public_key == NULL) && (pub_handle & TA_HANDLE_INPUT_BUFFER)) )
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_VERIFY;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(msg_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(pub_handle);

        data = packet->data;
        //copy signature into input stream
        memcpy(data, signature, sign_size);
        data += sign_size;

        // Take message into input stream if msg handle is input buffer
        if (msg_handle & TA_HANDLE_INPUT_BUFFER)
        {
            memcpy(data, message, message_len);
            data += message_len;
        }

        if (pub_handle & TA_HANDLE_INPUT_BUFFER)
        {
            memcpy(data, public_key, pubkey_len);
            data += pubkey_len;
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (is_verified && rsp_length)
            {
                *is_verified = resp_packet->data[0];
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief Executes the Verify command for ECCP256, which verifies a signature (ECDSA
 *          verify operation) with all components (message, signature, and
 *          public key) supplied.
 *
 * \param[in]  device       Device context pointer
 * \param[in]  message      32 byte message to be verified. Typically
 *                          the SHA256 hash of the full message.
 * \param[in]  signature    Signature to be verified. R and S integers in
 *                          big-endian format. 64 bytes for P256 curve.
 * \param[in]  public_key   The public key to be used for verification. X and
 *                          Y integers in big-endian format. 64 bytes for
 *                          P256 curve.
 * \param[out] is_verified  Boolean whether or not the message, signature,
 *                          public key verified.
 *
 * \return ATCA_SUCCESS on verification success or failure, because the
 *         command still completed successfully.
 */
ATCA_STATUS talib_verify_extern_compat(ATCADevice device, const uint8_t message[TA_VERIFY_P256_MSG_SIZE],
                                       const uint8_t signature[TA_SIGN_P256_SIG_SIZE],
                                       const uint8_t public_key[TA_ECC256_PUB_KEY_SIZE], bool* is_verified)
{
    return talib_verify(device, TA_KEY_TYPE_ECCP256, TA_HANDLE_INPUT_BUFFER, TA_HANDLE_INPUT_BUFFER, signature, 64,
                        message, TA_VERIFY_P256_MSG_SIZE, public_key, TA_ECC256_PUB_KEY_SIZE, is_verified);
}

/** \brief Executes the Verify command for ECCP256, which verifies a signature (ECDSA
 *         verify operation) with a public key stored in the device.
 *
 * \param[in]  device       Device context pointer
 * \param[in]  message      32 byte message to be verified. Typically
 *                          the SHA256 hash of the full message.
 * \param[in]  signature    Signature to be verified. R and S integers in
 *                          big-endian format. 64 bytes for P256 curve.
 * \param[in]  key_id       Handle containing the public key to be used in the
 *                          verification.
 * \param[out] is_verified  Boolean whether or not the message, signature,
 *                          public key verified.
 *
 * \return ATCA_SUCCESS on verification success or failure, because the
 *         command still completed successfully.
 */
ATCA_STATUS talib_verify_stored_compat(ATCADevice device, const uint8_t message[TA_VERIFY_P256_MSG_SIZE],
                                       const uint8_t signature[TA_SIGN_P256_SIG_SIZE], const uint16_t key_id,
                                       bool* is_verified)
{
    return talib_verify(device, TA_KEY_TYPE_ECCP256, TA_HANDLE_INPUT_BUFFER, key_id, signature,
                        TA_SIGN_P256_SIG_SIZE, message, TA_VERIFY_P256_MSG_SIZE, NULL, 0, is_verified);
}

/** \brief Executes the Verify command, to expand a point for known X - value and return Y - val
 *
 * \param[in]  device  Device context pointer
 * \param[in]  y_odd   2 if Y is even or 3 if Y is odd
 *
 * \param[in]  x_val   Known X value
 *
 * \param[out] y_val   Y value for corresponding X value returned here
 *
 * \return ATCA_SUCCESS on success otherwise an error code
 */
ATCA_STATUS talib_verify_point_exp(ATCADevice device, const uint8_t y_odd, const uint8_t* x_val,
                                   uint8_t* const y_val)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    ATCA_TA_RspPacket* resp_packet;
    uint16_t rsp_length;

    if ((NULL == device) || (NULL == x_val))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_VERIFY;
        packet->param1 = TA_VERIFY_POINT_EXPANSION;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE((uint32_t)y_odd);

        //Update input stream with know X - value (must be 32 byte)
        memcpy(packet->data, x_val, TA_VERIFY_X_VAL_MAX_SIZE);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(TA_VERIFY_X_VAL_MAX_SIZE +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            resp_packet = (ATCA_TA_RspPacket*)packet;
            rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (y_val && rsp_length)
            {
                memcpy(y_val, resp_packet->data, rsp_length);
            }
        }
        talib_packet_free(packet);
    }

    return status;
}
