/**
 * \file
 * \brief Basic Managecert commands for Trust Anchor Devices.
 *
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes ManageCert command to parse and verify x.509 certs or
 *                      manage an input certificate revocation list
 *
 *  \param[in]  device          Device object that holds the device related informations
 *  \param[in]  mode            mode parameter for ManageCert command
 *  \param[in]  parent_handle   Verifying certificate handle. This can be in Shared or Volatile
 *  \param[in]  target_handle   Handle to write verified certificate or CRL element. After
 *                                  successful verification, extracted element is written to this
 *                                  handle. A value of 0xFFFF, skips write to handle but returns
 *                                  verification status
 *  \param[in]  source_handle   Handle pointing to Full certificate or CRL. Only supports IO buffer
 *                                  or shared memory, but not Volatile register.
 *                                  CRL must point to IO buffer.
 *  \param[in]  in_cert         Incoming certificate or CRL when source handle pointing to IO
 *                                  buffer. Maximum size is 1020. Should be NULL if source_handle
 *                                  points to internal memory
 *  \param[in]  length          Length of the incoming certificate or CRL. Applicable only when
 *                                  in_cert exists on the IO buffer
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_manage_cert(ATCADevice device, const uint8_t mode, const uint16_t parent_handle,
                              const uint16_t target_handle, const uint16_t source_handle,
                              const uint8_t* in_cert, const uint16_t length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t *data;
    uint32_t tmp32;

    if (TA_HANDLE_INPUT_BUFFER == (source_handle & TA_HANDLE_MASK) && (NULL == in_cert))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_MANAGECERT;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(parent_handle);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(target_handle);

        data = packet->data;
        tmp32 = ATCA_UINT32_HOST_TO_BE(((uint32_t)source_handle << 16) | length);
        memcpy(data, &tmp32, sizeof(tmp32));
        data += sizeof(source_handle) + sizeof(length);

        if (TA_HANDLE_INPUT_BUFFER == (source_handle & TA_CERT_VERIFY_ONLY))
        {
            memcpy(data, in_cert, length);
            data += length;
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) + ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        talib_packet_free(packet);
    }

    return status;
}


/** \brief TA API - Executes ManageCert command to verify x.509 incoming cert / store extracted
 *                      certificate to shared element
 *
 *  \param[in]  device          Device object that holds the device related informations
 *  \param[in]  parent_handle   Verifying certificate handle. This can be in Shared or Volatile
 *  \param[in]  target_handle   Handle to write verified certificate. After successful verification,
 *                                  extracted elements are written to this handle.
 *  \param[in]  in_cert         Incoming certificate to verify and extract
 *  \param[in]  length          Length of the incoming certificate
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
static ATCA_STATUS talib_managecert_io_base(ATCADevice device, const uint16_t parent_handle,
                                            const uint16_t target_handle, const uint8_t* in_cert,
                                            const uint16_t cert_length)
{

    ATCA_STATUS status;
    uint8_t *cert;

    cert = (uint8_t*)in_cert;
    uint16_t length = cert_length;

    do
    {
        if (length > TA_MAX_CERTIFICATE_SIZE)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid certificate length received");
            break;
        }

        if (length <= TA_MAX_INPUT_CERTIFICATE_SIZE)
        {

            if (ATCA_SUCCESS != (status = talib_manage_cert(device, TA_IO_COMPLETE_CERT,
                                                            parent_handle, target_handle, TA_HANDLE_INPUT_BUFFER, cert, length)))
            {
                ATCA_TRACE(status, "talib_manage_cert - Execution failed");
                break;
            }
        }

        else
        {

            if (ATCA_SUCCESS != (status = talib_manage_cert(device, TA_IO_CERT_FIRST,
                                                            parent_handle, target_handle, TA_HANDLE_INPUT_BUFFER, cert, TA_MAX_INPUT_CERTIFICATE_SIZE)))
            {
                ATCA_TRACE(status, "talib_manage_cert - Execution failed");
                break;
            }

            length -= TA_MAX_INPUT_CERTIFICATE_SIZE;
            cert += TA_MAX_INPUT_CERTIFICATE_SIZE;

            if (length > TA_MAX_INPUT_CERTIFICATE_SIZE)
            {

                if (ATCA_SUCCESS != (status = talib_manage_cert(device, TA_IO_CERT_CONTINUE,
                                                                parent_handle, target_handle, TA_HANDLE_INPUT_BUFFER, cert, TA_MAX_INPUT_CERTIFICATE_SIZE)))
                {
                    ATCA_TRACE(status, "talib_manage_cert - Execution failed");
                    break;
                }

                length -= TA_MAX_INPUT_CERTIFICATE_SIZE;
                cert += TA_MAX_INPUT_CERTIFICATE_SIZE;
            }

            if (ATCA_SUCCESS != (status = talib_manage_cert(device, TA_IO_CERT_FINISH,
                                                            parent_handle, target_handle, TA_HANDLE_INPUT_BUFFER, cert, length)))
            {
                ATCA_TRACE(status, "talib_manage_cert - Execution failed");
                break;
            }

        }
    }
    while (0);

    return status;

}

/** \brief TA API - Executes ManageCert command to verify x.509 incoming cert and store extracted
 *                      certificate to shared element
 *
 *  \param[in]  device          Device object that holds the device related informations
 *  \param[in]  parent_handle   Verifying certificate handle. This can be in Shared or Volatile
 *  \param[in]  target_handle   Handle to write verified certificate. After successful verification,
 *                              extracted elements are written to this handle.
 *  \param[in]  in_cert         Incoming certificate to verify and extract
 *  \param[in]  cert_length     Length of the incoming certificate
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_store_extracted_cert_io(ATCADevice device, const uint16_t parent_handle,
                                          const uint16_t target_handle, const uint8_t* in_cert,
                                          const uint16_t cert_length)
{

    return talib_managecert_io_base(device, parent_handle, target_handle, in_cert, cert_length);

}

/** \brief TA API - Executes ManageCert command to verify x.509 stored cert and store extracted
 *                      certificate to shared element
 *
 *  \param[in]  device          Device object that holds the device related informations
 *  \param[in]  parent_handle   Verifying certificate handle. This can be in Shared or Volatile
 *  \param[in]  target_handle   Handle to write verified certificate. After successful verification,
 *                                  extracted elements are written to this handle.
 *  \param[in]  source_handle   Handle pointing to Full certificate only supports shared memory
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_store_extracted_cert(ATCADevice device, const uint16_t parent_handle,
                                       const uint16_t target_handle, const uint16_t source_handle)
{
    return talib_manage_cert(device, TA_CERTIFICATE_STORED, parent_handle, target_handle,
                             source_handle, NULL, 0);
}



/** \brief TA API - Executes ManageCert command to verify x.509 incoming cert and returns
 *                      verification status
 *
 *  \param[in]  device          Device object that holds the device related informations
 *  \param[in]  parent_handle   Verifying certificate handle. This can be in Shared or Volatile
 *  \param[in]  in_cert         Incoming certificate to verify and extract
 *  \param[in]  cert_length     Length of the incoming certificate
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_verify_cert_io(ATCADevice device, const uint16_t parent_handle,
                                 const uint8_t* in_cert, const uint16_t cert_length)
{

    return talib_managecert_io_base(device, parent_handle, TA_CERT_VERIFY_ONLY, in_cert,
                                    cert_length);

}

/** \brief TA API - Executes ManageCert command to verify x.509 stored cert and returns verification
 *                      status
 *
 *  \param[in]  device          Device object that holds the device related informations
 *  \param[in]  parent_handle   Verifying certificate handle. This can be in Shared or Volatile
 *  \param[in]  source_handle   Handle pointing to Full certificate only supports shared memory
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_verify_cert(ATCADevice device, const uint16_t parent_handle,
                              const uint16_t source_handle)
{
    return talib_manage_cert(device, TA_CERTIFICATE_STORED, parent_handle,
                             TA_CERT_VERIFY_ONLY, source_handle, NULL, 0);
}
