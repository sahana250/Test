/**
 * \file
 * \brief CryptoAuthLib Basic API methods for Info command.
 *
 * Info command returns a variety of static and dynamic information about the
 * device and its state. Also is used to control the GPIO pin and the persistent
 * latch.
 *
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "atca_config.h"
#include "atca_compiler.h"
#include "talib_basic.h"

#ifndef LOCK_ZONE_CONFIG
#define LOCK_ZONE_CONFIG    ((uint8_t)0x00)
#endif

#ifndef LOCK_ZONE_DATA
#define LOCK_ZONE_DATA      ((uint8_t)0x01)
#endif

/** \brief TA API - Issues an Info command, which return internal device information
 * \param[in]  device       Device context pointer
 * \param[in]  mode         Selects which mode to be used for info command.
 * \param[in]  param2       Handle for mode 2 & 3.
 * \param[out] out_data     Response from info command
 * \param[in,out] data_size  out_data buffer size as input and valid data length as output
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */

ATCA_STATUS talib_info_base(ATCADevice device, uint8_t mode, uint32_t param2, uint8_t* out_data,
                            size_t* data_size)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    if ((device == NULL) || (out_data == NULL) || (data_size == NULL))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_INFO;
        packet->param1 = mode;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(param2);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            size_t rx_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;
            if (rx_length)
            {
                if (*data_size < rx_length)
                {
                    status = ATCA_TRACE(ATCA_SMALL_BUFFER, "Small buffer received");
                }
                else
                {
                    *data_size = rx_length;
                }
                memcpy(out_data, resp_packet->data, *data_size);
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Issues an Info command to return revision of the internal hardware,
 *                  configuration or firmware of the device
 *
 * \param[in]  device      Device context pointer
 * \param[out] revision    device revision number returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info(ATCADevice device, uint8_t revision[8])
{
    size_t revnum_size = 8;

    return talib_info_base(device, TA_INFO_MODE_REV, 0, revision, &revnum_size);
}

/** \brief TA API - Issues an Info command to return revision of the internal hardware
 *                  (compatible with cryptoauthlib info command)
 * \param[in]  device      Device context pointer
 * \param[out] revision    device revision number returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_compat(ATCADevice device, uint8_t revision[4])
{
    size_t revnum_size = 4;
    ATCA_STATUS status = talib_info_base(device, TA_INFO_MODE_REV, 0, revision, &revnum_size);

    if (ATCA_SMALL_BUFFER == status)
    {
        status = ATCA_SUCCESS;
    }

    return status;
}

/** \brief The function returns 8 byte serial number of the device
 *
 *  \param[in]  device         Device context pointer
 *  \param[out] serial_number  8 byte serial number is returned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_serial_number(ATCADevice device, uint8_t serial_number[8])
{
    ATCA_STATUS status;
    size_t serial_number_size = 8;

    status = talib_info_base(device, TA_INFO_MODE_DEDICATED_MEMORY, 0, serial_number, &serial_number_size);

    if (ATCA_SMALL_BUFFER == status)
    {
        status = ATCA_SUCCESS;
    }

    return status;
}

/** \brief The function return 8 byte serial number of the device in 9 byte buffer
 *          (compatibility mode - cryptoauth devices have a 9 byte serial number)
 *
 *  \param[in]  device         Device context pointer
 *  \param[out] serial_number  8 byte serial number is returned here.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_serial_number_compat(ATCADevice device, uint8_t serial_number[9])
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    size_t serial_number_size = 8;

    if (serial_number)
    {
        serial_number[0] = 0;
        status = talib_info_base(device, TA_INFO_MODE_DEDICATED_MEMORY, 0, &serial_number[1], &serial_number_size);
    }

    if (ATCA_SMALL_BUFFER == status)
    {
        status = ATCA_SUCCESS;
    }

    return status;
}

/** \brief TA API - Issues an Info command to return remaining bytes in Non Volatile memory
 *
 * \param[in]  device       Device context pointer
 * \param[out] nv_remain    remaining non volatile memory in the device is returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_nv_remain(ATCADevice device, uint32_t* nv_remain)
{
    size_t nv_remain_out_size = TA_NV_REMAIN_MODE_OUTPUT_LENGTH;

    return talib_info_base(device, TA_INFO_MODE_NV_REMAIN, 0, (uint8_t*)nv_remain, &
                           nv_remain_out_size);
}

/** \brief TA API - Issues an Info command to return handle validity
 *
 * \param[in]  device            Device context pointer
 * \param[in]  target_handle     Target handle to read info
 * \param[out] is_valid          True if handle is created, irrespective of written or used status
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_handle_valid(ATCADevice device, uint32_t target_handle, uint8_t* is_valid)
{
    size_t handle_valid_out_size = TA_HANDLE_VALID_OUTPUT_LENGTH;

    return talib_info_base(device, TA_INFO_MODE_HANDLE_VALID, target_handle, is_valid, &
                           handle_valid_out_size);
}

/** \brief TA API - Issues an Info command to return attributes & status of a handle
 *
 * \param[in]  device             Device context pointer
 * \param[in]  target_handle      Target handle to read handle info
 * \param[out] handle_info        Handle info (handle attributes) returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_handle_info(ATCADevice device, uint32_t target_handle, uint8_t handle_info[TA_HANDLE_INFO_SIZE])
{
    size_t handle_info_size = TA_HANDLE_INFO_SIZE;

    return talib_info_base(device, TA_INFO_MODE_HANDLE_INFO, target_handle, handle_info,
                           &handle_info_size);
}

/** \brief TA API - Get the data stored in a handle
 *
 * \param[in]  device          Device context pointer
 * \param[in]  target_handle   Target handle to read info
 * \param[out] out_size        data handle size is returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_handle_size(ATCADevice device, uint32_t target_handle, size_t* out_size)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;
    uint8_t handle_info[TA_HANDLE_INFO_SIZE];


    if (out_size)
    {
        status = talib_info_get_handle_info(device, target_handle, handle_info);

        if (ATCA_SUCCESS == status)
        {
            uint8_t handle_class = handle_info[0] & TA_HANDLE_INFO_CLASS_MASK;

            switch (handle_class)
            {
            case TA_CLASS_PUBLIC_KEY:
                break;
            case TA_CLASS_PRIVATE_KEY:
                break;
            case TA_CLASS_SYMMETRIC_KEY:
                break;
            case TA_CLASS_DATA:
                *out_size = (size_t)(((handle_info[2] & 0x0F) << 8) | handle_info[1]);
                break;
            case TA_CLASS_EXTRACTED_CERT:
                break;
            case TA_CLASS_FAST_CRYPTO_KEY_GROUP:
                break;
            case TA_CLASS_CRL:
                break;
            default:
                break;
            }
        }
    }
    return status;
}

/** \brief TA API - Issues an Info command to return handles list
 *
 * \param[in]     device             Device context pointer
 * \param[out]    handle_array       List of handles received as response..
 * \param[in,out] array_size         As input, handle_array buffer size
 *                                   As output, number of elements in handle_array
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_handles_array(ATCADevice device, uint16_t* handle_array, size_t* array_size)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket * packet = NULL;

    if ((device == NULL) || (array_size == NULL))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_INFO;
        packet->param1 = TA_INFO_MODE_HANDLE_ARRAY;
        packet->param2.val32 = 0;

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            size_t rx_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (rx_length > 2)
            {
                int i;

                uint8_t* data = &resp_packet->data[2];
                rx_length -= 2;

                if (*array_size < rx_length / 2)
                {
                    status = ATCA_TRACE(ATCA_SMALL_BUFFER, "Small buffer received");
                }
                else
                {
                    *array_size = rx_length / 2;
                }

                for (i = 0; i < (int)*array_size; i++, data += 2)
                {
                    *handle_array++ = ATCA_UINT16_BE_TO_HOST(data[0] + (uint16_t)(data[1] << 8));
                }

                *array_size = rx_length / 2;
            }
            else
            {
                *array_size = 0;
            }

        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Issues an Info command to get auth session validity
 *
 * \param[in]  device            Device context pointer
 * \param[in]  auth_session_id   Target Auth session id to check validity, 0-1 are only valid
 * \param[out] is_valid          Auth session validity. True if session is valid for use
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_auth_session_valid(ATCADevice device, uint8_t auth_session_id, uint8_t* is_valid)
{
    ATCA_STATUS status;
    uint8_t auth_status[TA_AUTH_SESSION_MAX];
    size_t auth_status_out_size;

    do
    {
        if (is_valid == NULL)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        if (auth_session_id >= sizeof(auth_status))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid authorization session id received");
            break;
        }

        auth_status_out_size = TA_AUTH_SESSION_MAX;

        if (ATCA_SUCCESS != (status = talib_info_base(device, TA_INFO_MODE_AUTH_STATUS, 0,
                                                      auth_status, &auth_status_out_size)))
        {
            ATCA_TRACE(status, "talib_is_auth_session_valid - Info base failed");
            break;
        }

        *is_valid = (auth_status[auth_session_id] == 1) ? 1 : 0;
    }
    while (0);

    return status;
}

/** \brief TA API - Issues an Info command to get volatile register status
 *
 * \param[in]  device                Device context pointer
 * \param[in]  volatile_register_id  Target Volatile register id to check validity, 0-3 are only
 *                                   valid
 * \param[out] is_valid              True if handle is created, irrespective of written or used
 *                                   status
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_volatile_register_valid(ATCADevice device, uint8_t volatile_register_id,
                                             uint8_t* is_valid)
{
    ATCA_STATUS status;
    uint8_t vol_reg_status[TA_VOLATILE_REGISTER_MAX];
    size_t volg_reg_status_out_len;

    do
    {
        if (is_valid == NULL)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        if (volatile_register_id >= sizeof(vol_reg_status))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid volatile register id received");
            break;
        }

        volg_reg_status_out_len = TA_VOLATILE_REGISTER_MAX;
        if (ATCA_SUCCESS != (status = talib_info_base(device, TA_INFO_MODE_VOLATILE_REG_STATUS,
                                                      0, vol_reg_status, &volg_reg_status_out_len)))
        {
            ATCA_TRACE(status, "talib_is_volatile_register_valid - Info base failed");
            break;
        }

        *is_valid = (vol_reg_status[volatile_register_id] == 1) ? 1 : 0;
    }
    while (0);

    return status;
}

/** \brief TA API - Issues an Info command to return dedicated memory contents
 *
 * \param[in]  device              Device context pointer
 * \param[out] dedicated_memory    dedicated memory content of 16 byte is return here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_dedicated_memory(ATCADevice device, uint8_t* dedicated_memory)
{
    size_t dedicated_memory_size;

    dedicated_memory_size = TA_DEDICATED_MEMORY_SIZE;
    return talib_info_base(device, TA_INFO_MODE_DEDICATED_MEMORY, 0, dedicated_memory, &
                           dedicated_memory_size);
}

/** \brief TA API - Issues an Info command to return chip status
 *
 * \param[in]  device            Device context pointer
 * \param[out] chip_status       chip status (config lock status, setup lock status, latch status)
 *                               returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_chip_status(ATCADevice device, uint8_t chip_status[TA_CHIP_STATUS_SIZE])
{
    size_t chipstatus_size = TA_CHIP_STATUS_SIZE;

    return talib_info_base(device, TA_INFO_MODE_CHIP_STATUS, 0, chip_status, &chipstatus_size);
}

/** \brief TA API - Issues an Info command to get config lock status
 *
 * \param[in]  device       Device context pointer
 * \param[out] is_locked    True if config is locked or else false
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_config_locked(ATCADevice device, bool* is_locked)
{
    ATCA_STATUS status;
    uint8_t chip_status[TA_CHIP_STATUS_SIZE];

    if (NULL == is_locked)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        status = ATCA_TRACE(talib_info_get_chip_status(device, chip_status), "Chip status failed");
        *is_locked = chip_status[0] ? true : false;
    }

    return status;
}

/** \brief TA API - Issues an Info command to get setup lock status
 *
 * \param[in]  device       Device context pointer
 * \param[out] is_locked    True if setup is locked or else false
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_setup_locked(ATCADevice device, bool* is_locked)
{
    ATCA_STATUS status;
    uint8_t chip_status[TA_CHIP_STATUS_SIZE];

    if (NULL == is_locked)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        status = ATCA_TRACE(talib_info_get_chip_status(device, chip_status), "Chip status failed");
        *is_locked = chip_status[1] ? true : false;
    }

    return status;
}

/** \brief TA API - Issues an Info command to get Vcc latch state
 *
 * \param[in]  device         Device context pointer
 * \param[out] latch_value    return current state of the vcc latches
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_vcc_latch(ATCADevice device, uint8_t* latch_value)
{
    ATCA_STATUS status;
    uint8_t chip_status[TA_CHIP_STATUS_SIZE];

    if (NULL == latch_value)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        status = ATCA_TRACE(talib_info_get_chip_status(device, chip_status), "Chip status failed");
        memcpy(latch_value, &chip_status[2], 4);
    }

    return status;
}

/** \brief TA API - Issues an Info command to get Failure logs
 *
 * \param[in]  device            Device context pointer
 * \param[out] failure_log       previous self test failure log is returned here (64 byte)
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_failure_log(ATCADevice device, uint8_t* failure_log)
{
    size_t failure_log_size = TA_FAILURE_LOG_SIZE;

    return talib_info_base(device, TA_INFO_MODE_FAILURE_LOG, 0, failure_log, &failure_log_size);
}

/** \brief TA API - Issues an Info command to get ROM ID
 *
 * \param[in]  device  Device context pointer
 * \param[out] rom_id  Device rom version id is returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_rom_id(ATCADevice device, uint16_t* rom_id)
{
    size_t rom_id_size = TA_ROM_ID_SIZE;

    return talib_info_base(device, TA_INFO_MODE_ROM_ID, 0, (uint8_t*)rom_id, &rom_id_size);
}

/** \brief TA API - Issues an Info command to get CRL handle
 *
 * \param[in]  device      Device context pointer
 * \param[out] crl_handle  valid crl handle is returned here
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_info_get_crl_handle(ATCADevice device, uint8_t* crl_handle)
{
    size_t crl_handle_size = TA_CRL_HANDLE_SIZE;

    return talib_info_base(device, TA_INFO_MODE_CRL_HANDLE, 0, crl_handle, &crl_handle_size);
}

/** \brief Executes Read command, which reads the configuration zone to see if
 *          the specified zone is locked.
 *
 *  \param[in]  device     Device context pointer
 *  \param[in]  zone       The zone to query for locked (use LOCK_ZONE_CONFIG or
 *                         LOCK_ZONE_SETUP).
 *  \param[out] is_locked  Lock state returned here. True if locked.
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_locked_compat(ATCADevice device, uint8_t zone, bool* is_locked)
{
    ATCA_STATUS status = ATCA_BAD_PARAM;

    if (LOCK_ZONE_CONFIG == zone)
    {
        status = ATCA_TRACE(talib_is_config_locked(device, is_locked), "");
    }
    else if (LOCK_ZONE_DATA == zone)
    {
        status = ATCA_TRACE(talib_is_setup_locked(device, is_locked), "");
    }

    return status;
}

/** \brief Executes info command, which reads the handle info to see if
 *          the specified handle element is locked.
 *
 *  \param[in]  device     Device context pointer
 *  \param[in]  handle     Handle to query for locked
 *  \param[out] is_locked  Lock state returned here. True if locked.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_is_handle_locked(ATCADevice device, uint16_t handle, bool* is_locked)
{
    ATCA_STATUS status;
    uint8_t handle_info[TA_HANDLE_INFO_SIZE];

    if (NULL == is_locked)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        status = ATCA_TRACE(talib_info_get_handle_info(device, handle, handle_info), "Failed");
        *is_locked = (handle_info[8] & 0x04) ? true : false;
    }

    return status;
}

/** \brief Check if a slot is a private key
 *
 *  \param[in]   device         Device context pointer
 *  \param[in]   handle         Handle to query
 *  \param[out]  is_private     return true if private
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code
 */
ATCA_STATUS talib_is_private(ATCADevice device, uint16_t handle, bool* is_private)
{
    ATCA_STATUS status;
    uint8_t handle_info[TA_HANDLE_INFO_SIZE];

    if (NULL == is_private)
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        status = ATCA_TRACE(talib_info_get_handle_info(device, handle, handle_info), "Failed");
        *is_private = (TA_CLASS_PRIVATE_KEY == handle_info[0]);
    }

    return status;
}
