/**
 * \file
 * \brief Basic Create commands for the Trust Anchor Devices
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes Create command to create elements on shared data or volatile register.
 *                  This cannot create Secure_boot special handles.
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  mode           mode parameter for the create operations
 *  \param[in]  details        Additional details for HMAC and Ephemeral elements
 *  \param[in]  handle_in      handle to use to create an element
 *  \param[in]  handle_config  Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *  \param[out] handle_out     handle created by TA100 is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create(ATCADevice device, const uint8_t mode, const uint16_t details, const
                         uint16_t handle_in, const ta_element_attributes_t* handle_config,
                         uint16_t* const handle_out)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    ATCA_TA_RspPacket* resp_packet;
    uint16_t rsp_length;

    do
    {
        if ((NULL == device) || (NULL == handle_config))
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        if ((mode & TA_CREATE_MODE_HANDLE_BY_VEGA) == TA_CREATE_MODE_HANDLE_BY_VEGA)
        {
            if (handle_out == NULL)
            {
                status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
                break;
            }
        }

        packet = talib_packet_alloc();
        if (!packet)
        {
            status = ATCA_TRACE(ATCA_ALLOC_FAILURE, "");
            break;
        }

        packet->opcode = TA_OPCODE_CREATE;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(details);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(handle_in);

        // copy handle configuration to packet data (8 byte)
        memcpy(packet->data, (uint8_t*)handle_config, TA_CREATE_CONFIGURATION_SIZE);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(TA_CREATE_CONFIGURATION_SIZE +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        if (ATCA_SUCCESS != (status = ATCA_TRACE(talib_execute_command(packet, device), "")))
        {
            break;
        }

        resp_packet = (ATCA_TA_RspPacket*)packet;
        rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

        if (handle_out && rsp_length)
        {
            memcpy((uint8_t*)handle_out, resp_packet->data, sizeof(*handle_out));
            *handle_out = ATCA_UINT16_BE_TO_HOST(*handle_out);
        }
    }
    while (0);

    if (packet)
    {
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes Create command to create elements on TA100 shared data memory.
 *                  The handle is created by vega and handle value is copied into output buffer.
 *                  This function wont create handle for ephemeral or HMAC symmetric key.
 *                  This cannot create Secure_boot special handles
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  handle_cfg     Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *  \param[out] handle_out     handle created by TA100 is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create_element(ATCADevice device, const ta_element_attributes_t* handle_cfg,
                                 uint16_t* const handle_out)
{
    return talib_create(device, TA_CREATE_MODE_HANDLE_BY_VEGA, 0, TA_HANDLE_SHARED_DATA, handle_cfg,
                        handle_out);
}

/** \brief TA API - Executes Create command to create elements on TA100 shared data memory or
 *                  volatile register. This cannot create Secure_boot special handles.
 *                  This function wont create handle for ephemeral or HMAC symmetric key.
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  handle_in      handle to use to create an element
 *  \param[in]  handle_config  Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create_element_with_handle(ATCADevice device, const uint16_t handle_in, const
                                             ta_element_attributes_t* handle_config)
{
    return talib_create(device, TA_CREATE_MODE_HANDLE_BY_HOST, 0, handle_in, handle_config,
                        NULL);
}

/** \brief TA API - Executes Create command to create Ephemeral element on volatile register
 *                  This cannot create Secure_boot special handles
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  details        Additional details for HMAC and Ephemeral elements
 *  \param[in]  handle_in      handle to use to create an element
 *  \param[in]  handle_config  Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create_ephemeral_element_with_handle(ATCADevice device, const uint16_t details,
                                                       const uint16_t handle_in, const
                                                       ta_element_attributes_t* handle_config)
{
    return talib_create(device, (TA_CREATE_MODE_EPHEMERAL_ELEMENT) |
                        (TA_CREATE_MODE_HANDLE_BY_HOST), details, handle_in, handle_config, NULL);
}

/** \brief TA API - Executes Create command to create HMAC symmetric elements on shared data.
 *                  The handle is created by vega and handle value is copied into output buffer.
 *                  This cannot create Secure_boot special handles
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  hmac_key_size  size of hmac symmetric key size
 *  \param[in]  handle_config  Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *  \param[out]  handle_out    handle created by vega
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create_hmac_element(ATCADevice device, const size_t hmac_key_size, const
                                      ta_element_attributes_t* handle_config, uint16_t* const
                                      handle_out)
{
    ATCA_STATUS status;
    uint16_t details;

    do
    {
        if ((hmac_key_size < TA_CREATE_DETAILS_HMAC_MIN_LENGTH) || (hmac_key_size >
                                                                    TA_CREATE_DETAILS_HMAC_MAX_LENGTH))
        {
            status = ATCA_TRACE(ATCA_INVALID_SIZE, "Invalid hmac key size received");
            break;
        }

        details = (uint16_t)TA_CREATE_DETAILS_HMAC_KEY_LENGTH(hmac_key_size);

        status = talib_create(device, TA_CREATE_MODE_HANDLE_BY_VEGA, details, TA_HANDLE_SHARED_DATA,
                              handle_config, handle_out);

    }
    while (0);

    return status;
}

/** \brief TA API - Executes Create command to create HMAC symmetric elements on shared data memory
 *                  or volatile register. This cannot create Secure_boot special handles.
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  hmac_key_size  size of hmac symmetric key size
 *  \param[in]  handle_in      handle to use to create an element
 *  \param[in]  handle_config  Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create_hmac_element_with_handle(ATCADevice device, const size_t hmac_key_size,
                                                  const uint16_t handle_in, const
                                                  ta_element_attributes_t* handle_config)
{
    ATCA_STATUS status;
    uint16_t details;

    do
    {
        if ((hmac_key_size < TA_CREATE_DETAILS_HMAC_MIN_LENGTH) || (hmac_key_size >
                                                                    TA_CREATE_DETAILS_HMAC_MAX_LENGTH))
        {
            status = ATCA_TRACE(ATCA_INVALID_SIZE, "Invalid hmac key size received");
            break;
        }

        details = (uint16_t)TA_CREATE_DETAILS_HMAC_KEY_LENGTH(hmac_key_size);

        status = talib_create(device, TA_CREATE_MODE_HANDLE_BY_HOST, details, handle_in,
                              handle_config, NULL);

    }
    while (0);

    return status;
}

/** \brief TA-API Execute the create command to create handle by TA100 in linked shared data
 *
 *  \param[in]  device         Device context pointer
 *  \param[in]  details        Additional details for HMAC and Ephemeral elements
 *  \param[in]  handle_config  Attributes information for the element to be created.
 *                             Size must be 8 bytes
 *  \param[out] handle_out     handle created by TA100 is returned here
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_create_linked_shared_data(ATCADevice device, const uint16_t details, ta_element_attributes_t*
                                            handle_config, uint16_t* const handle_out)
{
    return talib_create(device, TA_CREATE_MODE_HANDLE_BY_VEGA, details, TA_HANDLE_LINKED_SHARED_DATA,
                        handle_config, handle_out);
}
