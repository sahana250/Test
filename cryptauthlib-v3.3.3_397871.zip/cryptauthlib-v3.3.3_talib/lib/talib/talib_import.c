/**
 * \file
 * \brief Basic Import commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes Import command to import the encrypted key/data blob into the handle.
 *                  The target handle should be created prior to this command and the value of its
 *                  attribute fields must match exactly that which is contained in the exported blob
 *                  with the exception of the link fields.
 *
 *  \param[in]  device      Device context pointer
 *  \param[in]  mode        either link keys are as per target handle or exported blob handle
 *  \param[in]  handle      Element handle where to import the data blob
 *  \param[in]  blob        Encrypted key/data blob
 *  \param[in]  blob_length Length of encrypted key/data blob
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_import_base(ATCADevice device, const uint8_t mode, const uint32_t handle, const
                              uint8_t* blob, const uint16_t blob_length)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    do
    {
        if ((NULL == device) || (NULL == blob))
        {
            status = ATCA_TRACE(ATCA_INVALID_POINTER, "NULL pointer received");
            break;
        }

        if ((blob_length < TA_IMPORT_BLOB_MIN_LEN) || (blob_length > TA_IMPORT_BLOB_MAX_LEN))
        {
            status = ATCA_TRACE(ATCA_INVALID_LENGTH, "Invalid Length received");
            break;
        }

        packet = talib_packet_alloc();
        if (packet == NULL)
        {
            status = ATCA_TRACE(ATCA_ALLOC_FAILURE, "");
            break;
        }

        packet->opcode = TA_OPCODE_IMPORT;
        packet->param1 = mode;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(handle);

        //Copy the blob into packet
        memcpy(packet->data, blob, blob_length);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(blob_length + ATCA_CMD_BUILD_MIN_LENGTH);

        if (ATCA_SUCCESS != (status = talib_execute_command(packet, device)))
        {
            status = ATCA_TRACE(status, "talib_import_base - Execution failed");
        }

        talib_packet_free(packet);
    }
    while (0);

    return status;
}

/** \brief TA API - Executes Import command to import the encrypted key/data blob into the handle.
 *                  The target handle should be created prior to this command and the value of its
 *                  attribute fields must match exactly that which is contained in the exported blob.
 *
 *  \param[in]  device      Device context pointer
 *  \param[in]  handle      Element handle where to import the data blob
 *  \param[in]  blob        Encrypted key/data blob
 *  \param[in]  blob_length Length of encrypted key/data blob
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_import_handle(ATCADevice device, const uint16_t handle, const uint8_t* blob, const
                                uint16_t blob_length)
{
    return talib_import_base(device, TA_IMPORT_MODE_LINKS_WITH_EXPORTED_BLOB, (uint32_t)handle,
                             blob, blob_length);
}

/** \brief TA API - Executes Import command to import the encrypted key/data blob into the handle.
 *                  The target handle should be created prior to this command and the value of its
 *                  attribute fields must match exactly that which is contained in the exported blob
 *                  with the exception of the link fields. Link keys are as per target handle
 *                  (where blob going to import)
 *
 *  \param[in]  device      Device context pointer
 *  \param[in]  handle      Element handle where to import the data blob
 *  \param[in]  blob        Encrypted key/data blob
 *  \param[in]  blob_length Length of encrypted key/data blob
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_import_handle_with_target_links(ATCADevice device, const uint16_t handle, const uint8_t*
                                                  blob, const uint16_t blob_length)
{
    return talib_import_base(device, TA_IMPORT_MODE_LINKS_WITH_TARGET_HANDLE, (uint32_t)handle, blob,
                             blob_length);
}
