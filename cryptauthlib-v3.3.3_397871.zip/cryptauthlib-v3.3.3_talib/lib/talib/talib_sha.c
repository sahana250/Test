/**
 * \file
 * \brief Basic SHA commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Executes SHA command, which computes a SHA-256 digest
 *                  for general purpose use by the host system.
 *
 * \param[in]    device         Device context pointer
 * \param[in]    mode           SHA command mode Start(0), Update/Compute(1),
 *                              Finalize(2) or Entire message is in IO buffer(3).
 * \param[in]    length         Number of bytes in the input stream
 * \param[in]    context_handle Target handle to write digest or
 *                                  SHA context handle of prior calculation
 * \param[in]    message        Data bytes to be hashed
 * \param[out]   data_out       Data returned by the command (digest or context).
 * \param[in,out] data_out_size  As input, the size of the data_out buffer. As
 *                              output, the number of bytes returned in data_out.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_base(ATCADevice device, const uint8_t mode, const uint16_t length, const
                           uint16_t context_handle, const uint8_t* message, uint8_t* const data_out,
                           uint16_t* const data_out_size)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;
    uint8_t *data;

    if (NULL == device || length > TA_SHA_MAX_MSG_LEN || (data_out && !data_out_size))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "Either NULL pointer or invalid length received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_SHA;
        packet->param1 = mode;
        packet->param2.val16[0] = ATCA_UINT16_HOST_TO_BE(length);
        packet->param2.val16[1] = ATCA_UINT16_HOST_TO_BE(context_handle);

        data = packet->data;
        if (message)
        {
            memcpy(data, message, length);
            data += length;
        }

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE((uint16_t)(data - packet->data) +
                                                ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;
            uint16_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

            if (data_out && rsp_length)
            {
                if (*data_out_size < rsp_length)
                {
                    status = ATCA_TRACE(ATCA_SMALL_BUFFER, "Small buffer received");
                }
                else
                {
                    memcpy(data_out, resp_packet->data, *data_out_size);
                }
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Executes SHA command, which computes a SHA-256 digest
 *                  for general purpose use by the host system.
 *
 * \param[in]    device         Device context pointer
 * \param[in]    mode           SHA command mode Start(0), Update/Compute(1),
 *                              Finalize(2) or Entire message is in IO buffer(3).
 * \param[in]    length         Number of bytes in the input stream
 * \param[in]    message        Data bytes to be hashed
 * \param[out]   digest         Data returned by the command (digest or context).
 * \param[in,out] digest_size  As input, the size of the data_out buffer. As
 *                              output, the number of bytes returned in data_out.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_base_compat(ATCADevice device, uint8_t mode, const uint16_t length,
                                  const uint8_t* message, uint8_t* const digest, uint16_t* const
                                  digest_size)
{
    ATCA_STATUS status;

    // Only start, update and end mode supported
    mode &= 0x03;
    do
    {
        if ((TA_SHA_MODE_START == mode) || (TA_SHA_MODE_UPDATE == mode) || (TA_SHA_MODE_END == mode))
        {
            if (ATCA_SUCCESS != (status = talib_sha_base(device, mode, length, TA_HANDLE_SHA_CONTEXT0,
                                                         message, digest, digest_size)))
            {
                ATCA_TRACE(status, "talib_sha_base_compat - Execution failed");
                break;
            }
        }
        else
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "Invalid mode received");
            break;
        }
    }
    while (0);

    return status;
}

/** \brief Executes SHA command to initialize SHA-256 calculation engine
 *  \param[in]  device          Device context pointer
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_start(ATCADevice device)
{
    return talib_sha_base(device, TA_SHA_MODE_START, 0, TA_HANDLE_SHA_CONTEXT0, NULL,
                          NULL, NULL);
}

/** \brief Executes SHA command to initialize SHA-256 calculation engine
 *
 *  \param[in]  device         Device context pointer
 *  \param[in] context_handle  SHA context handle of prior calculation
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_start_with_handle(ATCADevice device, const uint16_t context_handle)
{
    return talib_sha_base(device, TA_SHA_MODE_START, 0, context_handle, NULL, NULL, NULL);
}

/** \brief Executes SHA command to add message data to the current context.
 *
 * \param[in] device          Device context pointer
 * \param[in] message_length  length of input message for SHA operation
 * \param[in] message         message data to add to SHA operation.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_update(ATCADevice device, const uint16_t message_length, const uint8_t
                             *message)
{
    return talib_sha_base(device, TA_SHA_MODE_UPDATE, message_length,
                          TA_HANDLE_SHA_CONTEXT0, message, NULL, NULL);
}

/** \brief Executes SHA command to add message data to the current context.
 *
 * \param[in] device          Device context pointer
 * \param[in] context_handle  SHA context handle of prior calculation
 * \param[in] message_length  length of input message for SHA operation
 * \param[in] message         message data to add to SHA operation.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_update_with_handle(ATCADevice device, const uint16_t context_handle, const
                                         uint16_t message_length, const uint8_t *message)
{
    return talib_sha_base(device, TA_SHA_MODE_UPDATE, message_length, context_handle, message,
                          NULL, NULL);
}

/** \brief Executes SHA command to add message data to the current context.
 *         (compatibility function)
 * \param[in] device         Device context pointer
 * \param[in] message         message data to add to SHA operation.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_update_compat(ATCADevice device, const uint8_t* message)
{
    return talib_sha_update(device, 64, message);
}

/** \brief Executes SHA command to finalize SHA-256 calculation engine
 *
 *  \param[in]  device         Device context pointer
 *  \param[out] digest         Digest is returned here (32 bytes).
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_end(ATCADevice device, uint8_t* digest)
{
    const uint16_t digest_size = TA_SHA256_DIGEST_SIZE;

    return talib_sha_base(device, TA_SHA_MODE_END, 0, TA_HANDLE_SHA_CONTEXT0, NULL,
                          digest, (uint16_t*)&digest_size);
}

/** \brief Executes SHA command to finalize SHA-256 calculation engine
 *
 *  \param[in]  device         Device context pointer
 *  \param[in] context_handle  SHA context handle of prior calculation
 *  \param[out] digest         Digest is returned here (32 bytes).
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_end_with_handle(ATCADevice device, const uint16_t context_handle, uint8_t*
                                      digest)
{
    const uint16_t digest_size = TA_SHA256_DIGEST_SIZE;

    return talib_sha_base(device, TA_SHA_MODE_DIGEST_TO_CONTEXT | TA_SHA_MODE_END, 0,
                          context_handle, NULL, digest, (uint16_t*)&digest_size);
}

/** \brief Executes SHA command to finalize SHA-256 calculation engine
 *
 *  \param[in]  device         Device context pointer
 *  \param[out] digest         Digest is returned here (32 bytes).
 *  \param[in]  length         input message length to update the context
 *  \param[in]  message        message to compute SHA
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_end_compat(ATCADevice device, uint8_t *digest, uint16_t length, const
                                 uint8_t* message)
{
    ATCA_STATUS status;

    do
    {
        if (NULL != message)
        {
            if (ATCA_SUCCESS != (status = talib_sha_update(device, length, message)))
            {
                ATCA_TRACE(status, "talib_sha_update - Execution failed");
                break;
            }
        }

        if (ATCA_SUCCESS != (status = talib_sha_end_with_handle(device, TA_HANDLE_SHA_CONTEXT0,
                                                                digest)))
        {
            ATCA_TRACE(status, "talib_sha_end - Execution failed");
            break;
        }
    }
    while (0);

    return status;
}

/** \brief Use the SHA command to compute a SHA-256 digest for given message in input stream
 *
 * \param[in]  device   Device context pointer
 * \param[in]  length   Size of message parameter in bytes.
 * \param[in]  message  Message data to be hashed.
 * \param[out] digest   Digest is returned here (32 bytes).
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha(ATCADevice device, const uint16_t length, const uint8_t* message, uint8_t digest[TA_SHA256_DIGEST_SIZE])
{
    const uint16_t digest_size = TA_SHA256_DIGEST_SIZE;
    ATCA_STATUS status = ATCA_EXECUTION_ERROR;

    do
    {
        if (length)
        {
            if (ATCA_SUCCESS != (status = talib_sha_base(device, TA_SHA_MODE_ENTIRE_MSG, length, 0, message, digest,
                                                         (uint16_t*)&digest_size)))
            {
                ATCA_TRACE(status, "sha failed");
                break;
            }
        }
        else
        {
            if (ATCA_SUCCESS != (status = talib_sha_start(device)))
            {
                ATCA_TRACE(status, "sha failed");
                break;
            }

            if (ATCA_SUCCESS != (status = talib_sha_end(device, digest)))
            {
                ATCA_TRACE(status, "sha failed");
                break;
            }

        }
    }
    while (0);

    return status;
}

/** \brief Use the SHA command to compute a SHA-256 digest for given message in input stream
 *
 * \param[in]  device         Device context pointer
 * \param[in] context_handle  Target to write the digest
 * \param[in]  length         Size of message parameter in bytes.
 * \param[in]  message        Message data to be hashed.
 * \param[out] digest         Digest is returned here (32 bytes).
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_with_handle(ATCADevice device, const uint16_t context_handle, const uint16_t
                                  length, const uint8_t* message, uint8_t* const digest)
{
    const uint16_t digest_size = TA_SHA256_DIGEST_SIZE;

    return talib_sha_base(device, TA_SHA_MODE_DIGEST_TO_CONTEXT | TA_SHA_MODE_ENTIRE_MSG,
                          length, context_handle, message, digest, (uint16_t*)&digest_size);
}

///** \brief Initialize a SHA context for performing a hardware SHA-256 operation
// *          on a device. Note that only one SHA operation can be run at a time.
// *
// * \param[in] ctx  SHA256 context
// *
// *  \return ATCA_SUCCESS on success, otherwise an error code.
// */
//ATCA_STATUS talib_hw_sha2_256_init(ATCADevice device, atca_sha256_ctx_t* ctx)
//{
//    memset(ctx, 0, sizeof(*ctx));
//    return talib_sha_start(device);
//}
//
///** \brief Add message data to a SHA context for performing a hardware SHA-256
// *          operation on a device.
// *
// * \param[in] ctx        SHA256 context
// * \param[in] data       Message data to be added to hash.
// * \param[in] data_size  Size of data in bytes.
// *
// *  \return ATCA_SUCCESS on success, otherwise an error code.
// */
//ATCA_STATUS talib_hw_sha2_256_update(ATCADevice device, atca_sha256_ctx_t* ctx, const uint8_t* data,
// size_t data_size)
//{
//    ATCA_STATUS status = ATCA_SUCCESS;
//    uint32_t block_count;
//    uint32_t rem_size = ATCA_SHA256_BLOCK_SIZE - ctx->block_size;
//    uint32_t copy_size = data_size > rem_size ? rem_size : (uint32_t)data_size;
//    uint32_t i;
//
//    // Copy data into current block
//    memcpy(&ctx->block[ctx->block_size], data, copy_size);
//
//    if (ctx->block_size + data_size < ATCA_SHA256_BLOCK_SIZE)
//    {
//        // Not enough data to finish off the current block
//        ctx->block_size += (uint32_t)data_size;
//        return ATCA_SUCCESS;
//    }
//
//    // Process the current block
//    status = talib_sha_update(device, 64, ctx->block);
//    if (status != ATCA_SUCCESS)
//    {
//        return status;
//    }
//
//    // Process any additional blocks
//    data_size -= copy_size; // Adjust to the remaining message bytes
//    block_count = (uint32_t)(data_size / ATCA_SHA256_BLOCK_SIZE);
//    for (i = 0; i < block_count; i++)
//    {
//        status = talib_sha_update(device, 64, &data[copy_size + i * ATCA_SHA256_BLOCK_SIZE]);
//        if (status != ATCA_SUCCESS)
//        {
//            return status;
//        }
//    }
//
//    // Save any remaining data
//    ctx->total_msg_size += (block_count + 1) * ATCA_SHA256_BLOCK_SIZE;
//    ctx->block_size = data_size % ATCA_SHA256_BLOCK_SIZE;
//    memcpy(ctx->block, &data[copy_size + block_count * ATCA_SHA256_BLOCK_SIZE], ctx->block_size);
//
//    return ATCA_SUCCESS;
//}
//
///** \brief Finish SHA-256 digest for a SHA context for performing a hardware
// *          SHA-256 operation on a device.
// *
// * \param[in]  ctx     SHA256 context
// * \param[out] digest  SHA256 digest is returned here (32 bytes)
// *
// *  \return ATCA_SUCCESS on success, otherwise an error code.
// */
//ATCA_STATUS talib_hw_sha2_256_finish(ATCADevice device, atca_sha256_ctx_t* ctx, uint8_t* digest)
//{
//    ATCA_STATUS status;
//
//    do
//    {
//        if(ctx->block_size > 0)
//        {
//            if(ATCA_SUCCESS != (status = talib_sha_update(device, ctx->block_size, ctx->block)))
//                BREAK(status, "talib_sha_update - Execution failed")
//        }
//
//        if(ATCA_SUCCESS != (status = talib_sha_end(device, digest)))
//            BREAK(status, "talib_sha_end - Execution failed")
//
//    } while (0);
//
//    return status;
//}
//
///** \brief Use the SHA command to compute a SHA-256 digest.
// *
// * \param[in]  data       Message data to be hashed.
// * \param[in]  data_size  Size of data in bytes.
// * \param[out] digest     Digest is returned here (32 bytes).
// *
// * \return ATCA_SUCCESS on success, otherwise an error code.
// */
//ATCA_STATUS talib_hw_sha2_256(ATCADevice device, const uint8_t * data, size_t data_size, uint8_t*
//digest)
//{
//    ATCA_STATUS status = ATCA_SUCCESS;
//    atca_sha256_ctx_t ctx;
//
//    do
//    {
//        if (ATCA_SUCCESS != (status = talib_hw_sha2_256_init(device, &ctx)))
//            BREAK(status, "talib_sha_start - Execution failed")
//
//        if (ATCA_SUCCESS != (status = talib_hw_sha2_256_update(device, &ctx, data, data_size)))
//            BREAK(status, "talib_sha_update - Execution failed")
//
//        if (ATCA_SUCCESS != (status = talib_hw_sha2_256_finish(device, &ctx, digest)))
//            BREAK(status, "talib_sha_end - Execution failed")
//
//    } while (0);
//
//    return status;
//}

/** \brief Executes Read command to read the SHA-256 context from SHA Context0 handle
 *
 *  \param[in]     device            Device context pointer
 *  \param[out]    context           Context data is returned here.
 *  \param[in,out] context_size      As input, the size of the context buffer in
 *                                   bytes. As output, the size of the returned
 *                                   context data.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_read_context(ATCADevice device, uint8_t* const context, uint16_t* const
                                   context_size)
{
    ATCA_STATUS status;

    do
    {
        if (NULL == context)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        status = talib_read_element(device, TA_HANDLE_SHA_CONTEXT0, context_size, context);

    }
    while (0);

    return status;
}

/** \brief Executes Read command to read the SHA-256 context from given input handle
 *
 *
 *  \param[in]    device            Device context pointer
 *  \param[in]    context_handle    SHA context handle of prior calculation
 *  \param[out]   context           Context data is returned here.
 *  \param[in,out] context_size      As input, the size of the context buffer in
 *                                  bytes. As output, the size of the returned
 *                                  context data.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_read_context_with_handle(ATCADevice device, const uint16_t context_handle,
                                               uint8_t* const context, uint16_t* const context_size)
{
    ATCA_STATUS status;

    do
    {
        if (NULL == context)
        {
            status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
            break;
        }

        status = talib_read_element(device, context_handle, context_size, context);

    }
    while (0);

    return status;
}


/** \brief Executes SHA command to write (restore) a SHA-256 context into the
 *         the device SHA context0 handle.
 *
 *  \param[in] device           Device context pointer
 *  \param[in] context          Context data to be restored.
 *  \param[in] context_size     Size of the context data in bytes.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_write_context(ATCADevice device, const uint8_t* context, const uint16_t
                                    context_size)
{
    return talib_write_element(device, TA_HANDLE_SHA_CONTEXT0, context_size, context);
}

/** \brief Executes SHA command to write (restore) a SHA-256 context into the
 *         the device in given input handle.
 *
 *  \param[in] device           Device context pointer
 *  \param[in] context_handle   SHA context handle of prior calculation
 *  \param[in] context          Context data to be restored.
 *  \param[in] context_size     Size of the context data in bytes.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_sha_write_context_with_handle(ATCADevice device, const uint16_t context_handle,
                                                const uint8_t* context, const uint16_t context_size)
{
    return talib_write_element(device, context_handle, context_size, context);
}
