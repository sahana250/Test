/**
 * \file
 * \brief Basic KeyGen commands for Trust Anchor Devices.
 *
 * \note List of devices that support this command - TA100.
 *       There are differences in the modes that they support.
 *       Refer to device datasheets for full details.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#include "talib_basic.h"

/** \brief TA API - Issues GenKey command, which generates a new random key in
 *         handle and returns the public key if applicable.
 *
 * \param[in]     device       Device context pointer
 * \param[in]     mode         Mode determines what operations the GenKey command performs
 * \param[in]     key_handle   Handle for a Symmetric or private key
 * \param[out]    public_key   Public key will be returned here. Format will be
 *                             the X and Y integers in big-endian format.
 *                             Length depends on the Key attributes. Set to NULL if public key
 *                             isn't required.
 * \param[in,out] pubkey_len   As input, expected public key length
 *                             As output, public key length received from device.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_genkey_base(ATCADevice device, const uint8_t mode, const uint32_t key_handle,
                              uint8_t* const public_key, size_t * pubkey_len)
{
    ATCA_STATUS status;
    ATCA_TA_CmdPacket* packet = NULL;

    if (NULL == device || (public_key && !pubkey_len))
    {
        status = ATCA_TRACE(ATCA_BAD_PARAM, "NULL pointer received");
    }
    else
    {
        packet = talib_packet_alloc();
        status = ATCA_TRACE(packet ? ATCA_SUCCESS : ATCA_ALLOC_FAILURE, "");
    }

    if (packet)
    {
        packet->opcode = TA_OPCODE_KEYGEN;
        packet->param1 = mode;
        packet->param2.val32 = ATCA_UINT32_HOST_TO_BE(key_handle);

        //Update length including length, opcode, param1, param2 and CRC
        packet->length = ATCA_UINT16_HOST_TO_BE(ATCA_CMD_BUILD_MIN_LENGTH);

        status = ATCA_TRACE(talib_execute_command(packet, device), "");

        if (ATCA_SUCCESS == status)
        {
            ATCA_TA_RspPacket* resp_packet = (ATCA_TA_RspPacket*)packet;

            if (public_key)
            {
                uint16_t rsp_length = ATCA_UINT16_BE_TO_HOST(resp_packet->length) - ATCA_CMD_PARSE_MIN_LENGTH;

                if (*pubkey_len < rsp_length)
                {
                    status = ATCA_TRACE(ATCA_SMALL_BUFFER, "Small buffer received");
                }
                else
                {
                    *pubkey_len = rsp_length;
                    memcpy(public_key, resp_packet->data, *pubkey_len);
                }
            }
        }
        talib_packet_free(packet);
    }

    return status;
}

/** \brief TA API - Issues GenKey command, which generates a new random key in
 *         handle and returns the public key if applicable.
 *
 * \param[in]     device        Device context pointer
 * \param[in]     key_handle    Handle for a Symmetric or private key
 * \param[out]    public_key    Public key will be returned here. Format will be
 *                              the X and Y integers in big-endian format.
 *                              Length depends on the Key attributes. Set to NULL if public key
 *                              isn't required.
 * \param[in,out] pubkey_len    As input, expected public key length
 *                              As output, public key length received from device.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_genkey(ATCADevice device, const uint16_t key_handle, uint8_t* const public_key,
                         size_t* pubkey_len)
{
    return talib_genkey_base(device, TA_KEYGEN_MODE_NEWKEY, key_handle, public_key, pubkey_len);
}

/** \brief Issue Keygen command, which generates a new random ECCP256 private key in
 *         handle and returns the public key.
 *
 * \param[in]  device      Device context pointer
 * \param[in]  key_handle  Handle of a private key.
 * \param[out] public_key  Public key will be returned here. Format will be
 *                         the X and Y integers in big-endian format.
 *                         64 bytes for P256 curve. Set to NULL if public key
 *                         isn't required.
 *
 * \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_genkey_compat(ATCADevice device, const uint16_t key_handle, uint8_t public_key[64])
{
    size_t pubkey_len = 64;
    ATCA_STATUS status;
    uint8_t handle_info[TA_HANDLE_INFO_SIZE];

    status = talib_info_get_handle_info(device, key_handle, handle_info);

    if ((ATCA_SUCCESS == status) && (handle_info[8] == 1))
    {
        status = talib_delete_handle(device, key_handle);

        if (ATCA_SUCCESS == status)
        {
            status = talib_create_element_with_handle(device, key_handle, (ta_element_attributes_t*)handle_info);
        }
    }

    if (ATCA_SUCCESS == status)
    {
        status = talib_genkey_base(device, TA_KEYGEN_MODE_NEWKEY, key_handle, public_key, &pubkey_len);
    }

    return status;
}

/** \brief Uses GenKey command to calculate the public key from an existing
 *         ECCP256 private key in a handle.
 *
 *  \param[in]  device      Device context pointer
 *  \param[in]  key_handle  Handle of a private key.
 *  \param[out] public_key  Public key will be returned here. Format will be
 *                          the X and Y integers in big-endian format.
 *                          64 bytes for P256 curve. Set to NULL if public key
 *                          isn't required.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_get_pubkey_compat(ATCADevice device, const uint16_t key_handle, uint8_t public_key[64])
{
    size_t pubkey_len = 64;

    return talib_genkey_base(device, TA_KEYGEN_MODE_PUBKEY, key_handle, public_key, &pubkey_len);
}

/** \brief Uses GenKey command to calculate the public key from an existing
 *         private key in a handle.
 *
 *  \param[in]     device       Device context pointer
 *  \param[in]     key_handle   Handle of a private key.
 *  \param[out]    public_key   Public key will be returned here.
 *  \param[in,out] pubkey_len   As input, expected public key length
 *                              As output, public key length received from device.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_get_pubkey(ATCADevice device, const uint16_t key_handle, uint8_t* const public_key,
                             size_t* pubkey_len)
{
    return talib_genkey_base(device, TA_KEYGEN_MODE_PUBKEY, key_handle, public_key, pubkey_len);
}

/** \brief Uses GenKey command to calculate the symmetric key and load into given handle.
 *
 *  \param[in]  device      Device context pointer
 *  \param[in]  key_handle  generated symmetric key write into handle.
 *
 *  \return ATCA_SUCCESS on success, otherwise an error code.
 */
ATCA_STATUS talib_genkey_symmetric_key(ATCADevice device, const uint16_t key_handle)
{
    return talib_genkey_base(device, TA_KEYGEN_MODE_NEWKEY, key_handle, NULL, NULL);
}
