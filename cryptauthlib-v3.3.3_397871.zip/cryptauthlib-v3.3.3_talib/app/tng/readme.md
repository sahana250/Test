# TNG Functions

This folder has a number of convenience functions for working with TNG devices
(currently ATECC608A-MAHTN-T).

These devices have standard certificates that can be easily read using the
functions in tng_atcacert_client.h

@ingroup tng_
