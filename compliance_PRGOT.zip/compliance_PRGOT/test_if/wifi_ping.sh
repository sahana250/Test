HOSTIP=`ifconfig mlan0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`

echo "$HOSTIP"
while [ 1 ];
do
	if ping -q -c 1 -W 1 192.168.43.1 >/dev/null; 
	then
	  echo "WiFi is up"
	  break
	else
	  echo "WiFi IP address not assigned"
	  sleep 1
	fi
done

ping -I mlan0 192.168.43.1 &
