#!/bin/sh
while [ 1 ];
do
	hcitool scan
	sleep 1

	echo -e "\n\n"
done
