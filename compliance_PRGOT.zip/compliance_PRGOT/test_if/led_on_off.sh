#!/bin/sh

while [ 1 ];
do
	echo "LED ON !!!!!!!!!!!!!!!!!!!!!!!"
	echo 1 > /sys/class/gpio/gpio107/value
	sleep 1
	echo "LED OFF !!!!!!!!!!!!!!!!!!!!!!"
	echo 0 > /sys/class/gpio/gpio107/value
	sleep 1

	echo -e "\n\n"
done
