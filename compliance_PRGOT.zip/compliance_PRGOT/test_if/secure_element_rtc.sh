while [ 1 ];
do
	i2cdetect -y 3
	sleep 2
done
