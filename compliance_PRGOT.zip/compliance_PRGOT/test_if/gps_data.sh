#!/bin/sh
sleep 3

while [ 1 ];
do
	sleep 1
	echo "GPS !!!!!!!!!!!!!!!!!!!!!!!!!!"
	cat /dev/ttyUSB1

	echo -e "\n\n"
done
