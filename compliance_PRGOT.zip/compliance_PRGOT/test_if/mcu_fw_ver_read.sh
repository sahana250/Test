#!/bin/sh
while [ 1 ];
do
	ver=$(echo y | i2ctransfer -fy 0 w10@0x76 0xB0 0x03 0x00 0x00 0x0 0x0 0x0 0x0 0x0 0x0 r10)
	a=$(echo $ver | awk '{print $7}')
	b=$(echo $ver | awk '{print $8}')

	prefix="0x0"
	foo=${a#"$prefix"}
	a=$foo
	foo=${b#"$prefix"}
	b=$foo

	printf 'MCU Firmware Version is \"iW-PRGST-SC-R1.0-REL%d.%d_MCU_FW\"\n\n' $a $b
	sleep 1
done
