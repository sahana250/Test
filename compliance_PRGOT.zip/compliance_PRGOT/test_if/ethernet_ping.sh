ping -I eth0 192.168.1.12 &
