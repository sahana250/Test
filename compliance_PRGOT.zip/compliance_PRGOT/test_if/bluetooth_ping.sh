HOSTIP=`hcitool scan | grep 'prgst_pre_compliance' | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}'`
echo "$HOSTIP"

l2ping $HOSTIP
