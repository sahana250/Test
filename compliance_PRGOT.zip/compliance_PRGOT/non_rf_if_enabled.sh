# Exporting the GPIOs used
cd init
./export.sh

# Initialization of All Interfaces
./can_init.sh
./ethernet_init.sh
cd ../

# Enabling All Interfaces
cd test_if
./led_on_off.sh &
./ethernet_ping.sh &
./battery_status.sh &
./mcu_fw_ver_read.sh &
./secure_element_rtc.sh &
./sensor_test
cd ../
