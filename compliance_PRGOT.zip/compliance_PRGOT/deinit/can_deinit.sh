killall -9 can_send.sh
killall -9 cansend
killall -9 candump

ifconfig can0 down
ifconfig can1 down
ifconfig can2 down

modprobe -r tcan4x5x
