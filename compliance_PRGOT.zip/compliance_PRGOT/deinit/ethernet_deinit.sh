ifconfig eth0 down
