ifconfig ppp0 down
killall -9 pppd

echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 1 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 5

echo 0 > /sys/class/gpio/gpio90/value
echo 0 > /sys/class/gpio/gpio78/value
