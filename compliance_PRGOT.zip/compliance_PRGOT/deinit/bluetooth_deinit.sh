killall -9 bluetooth_ping.sh
killall -9 bluetooth_scan.sh
killall -9 l2ping
killall -9 hciattach

echo 0 > /sys/class/gpio/gpio133/value
sleep 1
