#!/bin/sh
modprobe moal mod_para=nxp/wifi_mod_para.conf	
sleep 1

hostapd /etc/hostapd.conf -B
ifconfig uap0 192.168.43.1
udhcpd

echo 1 > /proc/sys/net/ipv4/ip_forward
sleep 1
iptables -t nat -A POSTROUTING -o ppp0 -j MASQUERADE
sleep 1
iptables -A FORWARD -i ppp0 -o uap0 -m state --state RELATED,ESTABLISHED -j ACCEPT
sleep 1
iptables -A FORWARD -i uap0 -o ppp0 -j ACCEPT
sleep 1
iptables -t nat -S
