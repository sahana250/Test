#!/bin/sh
insmod /home/root/tcan4x5x.ko
sleep 1
ip link set can0 up type can bitrate 250000
sleep 1
ip link set can1 up type can bitrate 250000
sleep 1
ip link set can2 up type can bitrate 250000
sleep 1
ip link set can3 up txqlen 25000 type can bitrate 250000 dbitrate 1000000 fd on
sleep 1
ip link set can4 up txqlen 25000 type can bitrate 250000 dbitrate 1000000 fd on 
