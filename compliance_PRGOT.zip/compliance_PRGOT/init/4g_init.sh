#!/bin/sh

echo 0 > /sys/class/gpio/gpio137/value
echo 1 > /sys/class/gpio/gpio90/value
echo 1 > /sys/class/gpio/gpio78/value

echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 1 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value

while [ 1 ]
do
        if [ -e "/dev/ttyUSB3" ]; then
                break
        fi
        sleep 1
done

