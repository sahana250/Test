#!/bin/sh
modprobe moal mod_para=nxp/wifi_mod_para.conf
sleep 1
hciattach /dev/ttyLP1 any 3000000 flow
sleep 1
hciconfig hci0 up piscan
sleep 1
hcitool dev
sleep 1
hcitool scan
sleep 1
hcitool info 
