WIFI_CONF_PATH=test_if/wifi_conf

modprobe moal mod_para=nxp/wifi_mod_para.conf	
sleep 1

wpa_supplicant -B -Dnl80211 -c $WIFI_CONF_PATH/wpa_supplicant.conf -i mlan0
ifconfig mlan0 192.168.43.1
udhcpc -i mlan0 &

