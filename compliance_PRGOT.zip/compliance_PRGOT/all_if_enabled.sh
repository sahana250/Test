# Exporting the GPIOs used
#cd init
./init/export.sh

# Initialization of All Interfaces
./init/4g_init.sh
./init/bluetooth_init.sh
./init/can_init.sh
./init/ethernet_init.sh
./init/gps_init.sh
./init/wifi_station_init.sh
#cd ../

# Enabling All Interfaces
cd test_if
./led_on_off.sh &
./4g_ping.sh &
./ethernet_ping.sh &
./battery_status.sh &
./bluetooth_ping.sh &
./wifi_ping.sh &     
./gps_data.sh &
./mcu_fw_ver_read.sh &
./can_send &
./secure_element_rtc.sh &
./sensor_test
cd ../
