# Deinitialization of Cellular & GNSS
cd deinit
./gps_deinit.sh
./4g_deinit.sh

# Unexporting the GPIOs used
./unexport.sh
cd ../

killall sh
