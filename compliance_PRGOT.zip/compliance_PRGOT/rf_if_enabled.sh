# Exporting the GPIOs used
cd init
./export.sh

# Initialization of All Interfaces
./4g_init.sh
./gps_init.sh
./bluetooth_init.sh
./wifi_station_init.sh
cd ../

# Enabling All Interfaces
cd test_if
./4g_ping.sh &
./gps_data.sh &
./bluetooth_ping.sh &
./wifi_ping.sh &     
cd ../
