# 12V Register
echo 137 > /sys/class/gpio/unexport

# Battery Status
echo 118 > /sys/class/gpio/unexport

# Battery Charge Enable
echo 120 > /sys/class/gpio/unexport

# LED
echo 0 > /sys/class/gpio/gpio73/value
echo 73 > /sys/class/gpio/unexport

# Battery Power Good
echo 64 > /sys/class/gpio/unexport

# Modem
echo 90 > /sys/class/gpio/unexport
echo 78 > /sys/class/gpio/unexport
echo 88 > /sys/class/gpio/unexport

# GNSS
echo 86 > /sys/class/gpio/unexport

# Bluetooth
echo 133 > /sys/class/gpio/unexport
