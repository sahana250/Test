killall gps_data.sh
echo -ne "at+qgps=0" >/dev/ttyUSB2
