killall -9 wifi_scan.sh
killall -9 wifi_ping.sh
ifconfig wlan0 down
killall -9 udhcpd
killall -9 hostapd
killall -9 udhcpc
killall -9 wpa_supplicant

modprobe -r brcmfmac
