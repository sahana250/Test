#!/bin/sh

while [ 1 ]
do
	echo ""
	bat_raw_val=`cat /sys/bus/iio/devices/iio:device0/in_voltage5_raw`
	bat_volt=$( awk "BEGIN { print ($bat_raw_val*3300/4096/1000*1.5)}" )
	echo "Battery ADC Voltage is $bat_volt V"

	adc_raw_val=`cat /sys/bus/iio/devices/iio:device0/in_voltage1_raw`
	adc_volt=$( awk "BEGIN { print ($adc_raw_val*0.005575)}" )
	echo "12V ADC Voltage is $adc_volt V"

	echo ""
	sleep 1
done
