#!/bin/sh
while [ 1 ];
do
	iw dev wlan0 scan | grep "SSID:"
	sleep 1

	echo -e "\n\n"
done
