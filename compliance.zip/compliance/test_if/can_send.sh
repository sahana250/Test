#!/bin/sh
while [ 1 ];
do
	cansend can0 7e0#02010C0000000000
	cansend can1 7e1#02010C0000000000
	cansend can2 7e2#02010C0000000000

	sleep 1
done 
