#!/bin/sh
sleep 3

while [ 1 ]
do
	if [ -e "/dev/ttyUSB2" ]; then
		echo -ne "at+qgps=1\r\n" >/dev/ttyUSB2
		break
	fi

	sleep 1
done
