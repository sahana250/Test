# 12V Register
echo 137 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio137/direction

# Battery Status
echo 118 > /sys/class/gpio/export
echo in > /sys/class/gpio/gpio118/direction

# Battery Charge Enable
echo 120 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio120/direction

# LED
echo 73 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio73/direction

# Battery Power Good
echo 64 > /sys/class/gpio/export
echo in > /sys/class/gpio/gpio64/direction

# Modem
echo 90 > /sys/class/gpio/export
echo 78 > /sys/class/gpio/export
echo 88 > /sys/class/gpio/export

echo out > /sys/class/gpio/gpio90/direction
echo out > /sys/class/gpio/gpio78/direction
echo out > /sys/class/gpio/gpio88/direction

# GNSS
echo 86 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio86/direction

# Bluetooth
echo 133 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio133/direction
