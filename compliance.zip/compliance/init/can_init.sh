#!/bin/sh
modprobe tcan4x5x
sleep 1

ip link set can0 up type can bitrate 250000
sleep 1
ip link set can1 up type can bitrate 250000
sleep 1
ip link set can2 up txqlen 25000 type can bitrate 250000 dbitrate 1000000 fd on
sleep 1

candump can0 &
candump can1 &
candump can2 &
