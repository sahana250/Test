ifconfig eth0 down
ifconfig eth0 192.168.1.10 up
