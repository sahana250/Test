#!/bin/sh
modprobe brcmfmac
sleep 1
ifconfig wlan0 up
