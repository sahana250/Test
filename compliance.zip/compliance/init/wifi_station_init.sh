WIFI_CONF_PATH=test_if/wifi_conf

modprobe brcmfmac
sleep 1

wpa_supplicant -B -Dnl80211 -c $WIFI_CONF_PATH/wpa_supplicant.conf -i wlan0
ifconfig wlan0 192.168.43.1
udhcpc -i wlan0 &

echo 1 > /proc/sys/net/ipv4/ip_forward
iptables -t nat -A POSTROUTING -o ppp0 -j MASQUERADE
iptables -A FORWARD -i ppp0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i wlan0 -o ppp0 -j ACCEPT
iptables -t nat -S
