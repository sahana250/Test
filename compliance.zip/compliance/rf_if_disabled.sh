# Deinitialization of All interfaces
cd deinit
./gps_deinit.sh
./4g_deinit.sh
./bluetooth_deinit.sh
./wifi_deinit.sh

# Unexport all the GPIOs
./unexport.sh
cd ../

killall sh
