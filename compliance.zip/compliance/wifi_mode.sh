#!/bin/sh  

WIFI_CONF_PATH=test_if/wifi_conf
WIFI_HOST_PATH=/etc/hostapd.conf
WIFI_STA_PATH=/etc/wpa_supplicant.conf

ifconfig wlan0 down
killall -9 udhcpd
killall -9 hostapd
killall -9 udhcpc
killall -9 wpa_supplicant

echo "Enter the option"  
echo -e "\t1. WiFi 2.4 GHz Mode"
echo -e "\t2. WiFi 5 GHz Mode"
echo -e "\t3. WiFi Scan Mode"
echo -e "\t4. WiFi Ping Mode"

read wifi_mode

if [ $wifi_mode == 1 ]; then
	echo "Enable WiFi HotSpot in 2.4 GHz Mode"
	hostapd $WIFI_CONF_PATH/hostapd_2g.conf -B
	ifconfig wlan0 192.168.43.1
	udhcpd

	echo 1 > /proc/sys/net/ipv4/ip_forward
	iptables -t nat -A POSTROUTING -o ppp0 -j MASQUERADE
	iptables -A FORWARD -i ppp0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
	iptables -A FORWARD -i wlan0 -o ppp0 -j ACCEPT
	iptables -t nat -S

elif [ $wifi_mode == 2 ]; then
	echo "Enable WiFi HotSpot in 5 GHz Mode"
	hostapd $WIFI_CONF_PATH/hostapd_5g.conf -B

	ifconfig wlan0 192.168.43.1
	udhcpd

	echo 1 > /proc/sys/net/ipv4/ip_forward
	iptables -t nat -A POSTROUTING -o ppp0 -j MASQUERADE
	iptables -A FORWARD -i ppp0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
	iptables -A FORWARD -i wlan0 -o ppp0 -j ACCEPT
	iptables -t nat -S

elif [ $wifi_mode == 3 ]; then
	echo "Enable WiFi in Scan Mode"
	sh init/wifi_init.sh
	sh test_if/wifi_scan.sh &

elif [ $wifi_mode == 4 ]; then
	echo "Enable WiFi in Ping Mode"
	sh init/wifi_station_init.sh
	sh test_if/wifi_ping.sh &

else
	echo "Enter valid input"

fi
