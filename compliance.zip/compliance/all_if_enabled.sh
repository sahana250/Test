# Exporting the GPIOs used
cd init
./export.sh

# Initialization of All Interfaces
./4g_init.sh
./bluetooth_init.sh
./can_init.sh
./ethernet_init.sh
./gps_init.sh
./wifi_station_init.sh
cd ../

# Enabling All Interfaces
cd test_if
./led_on_off.sh &
./4g_ping.sh &
./ethernet_ping.sh &
./battery_status.sh &
./bluetooth_ping.sh &
./wifi_ping.sh &     
./gps_data.sh &
./mcu_fw_ver_read.sh &
./sensor_test
cd ../
