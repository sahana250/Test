killall -9 mcu_fw_ver_read.sh
killall -9 battery_status.sh
killall -9 led_on_off.sh
killall -9 4g_ping.sh
killall -9 sensor_test

# Deinitialization of All interfaces
cd deinit
./gps_deinit.sh
./4g_deinit.sh
./bluetooth_deinit.sh
./can_deinit.sh
./ethernet_deinit.sh
./wifi_deinit.sh

# Unexport all the GPIOs
./unexport.sh
cd ../

killall sh
