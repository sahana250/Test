#!/bin/sh
insmod /iwtest/Kernel-Module/tcan4x5x.ko
sleep 2
ip link set can2 up type can bitrate 250000
sleep 1
ip link set can0 up type can bitrate 250000
sleep 1
ip link set can1 up type can bitrate 250000
sleep 1
candump can0 &
candump can1 &

