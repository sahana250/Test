#!/bin/sh
killall battery_status_RE.sh