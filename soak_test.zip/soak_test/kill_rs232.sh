killall -9 cat
killall can_send.sh
