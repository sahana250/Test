#!/bin/sh
#Bluetooth Initialization
./bluetooth_init.sh

#Intializing GPIO
./export.sh

#Enabling all swithes
./switch_on.sh

#Modem 
./4g_on.sh

sleep 5

#CAN INIT
./can_init.sh

#ETH_INIT
./eth_init

sleep 10

#GPS
./gps_RE.sh & 
sleep 10

#4G TEST
./4G_AT_TEST & 

#BLUETOOTH SCAN
./bluetooth_scan.sh &

#LED
./led.sh &

#Battery Status
./battery_status_RE.sh &

#CAN send
./can_send.sh &

#Ethernet
./ethernet.sh &

#Accelerometer temperature
./acc_temp

#ACCELEROMETER & GYROSCOPE
./sensor_test 
