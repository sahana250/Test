#!/bin/sh
ifconfig can0 down
ifconfig can1 down
ifconfig can2 down

rmmod tcan4x5x.ko
sleep 1

killall can_send.sh