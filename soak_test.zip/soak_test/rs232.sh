#!/bin/sh
cat /dev/ttymxc5 &

while true
do
echo "RS232 data read" > /dev/ttymxc5 &
sleep 1
done
